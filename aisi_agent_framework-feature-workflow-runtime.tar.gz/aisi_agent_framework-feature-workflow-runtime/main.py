import os
import sys
import selectors
import time

# 根据命令行参数加载环境变量（dev -> .env.dev，prod -> .env），须在其它业务模块之前
import config.env_config  # noqa: F401

from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.graph.state import CompiledStateGraph
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import StreamingResponse, HTMLResponse, FileResponse

from agent.pg_checkpoint import PGCheckPoint
from config import get_logger
from entity.dh_model import DigitalHumanFactory
from agent.base_graph import BaseGraph
from api.api_zbt import zbt_router
from background import bg_router
from chat_stream import astream_events_generator
from entity.chat_request import ChatRequest

logger = get_logger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    checkpointer: AsyncPostgresSaver = await PGCheckPoint.init_checkpointer()
    logger.info("PostgreSQL checkpointer 初始化完成")
    app.state.workflow = BaseGraph.build_graph(checkpointer)
    yield
    await PGCheckPoint.close_checkpointer()
    logger.info("PostgreSQL 连接已关闭")


app = FastAPI(title="爱思 AI 大脑", lifespan=lifespan)

origins = [
    "https://serverless.t.nxin.com",
    "https://serverless.nxin.com",
    "https://r.nxin.com",
    "https://r.t.nxin.com",
    "https://liveui.nxin.com",
    "https://liveui.t.nxin.com",
    "https://liveui.nxin.com:8081",
    "https://liveui.t.nxin.com:8081",
]


app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # 允许的源
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

# 猪病通api
app.include_router(zbt_router)

# LangGraph 会话管理
app.include_router(bg_router)


@app.get("/health")
async def health_check():
    return {
        "status": "ok",
        "service": "aisi-agent-framework",
        "timestamp": int(time.time()),
    }


@app.get("/graph", response_class=HTMLResponse)
async def index():
    return FileResponse(os.path.join(os.path.dirname(__file__), "index.html"))


@app.post("/channel")
async def channel(request: ChatRequest, req: Request):
    """对应原ChannelV2"""
    workflow: CompiledStateGraph = req.app.state.workflow
    dh_type = req.query_params.get("dh_type", "")
    digital_human = DigitalHumanFactory.create(request, dh_type)
    return StreamingResponse(astream_events_generator(workflow, digital_human), media_type="text/event-stream")


if __name__ == "__main__":
    host = os.getenv('SERVER_HOST') or os.getenv('host', '0.0.0.0')
    port = int(os.getenv('SERVER_PORT') or os.getenv('port', '8997'))
    if sys.platform == "win32":
        import asyncio
        async def windows_server():
            """用 SelectorEventLoop 跑 uvicorn，兼容 psycopg async。"""
            config = uvicorn.Config(app, host=host, port=port)
            server = uvicorn.Server(config)
            await server.serve()
        asyncio.run(
            windows_server(),
            loop_factory=lambda: asyncio.SelectorEventLoop(selectors.SelectSelector()),
        )
    else:
        uvicorn.run(app, host=host, port=port)