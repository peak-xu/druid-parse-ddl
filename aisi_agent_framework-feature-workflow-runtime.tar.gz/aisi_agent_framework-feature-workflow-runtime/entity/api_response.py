class APIResponse:

    @staticmethod
    def succeed(data = None, msg = ''):
        return {"code": 0, "data": data, "msg": msg if msg else "请求成功"}

    @staticmethod
    def fail(msg = ''):
        return {"code": 0, "data": None, "msg": msg if msg else "请求失败"}