import json
from abc import ABC, abstractmethod
from typing import Dict

from langchain_core.tools import BaseTool

from entity.chat_request import ChatRequest


class BaseDigitalHuman(ABC):
    """数字人策略抽象基类"""
    dh_map: Dict[str, type] = {}  # 自动注册的子类表

    def __init_subclass__(cls, dh_type, **kwargs):
        super().__init_subclass__(**kwargs)
        if not dh_type:
            raise ValueError(f'数字人类型为空，请配置`dh_type`!')
        cls.dh_map[dh_type] = cls

    def __init__(self, request: ChatRequest = None):
        self._request = request
        self._tool_choice = False
        self._classify_type = 'default'
        self._tools = self._build_tools()
        self.tool_desc_map = self._build_tool_desc_map()

    def get_request(self) -> ChatRequest:
        return self._request

    def get_group_id(self) -> str:
        """获取集团id"""
        return str(self._request.env.group_id)

    def get_group_chat_content(self) -> str:
        """获取群聊上下文(并排除当前请求)"""
        group_chat_contents = []
        if len(self._request.user_chats) <= 1:
            return ''
        else:
            for user_chat in self._request.user_chats[:-1]:
                user_content = f'{user_chat.user_name}({user_chat.user_id}): {user_chat.content}'
                group_chat_contents.append(user_content)
        return "\n".join(group_chat_contents)

    def get_current_query_user(self) -> str:
        return self._request.user_chats[-1].user_id

    def get_current_query(self) -> str:
        """获取当前query"""
        return self._request.user_chats[-1].content

    def get_dataset_token(self) -> str:
        """获取数据集令牌"""
        return self._request.user_chats[-1].dataset_token

    def get_file_url(self) -> str:
        return self._request.user_chats[-1].file_url

    def get_file_type(self) -> str:
        return self._request.user_chats[-1].file_type

    def enable_thinking(self) -> bool:
        return bool(self._request.user_chats[-1].deep_thinking)

    def enable_web_search(self) -> bool:
        return bool(self._request.user_chats[-1].search_type)

    def get_conversation_id(self) -> str:
        if conversation_id := self._request.conversation_id:
            return conversation_id
        else:
            from uuid import uuid4
            return str(uuid4())

    def get_tools(self):
        """获取工具"""
        return self._tools

    def is_tool_choice(self) -> bool:
        """是否必执行工具"""
        return self._tool_choice

    def get_classify_type(self):
        """获取决策分类"""
        return self._classify_type

    def have_zsk_knowledge(self) -> bool:
        try:
            return bool(self._request.zsk_knowledge.knowledge_base_ids) or bool(self._request.zsk_knowledge.knowledge_ids)
        except Exception as e:
            return False

    def at_skill(self) -> bool:
        if self._request.at_general_skill_info is None:
            return False
        info = self._request.at_general_skill_info
        return len(info.dataset_meta_list or []) > 0 or len(info.skill_meta_list or []) > 0

    def at_dataset(self) -> bool:
        return len(self._request.at_dataset_meta_list) > 0

    def _build_tool_desc_map(self) -> dict:
        """根据工具对象列表构建 tool_name -> description（取 docstring 首行）的映射。"""
        tool_desc_map = {}
        for t in self._tools or []:
            desc = (t.description or "").strip().split("\n")[0]
            tool_desc_map[t.name] = desc or t.name
        return tool_desc_map


    @abstractmethod
    def system_prompt(self) -> str:
        """该数字人对应的系统提示词"""
        pass

    @abstractmethod
    def _build_tools(self) -> list[BaseTool]:
        """该数字人可用工具"""
        pass

    @abstractmethod
    def _need_output_result_tool_names(self) -> list[str]:
        """需要输出工具结果的工具名"""
        pass

    def output_tool_result(self, event: dict) -> tuple[dict|str|None, dict]:
        """
        输出工具执行结果，这个方法如果运行没报错，永远不要动。
        如需输出指定工具执行结果，只需在 `_need_output_result_tool_names` 配置需要输出结果的工具即可
        Args:
            event: astream_events迭代产出的事件对象
        Returns:
            工具结果
        """
        if tool_names := self._need_output_result_tool_names():
            tool_name = event.get("name", "tool")
            if tool_name in tool_names:
                extra_info = {"tool_name": tool_name}
                data = event.get("data", {})
                if result := data.get("output"):
                    content = result.content if hasattr(result, "content") else result
                    if content:
                        tool_result = json.loads(content)
                        if tool_call_id := getattr(result, "tool_call_id", None):
                            extra_info["tool_call_id"] = tool_call_id
                        return tool_result, extra_info
        return None, {}


class DigitalHumanFactory:
    """数字人工厂类"""
    _is_loaded = False

    @classmethod
    def _register_digital_human(cls):
        if not cls._is_loaded:
            import pkgutil, importlib
            import digital_human as package
            for _, module_name, _ in pkgutil.walk_packages(package.__path__, package.__name__ + "."):
                importlib.import_module(module_name)
            cls._is_loaded = True

    @classmethod
    def create(cls, request: ChatRequest, dh_type='default') -> BaseDigitalHuman:
        cls._register_digital_human()
        dh_class: type = BaseDigitalHuman.dh_map.get(dh_type, None)
        if dh_class:
            return dh_class(request=request)
        else:
            from digital_human.dh_default import DefaultDigitalHuman
            return DefaultDigitalHuman(request=request)