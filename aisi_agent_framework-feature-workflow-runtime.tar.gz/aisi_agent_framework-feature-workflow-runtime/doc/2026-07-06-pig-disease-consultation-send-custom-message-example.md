# 猪病通会诊 — 发送自定义消息对接

**调用方**：业务后端（需主动向会诊群下发 IM 消息时）  
**联调索取**：`im-manage-host`、`appId=4` 的 `secretKey`

> **边界**：群聊 `@AI` 的 AI 回复（`customType=2002`）由 **chatbot → im-hook** 自动投递，业务**一般不调**本接口。  
> 本接口适用于：会诊群内的**业务通知、系统提醒**等自定义消息。

---

## 1. 接口

```
POST {im-manage-host}/api/s1/serve/message/v1/send
```

| 项 | 值 |
|----|-----|
| Body | `IMMsgParam`（见 §4） |
| Header `appId` | `4` |

---

## 2. 鉴权 Header

与 [建群接口](./2026-07-06-pig-disease-consultation-create-group-example.md) 相同：

| Header | 说明 |
|--------|------|
| `appId` | `4` |
| `timestamp` | 毫秒时间戳 |
| `accessToken` | `MD5(secretKey + timestamp)` |

---

## 3. 自定义消息约定

OpenIM 自定义消息 **`contentType = 110`**。  
`content.data` 为 **JSON 字符串**，内层再包一层业务协议：

```json
{
  "customType": 2000,
  "data": { }
}
```

| customType | 名称 | 猪病通场景 |
|------------|------|------------|
| `2000` | 公共号 / 业务通知 | **业务主动**向群/单聊发通知、卡片等 |
| `2001` | AI 公共号上行 | 用户 → AI 公众号（非本接口主场景） |
| `2002` | chatbot AI 回复 | **@AI 自动投递**；前端解析群 AI 消息 |

---

## 4. Body 字段（群聊自定义消息）

### 4.1 顶层

| 字段 | 必填 | 会诊群示例 | 说明 |
|------|------|------------|------|
| `sendID` | 是 | 系统号 `userID` | 发送者 IM userID，**须属于 appId=4** |
| `groupID` | 是 | 建群返回的 `groupID` | `sessionType=3` 时必填 |
| `sessionType` | 是 | `3` | `1` 单聊 / `3` 群聊 / `4` 系统通知 |
| `contentType` | 是 | `110` | 自定义消息 |
| `content` | 是 | 见 §4.2 | `IMCustomMsgContent` |
| `recvID` | 否 | — | 群聊**不传** |
| `isOnlineOnly` | 否 | `false` | 仅在线可达 |
| `notOfflinePush` | 否 | `true` | 是否跳过离线推送 |

### 4.2 content（IMCustomMsgContent）

| 字段 | 必填 | 说明 |
|------|------|------|
| `data` | 是 | **字符串**：`{"customType":2000,"data":{...}}` 序列化结果 |
| `description` | 否 | 客户端摘要，如「会诊通知」 |
| `extension` | 否 | 扩展 |

> `contentType` 决定 Jackson 反序列化 `content` 类型；传 `110` 时 `content` 必须是上述结构。

---

## 5. 请求 / 响应示例（会诊群 · customType=2000）

**场景**：专家入群后，业务向会诊群推送一条「方案拟定已开始」通知。

```json
{
  "sendID": "0pig_disease_ai00020004004",
  "groupID": "1745818300123004001234",
  "sessionType": 3,
  "contentType": 110,
  "content": {
    "data": "{\"customType\":2000,\"data\":{\"type\":5,\"content\":\"eyJ0eXBlIjoibm90aWNlIiwidGl0bGUiOiLmtYvor5XliIbnsbvov5Hph43popgiLCJ0ZXh0Ijoi5LiT5a625bey5YWl576k77yM6K+35byA5aeL5pa55qGI5ouf5a6aIn0=\",\"isOwn\":false}}",
    "description": "会诊通知",
    "extension": ""
  },
  "isOnlineOnly": false,
  "notOfflinePush": true
}
```

说明：

- `sendID`：常用建群时的 **AI 系统号** `userID`（§建群文档 §4），或其它已注册的 `appId=4` 系统号。
- `groupID`：§建群成功响应中的 `groupID`。
- `data.data.content`：`2000` 协议里 `type=5` 时，`content` 为 **Base64(JSON)**。上例解码后为：
  `{"type":"notice","title":"会诊提醒","text":"专家已入群，请开始方案拟定"}`  
  若客户端已有公共号 `2000` 渲染组件，按现有规范组装即可。

**成功响应**（节选）：

```json
{
  "code": 0,
  "data": {
    "serverMsgID": "8b7e2f1a-4c3d-4e5f-9a0b-1c2d3e4f5a6b",
    "clientMsgID": "client-msg-id-001",
    "sendTime": 1745818300123,
    "recvID": "",
    "receiverType": 2
  }
}
```

| 响应字段 | 说明 |
|----------|------|
| `serverMsgID` | OpenIM 服务端消息 ID |
| `clientMsgID` | 客户端消息 ID（幂等键） |
| `receiverType` | `2` 表示群组 |

---

## 6. 对照：群 AI 回复（customType=2002，通常不由业务发送）

`@AI` 完成后，chatbot 经 im-hook 投递，群内消息体大致为：

```json
{
  "customType": 2002,
  "data": "{\"type\":\"reply\",\"text\":\"根据目前症状...\",\"textType\":\"markdown\",\"questionId\":\"...\",\"appId\":4}"
}
```

前端在群聊里解析 **`customType=2002`** 渲染 AI 回复；业务**无需**也**不应**手工模拟该结构发 @AI 回复。

---

## 7. 单聊自定义消息（可选）

若需单聊下发（非会诊群主路径）：

| 字段 | 值 |
|------|-----|
| `sessionType` | `1` |
| `recvID` | 接收者 IM userID |
| `groupID` | 不传 |

其余 `contentType=110` 与 `customType` 规则相同。

批量单聊 / 系统通知见：

- `POST .../message/v1/send/batch`（`sessionType` 1 或 4）
- `POST .../message/v1/public-account`（公众号下行）

---

## 8. 错误与校验

| 现象 | 原因 |
|------|------|
| 401 | 签名错误 |
| `无权以当前 appId 操作该用户或通知号` | `sendID` / `recvID` 不属于 `appId=4` |
| `群不存在` / 群归属失败 | `groupID` 无效或不属于 `appId=4` |
| `消息内容不能为空` | `content.data` 未传或为空 |
| `不支持的会话类型` | `sessionType` 非 1/3/4 |

---

## 9. 与建群文档的关系

| 步骤 | 文档 |
|------|------|
| 1. 注册 AI 系统号 | [建群示例 §4](./2026-07-06-pig-disease-consultation-create-group-example.md) |
| 2. 建会诊群，拿 `groupID` | [建群示例 §6](./2026-07-06-pig-disease-consultation-create-group-example.md) |
| 3. 本接口向群内发自定义消息 | 本文 §5 |
