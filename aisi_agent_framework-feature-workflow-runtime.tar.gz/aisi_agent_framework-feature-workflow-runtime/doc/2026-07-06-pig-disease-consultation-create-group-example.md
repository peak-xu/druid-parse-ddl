# 猪病通会诊建群 — 接口对接

**调用方**：业务后端（选专家校验通过后）  
**联调索取**：`im-manage-host`、`appId=4` 的 `secretKey`

---

## 1. 接口

```
POST {im-manage-host}/api/s1/serve/group/v1/create/3
```

| 项 | 值 |
|----|-----|
| `relatedType` | `3` |
| `relatedId` | `consultationId` |
| Body `appId` | `4` |

---

## 2. 鉴权 Header

| Header | 说明 |
|--------|------|
| `appId` | `4` |
| `timestamp` | 毫秒时间戳 |
| `accessToken` | `MD5(secretKey + timestamp)` |

---

## 3. 成员 `userType`

| userType | 谁 | 必填 | 说明 |
|----------|-----|------|------|
| `1`（默认） | 养殖户、专家 | `archiveId` | **须已 IM 注册**；未注册返回 `code=3001` |
| `2` | 会诊 AI | `userID` | **须先** `notification-account/add` 注册 |

> 对外建群接口**不自动注册**档案用户。`userType` 不传且有 `archiveId` 时默认 `1`。AI 必须显式传 `2`。

---

## 4. 前置注册(可以先不实现 后台注册一个就行)

| 成员 | 接口 |
|------|------|
| 档案用户 | `auth/user` 等 IM 用户注册接口（按现有流程） |
| AI | `POST .../notification-account/v1/add`（见下） |

**AI 注册（一次性）**：

```
POST {im-manage-host}/api/s1/serve/notification-account/v1/add
```

```json
{
  "businessId": "pig_disease_ai",
  "businessType": 2,
  "appMangerLevel": 4,
  "nickName": "爱思AI",
  "faceURL": "https://cdn.example.com/ai.png"
}
```

响应 `userID` → 建群时传入。

---

## 5. Body 字段

### 5.1 顶层

| 字段 | 必填 | 说明 |
|------|------|------|
| `appId` | 是 | `4` |
| `relatedId` | 是 | `consultationId` |
| `ownerUser` | 是 | 养殖户，见 §3 |
| `memberUsers` | 是 | 专家 + AI，见 §3 |
| `groupInfo` | 是 | 群信息，见 §5.2 |
| `adminUsers` | 否 | 会诊场景一般不需要 |

### 5.2 groupInfo

| 字段 | 必填 | 猪病通建议值 | 说明 |
|------|------|--------------|------|
| `groupName` | **是** | `猪病会诊-{专家名}` | 群名称 |
| `introduction` | 否 | `猪病通专家会诊` | 群介绍 |
| `notification` | 否 | — | 群公告 |
| `faceURL` | 否 | — | 群头像 |
| `needVerification` | 否 | `2` | 直接进群 |
| `lookMemberInfo` | 否 | `0` | 允许看成员 |
| `applyMemberFriend` | 否 | `0` | 允许互加好友 |
| `ex` | 否 | — | 扩展 JSON；服务端自动写 `relatedType=3`、`relatedId` |

> 响应还会返回 `groupID`、`ownerUserID`、`memberCount`、`createTime`、`status` 等，均为服务端生成，请求不用传。完整字段见 [group-create-related-api.md §3.3](../../group-create-related-api.md)。

---

## 6. 建群请求 / 响应

```json
{
  "appId": 4,
  "relatedId": "C-006",
  "ownerUser": {
    "archiveId": 600001
  },
  "memberUsers": [
    { "archiveId": 600002 },
    {
      "userType": 2,
      "userID": "0pig_disease_ai00020004004"
    }
  ],
  "groupInfo": {
    "groupName": "猪病会诊-李专家",
    "introduction": "猪病通专家会诊",
    "needVerification": 2,
    "lookMemberInfo": 0,
    "applyMemberFriend": 0
  }
}
```

**成功响应**（节选）：

```json
{
  "code": 0,
  "data": {
    "groupID": "1745818300123004001234",
    "groupName": "猪病会诊-李专家",
    "introduction": "猪病通专家会诊",
    "ownerUserID": "6000010004001",
    "memberCount": 3,
    "needVerification": 2,
    "ex": "{\"relatedType\":3,\"relatedId\":\"C-006\"}"
  }
}
```

> AI 的 `userID` 填 §4 注册返回值，**不要自己拼**。

**返前端**：`consultationId`、`imGroupId`、`groupCreatedAt`、`aiImUserId`（= 上面 AI 的 `userID`）。

## 7. 幂等 & 错误

| 错误 | 原因 |
|------|------|
| `code=3001` 用户未注册 | 档案用户未先注册 IM |
| `系统号 userID 无效或未注册` | AI userID 不在 `notification_account` |
| `群主须为档案用户` | owner 不能 userType=2 |
| 401 | 签名错误 |

同 `consultationId` 重复调 → 返回已有群。

字段全集：[group-create-related-api.md](../../group-create-related-api.md)
