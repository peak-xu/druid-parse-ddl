from langchain_core.tools import BaseTool

from entity.chat_request import Skill
from entity.dh_model import BaseDigitalHuman
from llm_tools.bms_tool import HttpToolBuilder
from utils.time_util import get_time_msg


class DefaultDigitalHuman(BaseDigitalHuman, dh_type='default'):
    """
    默认数字人
    """
    def system_prompt(self) -> str:
        # 默认数字人系统提示词仅拼接当前时间
        return f"{self._request.agent_data.role_settings}\n{get_time_msg()}"


    def _build_tools(self) -> list[BaseTool]:
        # 默认数字人构建bms配置的工具、数据集
        collect_skill_map: dict[str, Skill] = {}

        # 提取唯一 key 工具存入字典
        def collect_skill(s: Skill) -> None:
            key = f"{s.url or ''}{s.name or ''}"
            collect_skill_map[key] = s

        # 1. @通用技能，追加绑定的工具与数据集
        if self.at_skill():
            self._tool_choice = True
            self._classify_type = 'skill'
            info = self._request.at_general_skill_info
            all_skills = (info.skill_meta_list or []) + (info.dataset_meta_list or [])
            for skill in all_skills:
                collect_skill(skill)

        # 2. 单独@数据集列表
        if self.at_dataset():
            self._tool_choice = True
            self._classify_type = 'dataset'
            for skill in self._request.at_dataset_meta_list or []:
                collect_skill(skill)

        # 3. 无@强制调用时，加载全部默认技能池
        if not self._tool_choice:
            for skills_info in self._request.general_skills_info or []:
                for skill in skills_info.dataset_meta_list or []:
                    collect_skill(skill)
            for skill in self._request.dataset_meta_list or []:
                collect_skill(skill)
            for skill in self._request.skills or []:
                collect_skill(skill)
            function_skills = self._request.function_skills_info
            if function_skills:
                for skill in function_skills.skill_meta_list or []:
                    collect_skill(skill)
                for skill in function_skills.dataset_meta_list or []:
                    collect_skill(skill)

        tool_builder = HttpToolBuilder(self.get_group_id(), self.get_dataset_token())

        tools = tool_builder.build(list(collect_skill_map.values()))

        return tools


    def _need_output_result_tool_names(self) -> list[str]:
        return []