from langchain_core.tools import BaseTool

from api.api_zbt import ConsultationAPI
from config import get_logger
from entity.dh_model import BaseDigitalHuman
from llm_tools.pig_tool import pig_consultation_card_builder
from llm_tools.zsk_tool import create_zsk_tool
from utils.prompt_loader import load_prompt
from utils.time_util import get_time_msg

logger = get_logger(__name__)

class PigDigitalHuman(BaseDigitalHuman, dh_type='pig'):
    """
    猪病通数字人
    """
    def system_prompt(self):
        """猪病通数字人提示词在默认基础上拼接业务中需要的提示词"""
        sys_prompt = f"{self._request.agent_data.role_settings}\n{get_time_msg()}\n\n"
        status = ConsultationAPI.is_start_group(self.get_conversation_id())
        if status:
            logger.info('猪病通 prompt：群聊场景模式')
            return sys_prompt + load_prompt('zbt_group_chat_prompt.md')
        else:
            logger.info('猪病通 prompt：新建对话模式')
            return sys_prompt + load_prompt('zbt_new_conversation_prompt.md')


    def _build_tools(self) -> list[BaseTool]:
        """构建猪病通可用工具"""
        zsk_tool = create_zsk_tool(self._request)
        pig_consultation_card = pig_consultation_card_builder(self.get_conversation_id())
        return [zsk_tool, pig_consultation_card]


    def _need_output_result_tool_names(self) -> list[str]:
        pig_consultation_card = pig_consultation_card_builder(self.get_conversation_id())
        return [pig_consultation_card.name]