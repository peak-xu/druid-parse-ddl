import time
from typing import Optional

from langgraph.graph.state import CompiledStateGraph

from agent.aisi_state import AISIState
from config import get_logger
from entity.dh_model import BaseDigitalHuman
from utils.sse_response_util import StreamResponseGenerator, EventType


logger = get_logger(__name__)


async def astream_events_generator(
        workflow: CompiledStateGraph,
        digital_human: BaseDigitalHuman,
):
    """
    处理流式输出
    Args:
        workflow: 工作流
        digital_human: 数字人

    Returns:
        StreamResponseGenerator
    """
    config = {
        "configurable": {
            "thread_id": digital_human.get_conversation_id(),
        }
    }

    query = digital_human.get_current_query()

    logger.info('*' * 60)
    logger.info(f'>>> 用户当前 query: {query}')
    logger.info(f'>>> 请求数字人为：{type(digital_human)}')
    logger.info('*' * 60)

    start_time = time.time()
    first_yield_time: Optional[float] = None
    tk_count = {}
    final_answer = []  # 累积大模型完整回复

    request = digital_human.get_request()
    sse = StreamResponseGenerator(request)
    yield sse.start(start_time)

    try:
        event : dict
        async for event in workflow.astream_events(
            input=AISIState.initial_state(digital_human),
            config=config,
            context={"digital_human": digital_human},
            version="v2"
        ):
            if first_yield_time is None:
                first_yield_time = time.time()
                logger.info(f'首次 token 响应时长:{first_yield_time - start_time:.2f} s')

            event_type = event.get("event")
            data = event.get("data", {})

            # 模型流式输出 - 打字机效果
            # 默认静默：只放行不带 nostream 标签的模型调用（面向用户的最终回复，
            # 即 create_llm(stream_output=True)）。意图识别、摘要等中间过程小任务
            # 默认 stream_output=False 带 nostream，不输出给用户。
            if event_type == "on_chat_model_stream" and "nostream" not in event.get("tags", []):
                chunk = data.get("chunk")
                if chunk and hasattr(chunk, 'content') and chunk.content:
                    final_answer.append(chunk.content)
                    yield sse.output(chunk.content, EventType.GENERATING)

            # 工具调用开始 - 输出工具名称
            elif event_type == "on_tool_start":
                tool_name = event.get("name", "tool")
                tool_display = digital_human.tool_desc_map.get(tool_name)
                yield sse.output(f'调用工具：{tool_display}', EventType.CAPTION)

            # 工具调用结束 - 输出工具结果
            elif event_type == "on_tool_end":
                tool_result, extra_info = digital_human.output_tool_result(event)
                if tool_result:
                    yield sse.output(tool_result, EventType.TOOL_RESULT, extra_info)

            # 收集 token 使用信息
            elif event_type == "on_chat_model_end":
                usage = data.get("usage_metadata", {})
                if usage:
                    tk_count["input_tokens"] = tk_count.get("input_tokens", 0) + usage.get("input_tokens", 0)
                    tk_count["output_tokens"] = tk_count.get("output_tokens", 0) + usage.get("output_tokens", 0)
                    tk_count["total_tokens"] = tk_count.get("total_tokens", 0) + usage.get("total_tokens", 0)

        yield sse.end(time.time(), tk_count)

        final_answer = "".join(final_answer)
        logger.info(f'大模型最终完整回复：\n{final_answer}')
        logger.info(f'总耗时:{time.time() - start_time:.2f} s')

    except Exception as e:
        yield sse.output('本次对话过程发生异常中断，请稍后重试')
        yield sse.end(time.time(), tk_count)
        logger.exception("对话过程发生异常中断")  # 输出到日志文件，附带完整堆栈