# AISI Agent Framework

本项目复刻了原 Digital-human 项目 channelV2 和 518 需求的 90% 功能，使用 **FastAPI + LangChain + LangGraph** 进行架构升级。

## 项目结构

```
aisi_agent_framework/
├── main.py                    # FastAPI 入口，应用启动与路由注册
├── chat_stream.py             # SSE 流式响应生成器
│
├── agent/                     # LangGraph 工作流核心
│   ├── aisi_state.py          # 图状态定义（AISIState）
│   ├── base_graph.py          # 图构建器，节点与边编排
│   ├── pg_checkpoint.py       # PostgreSQL 状态持久化
│   └── nodes/
│       ├── step_0_summarize_node.py       # 历史消息摘要（token 压缩）
│       ├── step_1_preprocessing_node.py   # 预处理（设置 tool_choice、thinking 等标志）
│       ├── step_2_classify_node.py        # 分类路由（多模态 / 技能 / 默认）
│       ├── agent_default_node.py          # 默认 Agent 节点
│       ├── agent_multimodal_node.py       # 多模态 Agent 节点（图片识别）
│       ├── agent_skill_or_dataset_node.py # 技能/数据集强制执行节点
│       └── agent_data_hub_node.py         # DataHub 查询节点（暂未启用）
│
├── api/
│   └── api_zbt.py             # 猪病通业务 API 路由（/zbt 前缀）
│
├── config/
│   ├── __init__.py            # 导入时自动初始化日志
│   ├── env_config.py          # 环境配置、LLM 工厂、常量
│   └── logger_config.py       # 日志配置（JSON 文件 + 彩色终端）
│
├── digital_human/             # 数字人子类（策略模式）
│   ├── dh_default.py          # DefaultDigitalHuman（通用，BMS HTTP 工具）
│   └── dh_zbt.py              # PigDigitalHuman（猪病通，ZSK + 诊疗卡工具）
│
├── entity/                    # Pydantic 数据模型
│   ├── chat_request.py        # ChatRequest、Chat、Env、Skill 等
│   ├── dh_model.py            # BaseDigitalHuman（抽象基类）+ DigitalHumanFactory
│   └── api_response.py        # APIResponse 响应封装
│
├── llm_tools/                 # LangChain 工具定义
│   ├── bms_tool.py            # HttpToolBuilder：Skill → BaseTool（HTTP 调用）
│   ├── multimodal_tool.py     # get_image_metadata 工具
│   ├── pig_tool.py            # pig_consultation_card 工具（诊疗卡）
│   └── zsk_tool.py            # zsk_tool（知识库检索）
│
├── prompt_templetes/          # 提示词模板（Markdown）
│
├── utils/                     # 工具模块
│   ├── db_mongo.py            # MongoDBUtil（CRUD、分页）
│   ├── group_chat_util.py     # IMUtil（创建群聊、发送 IM 消息）
│   ├── http_util.py           # httpx.Client 单例
│   ├── langchain_util.py      # run_all_tools_forced（强制执行所有工具）
│   ├── multimodal_util.py     # Word/PDF/PPT 文件解析
│   ├── prompt_loader.py       # load_prompt() 加载提示词模板
│   ├── sse_response_util.py   # SSE 事件格式化
│   ├── string_util.py         # UUID、模板提取
│   └── time_util.py           # 日期时间工具
│
├── .env                       # 正式环境配置
├── .env.dev                   # 测试环境配置
└── requirements.txt           # 项目依赖（pip 管理）
```

## Agent 工作流

基于 LangGraph `StateGraph` 构建，流程如下：

```
START → 摘要节点 → 预处理节点 → 分类节点 → [路由]
                                        ├── 多模态节点 → END    （上传图片时）
                                        ├── 技能节点 → END      （@技能/数据集时）
                                        └── 默认节点 → END      （其他情况）
```

| 节点 | 说明 |
|------|------|
| **摘要节点** | 当 token 总量超过 40,000 时，将较早的消息压缩为摘要，保留最近 20 条 |
| **预处理节点** | 从 `digital_human` 读取请求信息，设置 `tool_choice`、`enable_thinking` 等状态标志 |
| **分类节点** | 根据状态路由：有图片 → 多模态，有 @技能 → 技能节点，否则 → 默认节点 |
| **默认节点** | 使用 `create_agent` 创建 LLM Agent，携带数字人的系统提示词和工具 |
| **多模态节点** | 使用多模态模型，附加图片识别提示词和 `get_image_metadata` 工具 |
| **技能节点** | 强制执行所有 @技能工具，将工具结果 + 上下文交给 LLM 生成最终回答 |

图编译时使用 PostgreSQL Checkpointer 实现会话状态持久化。

## 数字人体系

采用 **策略模式 + 自动注册**，通过 `BaseDigitalHuman.__init_subclass__(dh_type=...)` 将子类自动注册到 `dh_map`，`DigitalHumanFactory` 根据 `dh_type` 参数分发。

| 数字人 | dh_type | 系统提示词 | 工具 | 输出工具结果 |
|--------|---------|-----------|------|-------------|
| DefaultDigitalHuman | `default` | role_settings + 当前日期 | BMS HTTP 工具（从请求动态构建） | 无 |
| PigDigitalHuman | `pig` | 猪病通群聊/新对话提示词 | zsk_tool + pig_consultation_card | pig_consultation_card 结果 |

`BaseDigitalHuman` 封装了 `ChatRequest` 的常用方法（获取查询、文件、工具列表、分类类型等），使 Agent 工作流只面对基类接口，避免大量 `if...else...`。

## 快速开始

### 环境要求

- Python >= 3.12
- PostgreSQL（用于 LangGraph Checkpoint）
- MongoDB（用于猪病通业务数据）

### 安装依赖

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# Linux / macOS
source .venv/bin/activate

pip install -r requirements.txt
```

### 配置环境

在 [.env.dev](.env.dev)（测试环境）或 [.env](.env)（正式环境）中填写配置，同时在 [env_config.py](config/env_config.py) 中通过 `os.getenv('XXX')` 注册新的配置项。

主要配置项：

| 分类 | 配置项 |
|------|--------|
| 日志 | `LOG_LEVEL` |
| PostgreSQL | `PG_CHECKPOINT_URI` |
| IM 服务 | `IM_MANAGE_HOST`, `IM_SECRET_KEY`, `ZBT_IM_APP_ID` |
| MongoDB | `MONGODB_HOST`, `MONGODB_PORT`, `MONGODB_DATABASE`, `MONGODB_USERNAME`, `MONGODB_PASSWORD` |
| 知识库 | `ZSK_HOST`, `ZSK_API_KEY` |
| LLM 模型 | `BASE_MODEL_*`, `CODE_MODEL_*`, `THINKING_MODEL_*`, `MULTIMODAL_MODEL_*`（各含 `BASE_URL`、`API_KEY`、`NAME`） |

### 启动服务

```bash
# 测试环境
python main.py dev

# 正式环境
python main.py prod

# 或使用启动脚本（Git Bash / Linux）
./start.sh dev
./start.sh prod
```

服务默认监听 `0.0.0.0:8997`，可通过环境变量 `host` / `port`（或 `SERVER_HOST` / `SERVER_PORT`）覆盖。

## API 接口

### AI 对话

- `POST /channel?dh_type={type}` — SSE 流式 AI 对话，接受 `ChatRequest` 请求体

### 猪病通业务（/zbt 前缀）

主要接口包括：兽医管理、诊疗卡、诊断状态、治疗记录、会诊管理、群聊、检测报告、病例库等。详见 [api/api_zbt.py](api/api_zbt.py)。

## 开发指南

### 如何添加环境配置？

在 [.env](.env)（正式环境）或 [.env.dev](.env.dev)（测试环境）添加配置项，同时在 [env_config.py](config/env_config.py) 中通过 `os.getenv('XXX')` 注册，即可在代码任何位置获取。

### 如何使用独立的提示词模板？

在 [prompt_templetes/](prompt_templetes/) 目录下编写 `.md` 文件，在项目中使用 `load_prompt('XXX.md')` 获取提示词内容。

### 如何创建一个新的数字人？

继承 `BaseDigitalHuman` 类，声明 `dh_type` 参数，实现三个抽象方法：

```python
class MyDigitalHuman(BaseDigitalHuman, dh_type='my_type'):
    def system_prompt(self) -> str:
        ...

    def _build_tools(self) -> list[BaseTool]:
        ...

    def _need_output_result_tool_names(self) -> list[str]:
        ...
```

`DigitalHumanFactory` 会自动发现并注册新子类，无需额外配置。

### 新数字人有特定需求怎么办？

优先在子类中实现。若多个数字人可能共用该需求，则提升到 `BaseDigitalHuman` 增加相关功能，并让所有子类实现。若确实无法在基类层面解决，需调整 Agent 工作流——但请注意，**鼓励只使用一个 Agent 工作流，并减少 `if...else...`**。

### Agent 工作流还需调整吗？

目前工作流以 518 需求为基础构建，后续会集成「人类介入确认」、「deep-agent 合并」等通用功能。

## 核心设计模式

| 模式 | 说明 |
|------|------|
| **策略模式 + 自动注册** | `BaseDigitalHuman.__init_subclass__` + `DigitalHumanFactory`，按 `dh_type` 分发 |
| **LangGraph StateGraph** | 线性流水线 + 分类节点条件路由，PG Checkpoint 持久化会话 |
| **SSE 流式输出** | `astream_events_generator` 过滤 `nostream` 标签，分离内部推理与用户输出 |
| **动态工具构建** | `HttpToolBuilder` 将请求中的 `Skill` 对象转换为 LangChain `StructuredTool`，运行时可配置 |
| **nostream 标签约定** | `stream_output=False` 的 LLM 调用标记为 `nostream`，SSE 生成器仅流式输出无此标签的内容 |
