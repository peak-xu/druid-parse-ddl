from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.constants import START, END
from langgraph.graph import StateGraph

from agent.aisi_state import AISIState
from agent.nodes.step_0_summarize_node import summarize_node
from agent.nodes.step_1_preprocessing_node import preprocessing_node
from agent.nodes.step_2_classify_node import classify_node
from agent.nodes.agent_default_node import default_node
from agent.nodes.agent_multimodal_node import multimodal_node
from agent.nodes.agent_skill_or_dataset_node import skill_or_dataset_node
from agent.nodes.agent_data_hub_node import data_hub_node
from agent.nodes.agent_knowledge_rag_node import knowledge_rag_node

# 维护图节点名
SUMMARIZE_NODE = 'summarize_node'
PREPROCESSING_NODE = 'preprocessing_node'
CLASSIFY_NODE = 'classify_node'
DEFAULT_NODE = 'default_node'
SKILL_OR_DATASET_NODE = 'skill_or_dataset_node'
MULTIMODAL_NODE = 'multimodal_node'
DATA_HUB_NODE = 'data_hub_node'
KNOWLEDGE_RAG_NODE = 'knowledge_rag_node'


class BaseGraph:

    @staticmethod
    def build_graph(checkpointer: AsyncPostgresSaver=None):
        graph = StateGraph(AISIState)

        # 添加节点
        graph.add_node(SUMMARIZE_NODE, summarize_node)
        graph.add_node(PREPROCESSING_NODE, preprocessing_node)
        graph.add_node(CLASSIFY_NODE, classify_node)
        graph.add_node(DEFAULT_NODE, default_node)
        graph.add_node(SKILL_OR_DATASET_NODE, skill_or_dataset_node)
        graph.add_node(MULTIMODAL_NODE, multimodal_node)
        graph.add_node(DATA_HUB_NODE, data_hub_node)
        graph.add_node(KNOWLEDGE_RAG_NODE, knowledge_rag_node)

        # 设置边
        graph.add_edge(START, SUMMARIZE_NODE)
        graph.add_edge(SUMMARIZE_NODE, PREPROCESSING_NODE)
        graph.add_edge(PREPROCESSING_NODE, CLASSIFY_NODE)
        graph.add_edge(DEFAULT_NODE, END)
        graph.add_edge(SKILL_OR_DATASET_NODE, END)
        graph.add_edge(MULTIMODAL_NODE, END)
        graph.add_edge(DATA_HUB_NODE, END)
        graph.add_edge(KNOWLEDGE_RAG_NODE, END)

        # checkpointer 为 None 时图正常工作，只是不持久化
        return graph.compile(checkpointer=checkpointer)


if __name__ == '__main__':
    test_graph = BaseGraph.build_graph().get_graph()
    print('-' * 60)
    print('图结构')
    print('-' * 60)
    print(test_graph.draw_mermaid())
    print('-' * 60)

    png_bytes = test_graph.draw_mermaid_png()
    with open("BaseGraph.png", "wb") as f:
        f.write(png_bytes)