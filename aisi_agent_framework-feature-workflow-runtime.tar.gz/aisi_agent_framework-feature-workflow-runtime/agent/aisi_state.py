from typing import Annotated, Any

from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage
from langgraph.graph import add_messages
from pydantic import BaseModel

from config import get_logger
from entity.dh_model import BaseDigitalHuman
from utils.multimodal_util import parse_file_type, parse_file_url_content

logger = get_logger(__name__)


class AISIState(BaseModel):
    """定义Agent的状态结构"""
    messages: Annotated[list[AnyMessage], add_messages] = []
    tool_choice: bool = False
    enable_thinking: bool = False
    enable_web_search: bool = False
    upload_image: bool = False
    classify_type: str = ''

    @staticmethod
    def initial_state(digital_human: BaseDigitalHuman) -> dict:
        query = digital_human.get_current_query()

        file_url = digital_human.get_file_url()
        file_type = digital_human.get_file_type()

        state: dict[str, Any] = {'messages': []}

        # 群聊上下文
        if group_chat := digital_human.get_group_chat_content():
            state['messages'].append(SystemMessage("群聊上下文（上次AI回复后的群内消息）：\n" + group_chat))

        # 上传图片
        if file_url and file_type == 'image':
            state['upload_image'] = True
            state['messages'].append(
                HumanMessage(content=[
                    {"type": "text", "text": query},
                    {"type": "image_url", "image_url": {"url": file_url}}
                ])
            )

        # 上传文档
        elif file_url and file_type != 'image':
            file_type = parse_file_type(file_url)
            file_content = parse_file_url_content(file_url, file_type)
            state['messages'].extend([
                HumanMessage(content=f'文件地址：{file_url}，\n文件内容为：\n{file_content}'),
                HumanMessage(content=query)
            ])
        # 普通提问
        else:
            state['messages'].append(HumanMessage(content=query))
        return state