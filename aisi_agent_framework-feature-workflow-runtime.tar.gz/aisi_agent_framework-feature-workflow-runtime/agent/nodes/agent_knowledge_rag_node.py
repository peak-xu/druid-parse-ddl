import ast
from typing import Literal

from langchain_core.messages import SystemMessage
from langgraph.runtime import Runtime
from langgraph.types import Command
from agent.aisi_state import AISIState
from config import get_logger
from config.env_config import LlmFactory
from entity.dh_model import BaseDigitalHuman
from utils.knowledge__retriever_util import KnowledgeRetrieverUtil

logger = get_logger(__name__)


async def knowledge_rag_node(
        state: AISIState,
        runtime: Runtime,
) -> Command[Literal['default_node']]:
    """知识库 RAG 节点：用户 @ 了知识库时，检索领域知识后交由大模型作答。

    处理逻辑：
    1. 从 runtime.context 取出 digital_human。
    2. 调用 zsk_retriever 检索用户指定知识库。
    3. 检索失败或无结果时，路由到 default_node 兜底。
    4. 检索成功时，把知识片段拼进 system_prompt，调用模型生成最终回复。
    5. 仅把本轮最终回复传给 update，依赖 add_messages 追加，避免历史重复累积。
    """

    logger.info(">>> 进入 knowledge_rag_node...")

    digital_human: BaseDigitalHuman = runtime.context['digital_human']
    user_chat = digital_human.get_request().user_chats[0]

    knowledge = None
    zsk_knowledge = digital_human.get_request().zsk_knowledge
    if zsk_knowledge:
        logger.info(f"******执行知识库检索****** query={user_chat.content}, conversation_id={digital_human.get_conversation_id()}")
        knowledge = await KnowledgeRetrieverUtil.zsk_retriever(
            digital_human.get_current_query(),
            knowledge_base_ids=zsk_knowledge.knowledge_base_ids or [],
            knowledge_ids=zsk_knowledge.knowledge_ids or [],
        )
        if knowledge:
            logger.info(f"知识库检索结果（前 200 字符）：{knowledge[:200]}")

    # 检查是否进行联网检索
    online_search_info = None
    online_search = user_chat.search_type
    query = user_chat.content
    if online_search:
        logger.info(f"******执行联网搜索****** query={user_chat.content}, conversation_id={digital_human.get_conversation_id()}")
        online_search_info = await KnowledgeRetrieverUtil.online_search(query)
        if online_search_info:
            logger.info(f"联网检索到的知识信息（前 200 字符）：{online_search_info[:200]}")

    # online_search_info = None

    if not _has_retrieval_result(knowledge) and not _has_retrieval_result(online_search_info):
        logger.info("知识库检索无结果，下一个节点：default_node")
        return Command(goto='default_node')

    system_prompt = digital_human.system_prompt()
    if _has_retrieval_result(knowledge):
        system_prompt += f"\n以下是从知识库检索到的相关内容，\n{knowledge}\n"
    if _has_retrieval_result(online_search_info):
        system_prompt += f"\n以下是联网搜索到的相关内容，\n{online_search_info}\n"
    system_prompt += "请据此回答用户问题：\n"
    context_messages = [SystemMessage(content=system_prompt)] + state.messages

    llm = LlmFactory.create_llm(stream_output=True)
    final_response = await llm.ainvoke(context_messages)

    return Command(update={"messages": [final_response]})


def _has_retrieval_result(knowledge: str) -> bool:
    """判断知识库检索是否返回了有效内容。"""
    if not knowledge or not knowledge.strip():
        return False
    try:
        items = ast.literal_eval(knowledge)
        return bool(items)
    except (ValueError, SyntaxError):
        return False
