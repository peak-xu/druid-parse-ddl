from config import get_logger

from langgraph.runtime import Runtime
from langgraph.types import Command

from agent.aisi_state import AISIState
from entity.dh_model import BaseDigitalHuman

logger = get_logger(__name__)

async def preprocessing_node(state: AISIState, runtime: Runtime) -> Command:
    """预处理节点：根据请求构造本次对话可用的工具列表，并更新相关状态。

    处理逻辑：
    1. 从 runtime.context 取出原始请求。
    2. 调用 _build_tools 收集工具：若用户 @了技能/数据集则强制调用（tool_choice=True），
       否则加载全部默认技能池供模型按需选择。
    3. 将工具列表写回 runtime.context，供后续节点使用。
    4. 根据请求更新状态：是否强制调用工具、是否开启深度思考、是否开启联网搜索。
    5. 通过 Command(update=...) 返回状态更新。
    """

    logger.info(">>> 进入 preprocessing_node...")

    digital_human: BaseDigitalHuman = runtime.context['digital_human']

    update_state = dict(
        tool_choice=digital_human.is_tool_choice(),
        enable_thinking=digital_human.enable_thinking(),
        enable_web_search=digital_human.enable_web_search(),
        classify_type=digital_human.get_classify_type()
    )

    logger.info(f"更新状态：{update_state}")

    return Command(update=update_state)