from config import get_logger

from langchain_core.messages.utils import count_tokens_approximately
from langchain_core.messages import SystemMessage, RemoveMessage, ToolMessage, AIMessage

from agent.aisi_state import AISIState
from config.env_config import LlmFactory

logger = get_logger(__name__)


TOKEN_THRESHOLD = 40000
KEEP_LAST = 20
SUMMARY_PROMPT = "请将以上对话历史压缩为简洁摘要，保留关键事实、决策和待办事项。"


async def summarize_node(state: AISIState):
    """历史摘要节点：当对话 token 超过阈值时，把较早的消息压缩成摘要。

    处理逻辑：
    1. 统计当前消息总 token 数，未超阈值则直接返回（不压缩）。
    2. 超过阈值时，将消息分为「待摘要的旧消息」与「保留的最近 N 条消息」。
    3. 过滤掉旧消息中的工具调用相关消息（ToolMessage、纯 tool_calls 的 AIMessage），
       仅保留人类/AI 文本内容用于摘要，避免噪音干扰。
    4. 调用模型对旧消息生成简洁摘要。
    5. 通过 RemoveMessage 删除全部旧消息，再追加一条摘要 SystemMessage，
       并重建最近 N 条消息（生成新对象、置空 id），完成历史压缩。
    """

    messages = state.messages
    total_tokens = count_tokens_approximately(messages)

    if total_tokens < TOKEN_THRESHOLD:
        # 统计当前消息总 token 数，未超阈值则直接返回（不压缩）。
        return {}

    logger.warning(f'上下文 TOKEN 超过 {TOKEN_THRESHOLD}，开始压缩历史会话...')

    # 超过阈值时，将消息分为「待摘要的旧消息」与「保留的最近 N 条消息」。
    old_msgs = messages[:-KEEP_LAST]
    recent_msgs = messages[-KEEP_LAST:]

    # 过滤掉旧消息中的工具调用相关消息（ToolMessage、纯 tool_calls 的 AIMessage），
    # 仅保留人类/AI 文本内容用于摘要，避免噪音干扰。
    old_msgs = strip_tool_messages(old_msgs)

    # 调用模型对旧消息生成简洁摘要
    summary_resp = await LlmFactory.create_llm().ainvoke(old_msgs + [SystemMessage(content=SUMMARY_PROMPT)])

    # 重建 recent 消息:必须创建新对象(不能复用原 id,因为原消息马上要被删掉)
    rebuilt_recent = [m.model_copy(update={"id": None}) for m in recent_msgs]

    return {
        "messages": (
            [RemoveMessage(id=m.id) for m in messages]  # 删掉全部旧消息(old + recent)
            + [SystemMessage(content=f"[历史摘要] {summary_resp.content}")]
            + rebuilt_recent
        )
    }

def strip_tool_messages(messages):
    """过滤掉工具调用相关消息,只保留人类/AI文本内容用于摘要"""
    filtered = []
    for m in messages:
        if isinstance(m, ToolMessage):
            continue  # 丢弃工具返回结果
        if isinstance(m, AIMessage) and m.tool_calls:
            # AI消息如果只是工具调用(没有文本内容),直接丢弃
            if not m.content:
                continue
            # 如果AI消息同时有文本和tool_calls,只保留文本部分
            filtered.append(AIMessage(content=m.content))
            continue
        filtered.append(m)
    return filtered