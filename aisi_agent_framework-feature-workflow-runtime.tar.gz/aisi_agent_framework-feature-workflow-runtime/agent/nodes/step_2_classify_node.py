from typing import Literal

from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.types import Command

from agent.aisi_state import AISIState
from config import get_logger
from config.env_config import LlmFactory
from utils.prompt_loader import load_prompt
from langgraph.runtime import Runtime
from entity.dh_model import BaseDigitalHuman

logger = get_logger(__name__)


async def classify_node(
        state: AISIState,
        runtime: Runtime
) -> Command[Literal[
    "default_node",
    "skill_or_dataset_node",
    "multimodal_node",
    "data_hub_node",
    "knowledge_rag_node",
]]:
    """分类决策节点：根据当前状态路由到下一个执行节点。

    处理逻辑（按优先级判断）：
    1. 若用户上传了图片，路由到 multimodal_node（多模态处理）。
    2. 若识别为农信业务意图，路由到 data_hub_node。
    3. 若用户 @ 了知识库，路由到 knowledge_rag_node。
    4. 其余通用场景路由到 default_node（默认 agent 自主决策是否调用工具）。
    """

    logger.info(">>> 进入 classify_node, 开始决策下一个节点...")

    digital_human: BaseDigitalHuman = runtime.context['digital_human']

    # 多模态
    if state.upload_image:
        logger.info(f"用户上传了图片，下一个节点：multimodal_node")
        return Command(goto='multimodal_node')

    # 拿出当前会话query
    last_msg = None
    all_msg = state.messages
    if all_msg:
        last_msg = all_msg[-1]
    # 通过意图识别决定是否要执行 data_hub 获取业务数据
    user_intent = nxin_intent_recognition(last_msg)
    if last_msg and user_intent == "1":
        logger.info(f"识别为农信业务，下一个节点：data_hub_node")
        return Command(goto='data_hub_node')
    # at了知识库，走知识库查询
    hava_zsk = digital_human.have_zsk_knowledge()
    if last_msg and hava_zsk and user_intent == "2":
        logger.info(f"at了zsk，下一个节点：knowledge_rag_node")
        return Command(goto='knowledge_rag_node')

    # 通用场景
    # if state.tool_choice:
    #     logger.info(f"下一个节点：skill_or_dataset_node")
    #     return Command(goto='skill_or_dataset_node')
    # 默认兜底
    logger.info(f"下一个节点：default_node")
    return Command(goto='default_node')

def nxin_intent_recognition(query: str) -> str:
    """
    判断用户请求是否要获取农信业务数据
    """
    try:
        system_prompt = SystemMessage(load_prompt("sys_nxin_intent_recognition_prompt.md"))
        belong_nxin = LlmFactory.create_llm().invoke([
            system_prompt,
            query
        ]).content
        return belong_nxin
    except Exception:
        return "3"