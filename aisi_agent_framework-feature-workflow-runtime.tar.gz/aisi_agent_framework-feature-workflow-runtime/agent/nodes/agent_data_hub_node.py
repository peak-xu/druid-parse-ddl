import json

from config import get_logger
import httpx
from langchain_core.messages import SystemMessage
from langgraph.runtime import Runtime
from langgraph.types import Command

from agent.aisi_state import AISIState
from entity.dh_model import BaseDigitalHuman
from config.env_config import LlmFactory, DATAHUB_URL
from entity.chat_request import ChatRequest
from utils.time_util import get_time_msg


logger = get_logger(__name__)


async def data_hub_node(state: AISIState, runtime: Runtime) -> Command:
    """数据中台节点：用户 @了数据集时，直接请求 DataHub 取数后交由大模型作答。

    处理逻辑：
    1. 从 runtime.context 取出原始请求。
    2. 用角色设定 + 系统日期拼接 system_prompt（仅临时拼接，不写入历史）。
    3. 调用 DataHub 接口，按用户 query + 会话 id 取数，并对返回字段做中文名替换。
    4. 把取数结果拼进 system_prompt 作为参考数据，调用模型生成最终回复。
    5. 仅把本轮最终回复传给 update，依赖 add_messages 追加，避免历史重复累积。
    """

    logger.info(">>> 进入 data_hub_node...")

    digital_human: BaseDigitalHuman = runtime.context['digital_human']

    # 1. 调用 DataHub 获取数据
    data = await fetch_from_data_hub(digital_human)
    logger.info(f"DataHub 返回数据（前 200 字符）：{data[:200]}")

    # 2. 拼接 system_prompt，把取数结果作为参考数据注入（不写入历史）
    system_prompt = (f"{digital_human.system_prompt()}\n"
                     f"以下是从数据中台查询到的数据，\n{data}\n请据此回答用户问题：\n")
    context_messages = [SystemMessage(content=system_prompt)] + state.messages

    # 3. 调用模型生成最终回复
    llm = LlmFactory.create_llm(stream_output=True)
    final_response = await llm.ainvoke(context_messages)

    # 关键：只把本轮新增的最终回复传给 update，依赖 add_messages reducer 做追加
    return Command(update={"messages": [final_response]})


async def fetch_from_data_hub(digital_human: BaseDigitalHuman) -> str:
    """请求 DataHub 取数，返回可直接注入上下文的数据文本。

    移植自 aisi_agent_framework/channelV2.py 的 _get_data_from_hub：
      - body: {query, session_id}
      - header: Content-Type + Authorization(Bearer dataset_token)
      - 成功时按 fields 的 name->text 做字段中文名替换
    任何异常都降级为兜底文案，保证节点不中断。
    """
    msg = '未查询到结果，请依次检查用户是否有数据查看权限，时间等关键过滤参数是否正确传入'
    try:
        body = json.dumps({
            'query': digital_human.get_current_query(),
            'session_id': digital_human.get_conversation_id()
        }, ensure_ascii=False).encode('utf-8')
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {digital_human.get_dataset_token()}'
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url=DATAHUB_URL, headers=headers, content=body)
            res = resp.json()

        if res.get('status') == 0:
            msg = res.get('message', msg)
        else:
            # 字段中文映射
            fields_map = {field['name']: field['text'] for field in res['data']['fields']}
            dh_data_list = res['data']['data']['value']
            if dh_data_list:
                msg = str(dh_data_list)
                for key, value in fields_map.items():
                    msg = msg.replace(key, value)
    except Exception as e:
        logger.error(f'DataHub数据提取异常：{e}')
        msg = '获取数据异常，未查询到结果'
    return msg


def build_system_prompt(request: ChatRequest, data: str) -> str:
    """构建 system_prompt：角色设定 + 系统日期 + DataHub 取数结果。"""
    return (
        f"{request.agent_data.role_settings}\n{get_time_msg()}\n\n"
        f"以下是从数据中台查询到的数据，请据此回答用户问题：\n{data}"
    )
