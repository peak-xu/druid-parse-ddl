from langchain_core.tools import BaseTool

from config import get_logger

from langchain.agents import create_agent
from langgraph.runtime import Runtime
from langgraph.types import Command

from agent.aisi_state import AISIState
from entity.dh_model import BaseDigitalHuman
from config.env_config import LlmFactory, LLMType
from llm_tools.multimodal_tool import get_image_metadata
from utils.prompt_loader import load_prompt

logger = get_logger(__name__)


async def multimodal_node(state: AISIState, runtime: Runtime) -> Command:
    """多模态节点：处理含图片的对话，结合图片识别与知识库作答。

    处理逻辑：
    1. 从 runtime.context 取出原始请求，按知识库 id 创建知识库检索工具。
    2. 加载图片识别提示词模板，与角色设定、系统日期拼接为 system_prompt。
    3. 用多模态模型创建 agent，绑定图片元数据工具与知识库工具。
    4. 将当前消息历史交给 agent 执行，产出回复。
    5. 通过 Command(update=...) 把新消息写回 state。
    """

    logger.info(">>> 进入 multimodal_node...")

    digital_human: BaseDigitalHuman = runtime.context['digital_human']

    tools: list[BaseTool] = digital_human.get_tools() + [get_image_metadata]
    tool_choice = digital_human.is_tool_choice()
    logger.info(f"{'必执行' if tool_choice else '可使用'}的工具：{", ".join([tool.name for tool in tools])}")

    # 加载图片识别提示词模板
    image_recognition_prompt = load_prompt("sys_image_recognition_prompt.md")
    system_prompt = f"{digital_human.system_prompt()}\n{image_recognition_prompt}"

    agent = create_agent(
        name="多模态 agent",
        model=LlmFactory.create_llm(LLMType.MULTIMODAL, stream_output=True),
        tools=tools,
        system_prompt=system_prompt,
    )
    result = await agent.ainvoke({"messages": state.messages})

    return Command(update={"messages": result["messages"]})