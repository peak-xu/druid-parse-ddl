from config import get_logger

from langchain.agents import create_agent
from langgraph.runtime import Runtime
from langgraph.types import Command

from agent.aisi_state import AISIState
from entity.dh_model import BaseDigitalHuman
from config.env_config import LlmFactory

logger = get_logger(__name__)


async def default_node(state: AISIState, runtime: Runtime) -> Command:
    """默认对话节点：构建通用 agent 处理用户提问。"""

    logger.info(">>> 进入 default_node...")

    digital_human: BaseDigitalHuman = runtime.context['digital_human']

    system_prompt = digital_human.system_prompt()

    tools = digital_human.get_tools()
    tool_choice = digital_human.is_tool_choice()
    logger.info(f"{'必执行' if tool_choice else '可使用'}的工具：{", ".join([tool.name for tool in tools])}")

    agent = create_agent(
        name="默认 agent",
        model=LlmFactory.create_llm(stream_output=True),
        tools=tools,
        system_prompt=system_prompt,
    )
    # 调用 create_agent 生成的 agent
    result = await agent.ainvoke({"messages": state.messages})

    return Command(update={"messages": result["messages"]})