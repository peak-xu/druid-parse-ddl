from config import get_logger

from langchain_core.messages import SystemMessage
from langchain_core.tools import BaseTool
from langgraph.runtime import Runtime
from langgraph.types import Command

from agent.aisi_state import AISIState
from entity.dh_model import BaseDigitalHuman
from config.env_config import LlmFactory
from entity.chat_request import ChatRequest
from utils.langchain_util import run_all_tools_forced

logger = get_logger(__name__)


async def skill_or_dataset_node(state: AISIState, runtime: Runtime) -> Command:
    """技能/数据集节点：用户 @了技能或数据集时，强制调用全部绑定工具后作答。

    处理逻辑：
    1. 从 runtime.context 取出原始请求与预处理阶段构造的工具列表。
    2. 用角色设定 + 系统日期 + 技能提示词拼接 system_prompt（仅临时拼接，不写入历史）。
    3. 将 system message 与当前消息历史组合为上下文。
    4. 调用 run_all_tools_forced 强制执行全部工具，收集工具返回消息。
    5. 把工具结果拼回上下文，调用模型生成最终回复。
    6. 仅把本轮新增的工具消息与最终回复传给 update，依赖 add_messages 追加，
       避免历史重复累积。
    """

    logger.info(">>> 进入 skill_or_dataset_node...")

    digital_human: BaseDigitalHuman = runtime.context['digital_human']

    request: ChatRequest = digital_human.get_request()

    tools: list[BaseTool] = digital_human.get_tools()
    tool_choice = digital_human.is_tool_choice()
    logger.info(f"{'必执行' if tool_choice else '可使用'}的工具：{", ".join([tool.name for tool in tools])}")

    system_prompt = (f"{digital_human.system_prompt()}\n\n"
                     f"{request.at_general_skill_info.skill_prompt}")

    context_messages = [SystemMessage(content=system_prompt)] + state.messages

    llm = LlmFactory.create_llm(stream_output=True)

    tool_messages = await run_all_tools_forced(llm, tools, context_messages)

    final_response = await llm.ainvoke(context_messages + tool_messages)

    # 关键：只把本轮新增的消息传给 update，依赖 add_messages reducer 做追加，
    # 不要把 state.messages 里已有的内容再传一遍，否则历史会重复累积
    return Command(update={"messages": tool_messages + [final_response]})