from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from psycopg import AsyncConnection

from config.env_config import PG_CHECKPOINT_URI


class PGCheckPoint:
    checkpointer: AsyncPostgresSaver | None = None

    @classmethod
    async def init_checkpointer(cls) -> AsyncPostgresSaver:
        """
        建立 PG 连接并初始化 checkpointer。
        应在应用启动时调用（lifespan）。
        """
        conn = await AsyncConnection.connect(PG_CHECKPOINT_URI, autocommit=True)
        checkpointer = AsyncPostgresSaver(conn)
        await checkpointer.setup()   # 自动建表（幂等）
        cls._checkpointer = checkpointer
        return checkpointer

    @classmethod
    async def close_checkpointer(cls) -> None:
        """应用关闭时释放连接。"""
        if cls._checkpointer is not None:
            await cls._checkpointer.conn.close()
            cls._checkpointer = None