#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

ENV_ARG="${1:-}"
if [ -z "$ENV_ARG" ]; then
    echo "错误: 缺少环境参数"
    echo "用法: $(basename "$0") {prod|dev}"
    echo "  prod -> 加载 .env"
    echo "  dev  -> 加载 .env.dev"
    exit 1
fi

case "$ENV_ARG" in
    prod|dev) ;;
    *)
        echo "错误: 无效的环境参数 '$ENV_ARG'，仅支持: prod, dev"
        echo "用法: $(basename "$0") {prod|dev}"
        exit 1
        ;;
esac

HOST="${SERVER_HOST:-${host:-0.0.0.0}}"
PORT="${SERVER_PORT:-${port:-8997}}"
LOG_DIR="$ROOT_DIR/logs"
PID_FILE="$LOG_DIR/aisi_agent.pid"
STARTUP_LOG="$LOG_DIR/startup.log"
APP_LOG_DIR="$ROOT_DIR/log"

mkdir -p "$LOG_DIR" "$APP_LOG_DIR"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
}

resolve_python_bin() {
    local candidate py_exec

    if [ -n "${PYTHON_BIN:-}" ]; then
        if "$PYTHON_BIN" -c "import sys" >/dev/null 2>&1; then
            echo "$PYTHON_BIN"
            return 0
        fi
        return 1
    fi

    if command -v py >/dev/null 2>&1; then
        py_exec="$(py -3 -c "import sys; print(sys.executable)" 2>/dev/null || true)"
        if [ -n "$py_exec" ] && "$py_exec" -c "import sys" >/dev/null 2>&1; then
            echo "$py_exec"
            return 0
        fi
    fi

    for candidate in python3 python; do
        if ! command -v "$candidate" >/dev/null 2>&1; then
            continue
        fi
        py_exec="$(command -v "$candidate")"
        if "$py_exec" -c "import sys" >/dev/null 2>&1; then
            echo "$py_exec"
            return 0
        fi
    done

    return 1
}

check_python_deps() {
    if ! "$PYTHON_BIN" -c "import dotenv, fastapi, uvicorn, langgraph, psycopg" >/dev/null 2>&1; then
        log "错误: Python 依赖未安装"
        log "请执行: \"$PYTHON_BIN\" -m pip install -r requirements.txt"
        exit 1
    fi
}

PYTHON_BIN="$(resolve_python_bin)" || {
    echo "错误: 未找到可用的 Python 解释器"
    echo "请安装 Python 3.12+，或在 Git Bash 中尝试: PYTHON_BIN=\"/c/Path/To/python.exe\" ./start.sh dev"
    exit 1
}

stop_existing_main() {
    if [ -f "$PID_FILE" ]; then
        local old_pid
        old_pid="$(cat "$PID_FILE" || true)"
        if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
            log "Stopping existing main.py process: PID=$old_pid"
            kill "$old_pid" 2>/dev/null || true
            sleep 2
            if kill -0 "$old_pid" 2>/dev/null; then
                log "Force stopping existing main.py process: PID=$old_pid"
                kill -9 "$old_pid" 2>/dev/null || true
            fi
        fi
        rm -f "$PID_FILE"
    fi
}

start_main() {
    export host="$HOST"
    export port="$PORT"

    log "Starting main.py on ${HOST}:${PORT} (env=$ENV_ARG, python=$PYTHON_BIN)"
    "$PYTHON_BIN" -u main.py "$ENV_ARG" >>"$STARTUP_LOG" 2>&1 &
    local pid=$!
    sleep 1
    if ! kill -0 "$pid" 2>/dev/null; then
        log "错误: main.py 启动失败，请查看日志: $STARTUP_LOG"
        tail -n 20 "$STARTUP_LOG" 2>/dev/null || true
        rm -f "$PID_FILE"
        exit 1
    fi
    echo "$pid" > "$PID_FILE"
    log "main.py PID: $pid"
    log "Startup log: tail -f $STARTUP_LOG"
    log "Application log: tail -f $APP_LOG_DIR/$(date '+%Y-%m-%d').log"
}

wait_health() {
    local url="http://127.0.0.1:${PORT}/health"
    for _ in $(seq 1 30); do
        if [ -f "$PID_FILE" ]; then
            local pid
            pid="$(cat "$PID_FILE" || true)"
            if [ -n "$pid" ] && ! kill -0 "$pid" 2>/dev/null; then
                log "错误: main.py 进程已退出 (PID=$pid)，请查看日志: $STARTUP_LOG"
                tail -n 20 "$STARTUP_LOG" 2>/dev/null || true
                return 1
            fi
        fi
        if curl -sf "$url" >/dev/null 2>&1; then
            log "AISI Agent Framework is ready: $url"
            return 0
        fi
        sleep 1
    done
    log "AISI Agent Framework did not become healthy in time"
    log "请查看日志: $STARTUP_LOG"
    tail -n 20 "$STARTUP_LOG" 2>/dev/null || true
    return 1
}

stop_existing_main
check_python_deps
start_main
wait_health

log "AISI Agent Framework started"
