# 提示词模板 (Prompt Templates)

本目录存放所有 LLM 提示词模板文件。

## 文件组织

- 每个提示词对应一个 `.md` 文件
- 文件名使用 `snake_case` 命名，如 `image_recognition_prompt.md`

## 使用方法

在代码中通过 `utils.prompt_loader` 加载提示词：

```python
from utils.prompt_loader import load_prompt

# 加载提示词（文件不存在时抛出异常）
prompt = load_prompt("sys_image_recognition_prompt.md")
```

## 新增提示词步骤

1. 在 `prompt_templetes/` 下创建新的 `.md` 文件
2. 在代码中使用 `load_prompt("文件名_包含扩展名")` 加载