from config import get_logger

from langchain_core.tools import tool

from config.env_config import ZSK_HOST, ZSK_API_KEY
from entity.chat_request import ChatRequest
from utils.http_util import http_client


logger = get_logger(__name__)


def create_zsk_tool(request: ChatRequest):
    """创建 zsk 检索工具，传入知识库 ID 列表"""
    knowledge_base_ids = [klg.id for klg in request.knowledge_base]
    knowledge_ids = []

    @tool
    async def zsk_tool(query: str) -> str:
        """
        通过若干关键字检索相关知识库
        Args:
            query: 若干关键字，如“上海 美食 推荐”
        Returns:
            检索到的知识
        """
        data = {
            'query': query,
            'knowledge_base_ids': knowledge_base_ids,
            'knowledge_ids': knowledge_ids,
            'match_count': 7
        }

        logger.info(f'请求知识库服务入参： {data}')

        headers = {'X-Open-Retrieve-Api-Key': ZSK_API_KEY}
        try:
            response = http_client.post(f'{ZSK_HOST}/api/v1/open/knowledge/retrieve', json=data, headers=headers)
            result = response.json()
            content_list = [item['content'] for item in result['data']]
            logger.info(f'知识库检索结果： {str(content_list)[:200]}...')
            return str(content_list)
        except RuntimeError as e:
            return '检索知识库失败'

    return zsk_tool