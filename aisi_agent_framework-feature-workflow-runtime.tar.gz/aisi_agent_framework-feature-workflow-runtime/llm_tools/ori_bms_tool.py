# """
# 使用 HttpToolBuilder.build(skills) 构建符合 langchain 规范的 BaseTool
# 即把 Skill 转为 BaseTool
# """
# from typing import Any, Callable
# from pydantic import BaseModel, Field, create_model
#
# from langchain_core.tools import StructuredTool, BaseTool
#
# from entity.chat_request import Skill, InParameter
# from utils.http_util import http_client
#
#
# class HttpToolBuilder:
#
#     type_mapping = {
#         "string": str,
#         "int": int,
#         "integer": int,
#         "float": float,
#         "double": float,
#         "bool": bool,
#         "boolean": bool,
#         "array": list,
#         "list": list,
#         "object": dict,
#         "dict": dict,
#     }
#
#     @classmethod
#     def _python_type(cls, type_name: str):
#         if not type_name:
#             return str
#         return cls.type_mapping.get(type_name.lower(), str)
#
#     @classmethod
#     def _make_invoke_fn(
#         cls,
#         method: str,
#         url: str,
#         parameter_map: dict[str, InParameter],
#     ) -> Callable:
#         """
#         返回一个绑定了 method/url/parameter_map 的 _http_invoke 闭包
#         """
#         method = method.upper()
#
#         def _http_invoke(**kwargs):
#             """
#             请求http接口
#             Args:
#                 **kwargs: 大模型生成的参数
#             """
#             req_params = {}
#             headers = {}
#             json_data = {}
#
#             for param_name, value in kwargs.items():
#                 param = parameter_map.get(param_name)
#                 if not param:
#                     continue
#                 match param.location:
#                     case "param":
#                         req_params[param_name] = value
#                     case "header":
#                         headers[param_name] = value
#                     case "body":
#                         json_data[param_name] = value
#                     case _:
#                         json_data[param_name] = value
#
#             try:
#                 match method:
#                     case "GET":
#                         response = http_client.get(url, params=req_params, headers=headers, timeout=10)
#                         return response.text
#                     case "POST":
#                         response = http_client.post(url, params=req_params, headers=headers, json=json_data, timeout=10)
#                         return response.text
#                     case _:
#                         raise RuntimeError(f"method: '{method}' unsupported!")
#             except Exception as e:
#                 return f"HTTP error: {e}"
#         return _http_invoke
#
#     @classmethod
#     def build(cls, skills: list[Skill]) -> list[BaseTool]:
#         """
#         动态生成基于http的langchain Tool列表
#
#         单次遍历 skills：
#         - 每个 skill 只遍历一次 parameters，
#           同时构建 parameter_map（供 _http_invoke 使用）和 Schema 字段（供 args_schema 使用）
#         """
#         http_tools: list[BaseTool] = []
#
#         for skill in skills:
#             in_parameters: list[InParameter] = skill.parameters.in_parameters if skill.parameters else []
#
#             parameter_map: dict[str, InParameter] = {}
#             schema_fields: dict[str, Any] = {}
#
#             for param in in_parameters:
#                 parameter_map[param.name] = param
#
#                 py_type = cls._python_type(param.type)
#                 default = ... if param.required else param.default
#                 description = param.display_name
#
#                 schema_fields[param.name] = (py_type, Field(default=default, description=description))
#
#             args_schema: type[BaseModel] = create_model(f"{skill.name}Arg", **schema_fields)
#
#             invoke_fn = cls._make_invoke_fn(
#                 method=skill.method,
#                 url=skill.url,
#                 parameter_map=parameter_map,
#             )
#
#             http_tool = StructuredTool.from_function(
#                 func=invoke_fn,
#                 name=skill.name,
#                 description=skill.description,
#                 args_schema=args_schema,
#             )
#             http_tools.append(http_tool)
#
#         return http_tools