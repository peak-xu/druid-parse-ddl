"""
使用 HttpToolBuilder.build(skills) 构建符合 langchain 规范的 BaseTool
即把 Skill 转为 BaseTool

移植自 aisi_agent_framework 的 invoke_tool 逻辑，包含：
1. Path 参数 URL 替换
2. Query 参数提取
3. Header 参数 + 公共头 (Content-Type, Authorization, rs-group-id)
4. Request Body 构建 (JSON / Form 编码)
5. 默认值逻辑 (含 date 参数保护)
6. 异步任务参数注入
7. 数据集 URL 特殊处理
"""
import json
from typing import Any, Callable, Dict
from pydantic import BaseModel, Field, create_model

from config import get_logger
from langchain_core.tools import StructuredTool, BaseTool

from entity.chat_request import Skill, InParameter
from utils.http_util import http_client

logger = get_logger(__name__)


# 大模型已提取到非空值时，不允许用 tool 默认值覆盖
_NO_OVERRIDE_DEFAULT_ARGS = frozenset({
    'begindate', 'enddate', 'period', 'DateStart', 'DateEnd', 'begin_date', 'end_date', 'date',
    'rs_user_id', 'rs_enterprise_id', 'rs_group_id', 'rs_child_enterprise_id', 'rs_menu_id', 'rs_permissions',
    'rs-user-id', 'rs-enterprise-id', 'rs-group-id', 'rs-child-enterprise-id', 'rs-menu-id', 'rs-permissions',
})


def _is_arg_empty(value: Any) -> bool:
    """判断参数值是否为空。"""
    return value is None or value == ''


def _pick_arg(args: Dict[str, Any], *keys: str) -> str:
    """按顺序从 args 取值，兼容下划线与连字符命名。"""
    for key in keys:
        v = args.get(key)
        if v is not None and v != '':
            return str(v)
    return ''


def _format_log_value(value: Any) -> str:
    """安全格式化日志值，避免循环引用或序列化失败。"""
    if value is None:
        return 'None'
    if isinstance(value, (str, int, float, bool)):
        return str(value)
    if isinstance(value, dict):
        try:
            return json.dumps(value, ensure_ascii=False, default=str)
        except Exception:
            return str(value)
    if isinstance(value, (list, tuple)):
        return f'[{len(value)} items]'
    return str(value)


class HttpToolBuilder:
    """HTTP 工具构建器，将 Skill 转换为 langchain 规范的 BaseTool。"""
    def __init__(self, group_id: str, dataset_token: str):
        self.group_id=group_id
        self.dataset_token=dataset_token

    type_mapping = {
        "string": str,
        "int": int,
        "integer": int,
        "float": float,
        "double": float,
        "bool": bool,
        "boolean": bool,
        "array": list,
        "list": list,
        "object": dict,
        "dict": dict,
    }

    @classmethod
    def _python_type(cls, type_name: str):
        """将 Skill 参数类型转换为 Python 类型。"""
        if not type_name:
            return str
        return cls.type_mapping.get(type_name.lower(), str)

    def _make_invoke_fn(self, skill: Skill, parameter_map: Dict[str, InParameter]) -> Callable:
        """
        生成 HTTP 调用函数。

        流程:
          1. 应用默认值 (跳过 LLM 已提取的非空值)
          2. 按 location 分发参数 (path/query/header/body)
          3. 替换 URL 中的 path 参数
          4. 构建请求并发送
          5. 工具结果聚合 (DataAnalyzer)
        """
        method = skill.method.upper() if skill.method else 'POST'
        original_url = skill.url or ''

        def _http_invoke(**kwargs):
            """
            调用 HTTP 接口。

            Args:
                **kwargs: 大模型生成的参数

            Returns:
                接口响应文本 (或聚合后的结果)
            """
            tool_name = skill.name
            logger.info(f'[ToolCall] 开始调用工具: {tool_name}')
            logger.info(f'[ToolCall] 原始参数：{_format_log_value(kwargs)}')
            logger.info(f'[ToolCall] URL: {original_url}, Method: {method}')

            # ── Step 1: 应用默认值 ──────────────────────────────────────────
            merged_args = dict(kwargs)
            for param_name, param in parameter_map.items():
                if not param.default or param.default in (None, '', '0', '1'):
                    continue
                # 日期参数保护：如果参数名包含 "date" 且 LLM 已提取到非空值，不替换
                if "date" in param_name.lower() and not _is_arg_empty(merged_args.get(param_name)):
                    continue
                # 白名单参数保护
                if param_name in _NO_OVERRIDE_DEFAULT_ARGS and not _is_arg_empty(merged_args.get(param_name)):
                    continue
                merged_args.setdefault(param_name, param.default)

            logger.info(f'[ToolCall] 应用默认值后：{_format_log_value(merged_args)}')

            # ── Step 2: 按 location 分发参数 ───────────────────────────────────
            query_params: Dict[str, Any] = {}
            headers: Dict[str, str] = {}
            body_params: Dict[str, Any] = {}
            final_url = original_url

            for param_name, value in merged_args.items():
                param = parameter_map.get(param_name)
                if not param:
                    continue

                loc = param.location or 'body'

                # Path 参数：替换到 URL 中
                if loc == 'path':
                    final_url = final_url.replace('{' + param_name + '}', str(value))
                    logger.info(f'[ToolCall] Path 参数替换: {{{param_name}}} -> {value}')
                # Query 参数
                elif loc == 'query':
                    query_params[param_name] = value
                # Header 参数
                elif loc == 'header':
                    headers[param_name] = str(value)
                # Body 参数 (默认)
                else:
                    body_params[param_name] = value

            # ── Step 3: 添加公共 Header ──────────────────────────────────────
            if method == 'POST':
                headers['Content-Type'] = 'application/json'

            # Authorization (dataset_token)
            dataset_token = self.dataset_token
            if dataset_token:
                headers['Authorization'] = f'Bearer {dataset_token}'

            # rs-group-id (兼容下划线和连字符)
            headers['rs-group-id'] = str(self.group_id)

            logger.info(f'[ToolCall] 最终 URL: {final_url}')
            logger.info(f'[ToolCall] Headers: {_format_log_value(headers)}')
            logger.info(f'[ToolCall] Query 参数：{_format_log_value(query_params)}')
            logger.info(f'[ToolCall] Body 参数：{_format_log_value(body_params)}')

            # ── Step 4: 数据集 URL 特殊处理 ───────────────────────────────────
            if 'ed.nxin.com' in final_url or 'ed.t.nxin.com' in final_url:
                final_url = final_url.split('?')[0]
                query_params = {}
                logger.info(f'[ToolCall] 数据集 URL 处理，清空 query 参数')

            # ── Step 5: 发送 HTTP 请求 ───────────────────────────────────────
            try:
                if method == 'GET':
                    logger.info(f'[ToolCall] 发送 GET 请求...')
                    response = http_client.get(final_url, params=query_params or None, headers=headers, timeout=30)
                elif method == 'POST':
                    logger.info(f'[ToolCall] 发送 POST 请求...')
                    response = http_client.post(
                        final_url,
                        params=query_params or None,
                        headers=headers,
                        json=body_params,
                        timeout=30
                    )
                else:
                    error_msg = f"HTTP error: unsupported method '{method}'"
                    logger.error(f'[ToolCall] {error_msg}')
                    return error_msg

                response_text = response.text
                logger.info(f'[ToolCall] 响应状态：{response.status_code}')
                logger.info(f'[ToolCall] 响应内容 (前 200 字符): {response_text[:200]}')

                return response_text

            except Exception as e:
                error_msg = f"HTTP error: {e}"
                logger.error(f'[ToolCall] 请求异常：{error_msg}')
                return error_msg

        return _http_invoke

    def build(self, skills: list[Skill]) -> list[BaseTool]:
        """
        将 Skill 列表转换为 langchain BaseTool 列表。

        Returns:
            BaseTool 列表
        """
        http_tools: list[BaseTool] = []

        for skill in skills:
            in_parameters: list[InParameter] = skill.parameters.in_parameters if skill.parameters else []

            # 构建 parameter_map 和 Pydantic schema 字段
            parameter_map: Dict[str, InParameter] = {}
            schema_fields: Dict[str, Any] = {}

            for param in in_parameters:
                parameter_map[param.name] = param

                py_type = self._python_type(param.type)
                # 必传参数用 ... (Pydantic 必填标记)，非必传用默认值
                default = ... if param.required else param.default
                description = param.display_name or param.name

                schema_fields[param.name] = (py_type, Field(default=default, description=description))

            # 创建 Pydantic schema
            args_schema: type[BaseModel] = create_model(f"{skill.name}Arg", **schema_fields)

            # 生成 HTTP 调用函数 (传入完整的 skill 对象)
            invoke_fn = self._make_invoke_fn(skill=skill, parameter_map=parameter_map)

            # 创建 StructuredTool
            http_tool = StructuredTool.from_function(
                func=invoke_fn,
                name=skill.name,
                description=skill.description,
                args_schema=args_schema,
            )
            http_tools.append(http_tool)

            logger.info(f'[ToolBuilder] 已构建工具：{skill.name}')

        logger.info(f'[ToolBuilder] 共构建 {len(http_tools)} 个工具')
        return http_tools
