from langchain_core.tools import tool

from api.api_zbt import CardAPI
from config import get_logger
from utils.time_util import get_timestamp

logger = get_logger(__name__)

def pig_consultation_card_builder(conversation_id : str):

    @tool
    def pig_consultation_card(
            symptom: str = '',
            onset_time: str = '',
            house: str = '',
            stage: str = '',
            temperature: str = '',
            remark: str = '',
            images: str = '',
    ) -> dict:
        """
        问诊信息卡片
        (未知信息可以不填)
        补充信息：
        - 猪群阶段可以分为：仔猪（0-25/28天），保育前期（28-42天），保育后期（42-70天），
        育肥前期（70-120天），育肥后期（120天-出栏），成年母猪，成年公猪
        - 调用该工具视为给用户发放一张填写卡片
        Args:
            symptom: 主要症状
            onset_time: 发病时间，格式严格要求：yyyy-MM-dd HH:mm:ss，不指名时分秒可以置为00:00:00
            house: 栋舍名称
            stage: 猪群阶段：可选值(仔猪|保育前期|保育后期|育肥前期|育肥后期|成年母猪|成年公猪)
            temperature: 体温：(单位℃)
            remark: 补充说明：如：发病头数、用药、死亡情况等和用户沟通中发现的其他详细自然语言信息，
            images: 猪病图片URL
        Returns:
            对输入参数格式化后的问诊信息数据，仅为预填写，不能视为是用户提交的信息
        """
        try:
            logger.info(f'卡片识别时间为：{onset_time}')
            onset_time = str(get_timestamp(onset_time))
            logger.info(f'卡片时间转为时间戳为：{onset_time}')
        except Exception as e:
            logger.error(f'卡片时间转为时间戳失败: {e}')
        llm_out_card = {
            "symptom": symptom,
            "onset_time": onset_time,
            "house": house,
            "stage": stage,
            "temperature": temperature,
            "remark": remark,
            "images": images,
        }
        saved_card = CardAPI.get_card(conversation_id)
        if not saved_card:
            return llm_out_card

        for k, v in llm_out_card.items():
            if v:
                saved_card[k] = v

        logger.info(f'卡片输出最终信息：{saved_card}')

        return saved_card

    return pig_consultation_card