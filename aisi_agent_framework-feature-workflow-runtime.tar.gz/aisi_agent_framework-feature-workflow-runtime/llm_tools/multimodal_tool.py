from PIL import Image
from langchain_core.tools import tool


@tool
def get_image_metadata(image_path: str) -> str:
    """根据图片路径获取图片的基础元信息（尺寸、格式、大小）。
    当需要补充图片技术细节时调用。
    """
    try:
        with Image.open(image_path) as img:
            return f"格式: {img.format}, 尺寸: {img.size}, 模式: {img.mode}"
    except Exception as e:
        return f"找不到图片文件: {image_path}"