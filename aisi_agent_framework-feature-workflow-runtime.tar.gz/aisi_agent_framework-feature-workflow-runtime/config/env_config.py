import os
import sys
from enum import Enum

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

from config import get_logger

# 根据命令行参数选择配置文件
# python main.py -> 默认加载 .env.dev (开发环境)
# python main.py dev -> 加载 .env.dev (开发环境)
# python main.py prod -> 加载 .env (生产环境)
env_mode = 'dev'  # 默认开发环境
if len(sys.argv) > 1:
    arg = sys.argv[1].lower()
    if arg == 'dev':
        env_mode = 'dev'
    elif arg == 'prod':
        env_mode = 'prod'

# 加载对应的配置文件
env_file = '.env.dev' if env_mode == 'dev' else '.env'
load_dotenv(env_file)

# 日志级别
LOG_LEVEL = os.getenv('LOG_LEVEL').upper()
logger = get_logger(__name__)

# 打印 env_mode
logger.info(f"config/env_config 初始化，当前的env_mode={env_mode}")


# PostgreSQL
PG_CHECKPOINT_URI = os.getenv('PG_CHECKPOINT_URI')

# IM
IM_MANAGE_HOST = os.getenv('IM_MANAGE_HOST')
IM_SECRET_KEY = os.getenv('IM_SECRET_KEY')

# 各数字人的IM_APP_ID
ZBT_IM_APP_ID = os.getenv('ZBT_IM_APP_ID')  # 猪病通


# MongoDB
MONGODB_HOST=os.getenv('MONGODB_HOST')
MONGODB_PORT=int(os.getenv('MONGODB_PORT'))
MONGODB_DATABASE=os.getenv('MONGODB_DATABASE')
MONGODB_USERNAME=os.getenv('MONGODB_USERNAME')
MONGODB_PASSWORD=os.getenv('MONGODB_PASSWORD')
MONGODB_AUTH_SOURCE=os.getenv('MONGODB_AUTH_SOURCE')
MONGODB_CONNECT_TIMEOUT=os.getenv('MONGODB_CONNECT_TIMEOUT')
MONGODB_SERVER_SELECTION_TIMEOUT=os.getenv('MONGODB_SERVER_SELECTION_TIMEOUT')


# DataHub 服务地址
DATAHUB_URL = os.getenv('DATAHUB_URL')


# 知识库
ZSK_HOST=os.getenv('ZSK_HOST')
ZSK_API_KEY=os.getenv('ZSK_API_KEY')

# 联网搜索
ONLINE_SEARCH_URL=os.getenv('ONLINE_SEARCH_URL')

class LLMType(str, Enum):
    BASE        = 'BASE'
    CODE        = 'CODE'
    THINKING    = 'THINKING'
    MULTIMODAL  = 'MULTIMODAL'


class LlmFactory:

    llm_base_map: dict[str, ChatOpenAI] = {}

    @classmethod
    def create_llm(
            cls,
            llm_type: LLMType = LLMType.CODE,
            stream_output: bool = False,
            for_deep_agent: bool = False,
    ) -> ChatOpenAI | str:
        """
        创建 LLM 实例。

        stream_output=False（默认）时打上 LangGraph 的 nostream 标签，
        中间节点的 LLM 结果不会进入 stream_mode="messages" 流。
        注意：nostream 对 astream_events / on_chat_model_stream 无效，
        但标签会随事件透传，因此 main.py 用它区分是否面向用户输出：
        - 默认 stream_output=False → 带 nostream → 视为中间过程小任务，不输出给用户；
        - 面向用户最终回复的调用传 stream_output=True → 不带 nostream → 输出给用户。
        """
        llm_type = llm_type.value
        model_name = os.getenv(f'{llm_type}_MODEL_NAME')
        unique_model_name = f'{model_name}_{stream_output}'

        if unique_model_name in cls.llm_base_map:
            return cls.llm_base_map[unique_model_name]

        base_url = os.getenv(f'{llm_type}_MODEL_BASE_URL')
        api_key = os.getenv(f'{llm_type}_MODEL_API_KEY', os.getenv('API_KEY'))
        temperature = 0 if llm_type == LLMType.CODE else 0.7

        logger.info(f'加载{model_name}模型, url:{base_url}')

        if for_deep_agent:
            os.environ["OPENAI_BASE_URL"] = base_url
            os.environ["OPENAI_API_KEY"] = api_key
            return f"openai:{model_name}"

        llm = ChatOpenAI(
            model=model_name,
            base_url=base_url,
            api_key=api_key,
            temperature=temperature
        )
        if not stream_output:
            llm = llm.with_config({"tags": ["nostream"]})

        cls.llm_base_map[unique_model_name] = llm
        return llm