"""配置模块初始化 - 导入时自动初始化日志系统"""
import os

# 初始化日志系统（必须在其他模块之前加载）
from config.logger_config import setup_logging, get_logger

# 获取日志级别，默认为 INFO（直接从环境变量读取，避免循环导入）
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO').upper()

# 使用绝对路径，确保日志文件保存在项目根目录的 log/ 文件夹
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
setup_logging(log_dir=os.path.join(BASE_DIR, 'log'), log_level=LOG_LEVEL)

__all__ = ['setup_logging', 'get_logger', 'BASE_DIR']