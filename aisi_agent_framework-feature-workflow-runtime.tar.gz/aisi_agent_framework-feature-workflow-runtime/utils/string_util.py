import uuid


def get_prompt_template(template_name: str) -> str:
    with open(f'../prompt_templates/{template_name}', 'r', encoding='utf-8') as f:
        return f.read()


def get_uuid() -> str:
    return str(uuid.uuid4()).replace('-', '').upper()