"""MongoDB工具类"""
from typing import Dict, List, Any, Optional, Union
from datetime import datetime

from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database
from pymongo.errors import DuplicateKeyError
from bson import ObjectId

from config.env_config import *

logger = get_logger(__name__)

class MongoDBUtil:
    
    def __init__(self):
        self._client: Optional[MongoClient] = None
        self._db: Optional[Database] = None
    
    def _initialize(self):
        """初始化MongoDB连接"""
        if self._client is None:
            self._client = MongoClient(
                host=MONGODB_HOST,
                port=MONGODB_PORT,
                username=MONGODB_USERNAME,
                password=MONGODB_PASSWORD,
                authSource=MONGODB_AUTH_SOURCE,
                connectTimeoutMS=MONGODB_CONNECT_TIMEOUT,
                serverSelectionTimeoutMS=MONGODB_SERVER_SELECTION_TIMEOUT
            )
            self._db = self._client[MONGODB_DATABASE]

    def _handle_object_id(self, filter_dict: Dict[str, Any]) -> Dict[str, Any]:
        """自动将 _id（含 $in）转为 ObjectId"""
        if '_id' in filter_dict:
            value = filter_dict['_id']
            if isinstance(value, str):
                filter_dict['_id'] = ObjectId(value)
            elif isinstance(value, dict) and '$in' in value:
                new_in = [ObjectId(v) for v in value['$in']]
                filter_dict['_id']['$in'] = new_in
        return filter_dict

    def _convert_object_ids(self, documents):
        if isinstance(documents, list):
            for doc in documents:
                if '_id' in doc:
                    doc['id'] = str(doc.pop('_id'))
        elif isinstance(documents, dict) and '_id' in documents:
            documents['id'] = str(documents.pop('_id'))
        return documents

    
    def get_collection(self, collection_name: str) -> Collection:
        if self._db is None:
            try:
                self._initialize()
            except Exception as e:
                raise RuntimeError("数据库连接未建立")
        return self._db[collection_name]
    
    def insert_one(self, collection_name: str, document: Dict[str, Any]) -> str:
        try:
            collection = self.get_collection(collection_name)
            # 添加创建时间和修改时间
            now = self._get_current_time()
            document['create_time'] = now
            document['update_time'] = now
            result = collection.insert_one(document)
            logger.info(f"文档插入成功: {collection_name}, ID: {result.inserted_id}")
            return str(result.inserted_id)
        except DuplicateKeyError as e:
            logger.error(f"文档插入失败，重复键错误: {e}")
            raise
        except Exception as e:
            logger.error(f"文档插入失败: {e}")
            raise
    
    def insert_many(self, collection_name: str, documents: List[Dict[str, Any]]) -> List[str]:
        try:
            collection = self.get_collection(collection_name)
            # 为所有文档添加创建时间和修改时间
            now = self._get_current_time()
            for doc in documents:
                doc['create_time'] = now
                doc['update_time'] = now
            result = collection.insert_many(documents)
            inserted_ids = [str(id) for id in result.inserted_ids]
            logger.info(f"批量插入成功: {collection_name}, 数量: {len(inserted_ids)}")
            return inserted_ids
        except Exception as e:
            logger.error(f"批量插入失败: {e}")
            raise
    
    def find_one(self, collection_name: str, filter_dict: Dict[str, Any] = None, 
                 projection: Dict[str, int] = None) -> Optional[Dict[str, Any]]:
        try:
            collection = self.get_collection(collection_name)
            filter_dict = self._handle_object_id(filter_dict or {})
            result = collection.find_one(filter_dict, projection)
            return self._convert_object_ids(result) if result else None
        except Exception as e:
            logger.error(f"查询单个文档失败: {e}")
            raise
    
    def find_many(self, collection_name: str, filter_dict: Dict[str, Any] = None,
                  projection: Dict[str, int] = None, limit: int = None,
                  skip: int = None, sort: List[tuple] = None) -> List[Dict[str, Any]]:
        try:
            collection = self.get_collection(collection_name)
            filter_dict = self._handle_object_id(filter_dict or {})
            cursor = collection.find(filter_dict, projection)
            # 默认按修改时间倒序排序，如果指定了sort参数则使用指定的排序
            if sort:
                cursor = cursor.sort(sort)
            else:
                cursor = cursor.sort([('update_time', -1)])
            if skip:
                cursor = cursor.skip(skip)
            if limit:
                cursor = cursor.limit(limit)

            results = list(cursor)
            return self._convert_object_ids(results)
        except Exception as e:
            logger.error(f"查询多个文档失败: {e}")
            raise

    def page_list(self, collection_name: str, filter_dict: Dict[str, Any] = None,
                  projection: Dict[str, int] = None, limit: int = None, skip: int = None, sort: List[tuple] = None
                  ) -> tuple[int,List[Dict[str, Any]]]:
        results = self.find_many(collection_name, filter_dict, projection, limit, skip, sort)
        collection = self.get_collection(collection_name)
        filter_dict = self._handle_object_id(filter_dict or {})
        total = collection.count_documents(filter_dict)
        return total, results


    def replace_one(self, collection_name: str, filter_dict: Dict[str, Any],
                    replacement: Dict[str, Any], upsert: bool = False) -> int:
        """替换单个文档（完全覆盖，旧字段会被清空）"""
        try:
            collection = self.get_collection(collection_name)
            filter_dict = self._handle_object_id(filter_dict)
            
            # 更新修改时间，保留创建时间
            now = self._get_current_time()
            if upsert:
                # 如果是upsert操作，可能是新建，需要设置创建时间
                if 'create_time' not in replacement:
                    replacement['create_time'] = now
                replacement['update_time'] = now
            else:
                # 如果是替换操作，保留原有的创建时间
                existing_doc = collection.find_one(filter_dict)
                if existing_doc and 'create_time' in existing_doc:
                    replacement['create_time'] = existing_doc['create_time']
                replacement['update_time'] = now

            result = collection.replace_one(filter_dict, replacement, upsert=upsert)
            logger.info(
                f"文档替换成功: {collection_name}, 匹配: {result.matched_count}, 修改: {result.modified_count}"
            )
            return result.modified_count
        except Exception as e:
            logger.error(f"替换文档失败: {e}")
            raise

    
    def update_one(self, collection_name: str, filter_dict: Dict[str, Any], 
                   update_dict: Dict[str, Any], upsert: bool = False) -> int:
        try:
            collection = self.get_collection(collection_name)
            filter_dict = self._handle_object_id(filter_dict)
            
            if not any(key.startswith('$') for key in update_dict.keys()):
                update_dict = {'$set': update_dict}

            now = self._get_current_time()
            # 添加修改时间
            if '$set' not in update_dict:
                update_dict['$set'] = {}
            update_dict['$set']['update_time'] = now

            # 如果是upsert操作，设置创建时间
            if upsert:
                if '$setOnInsert' not in update_dict:
                    update_dict['$setOnInsert'] = {}
                update_dict['$setOnInsert']['create_time'] = now

            result = collection.update_one(filter_dict, update_dict, upsert=upsert)
            logger.info(f"文档更新成功: {collection_name}, 匹配: {result.matched_count}, 修改: {result.modified_count}")
            return result.modified_count
        except Exception as e:
            logger.error(f"更新文档失败: {e}")
            raise
    
    def update_many(self, collection_name: str, filter_dict: Dict[str, Any], 
                    update_dict: Dict[str, Any], upsert: bool = False) -> int:
        try:
            collection = self.get_collection(collection_name)
            
            if not any(key.startswith('$') for key in update_dict.keys()):
                update_dict = {'$set': update_dict}

            now = self._get_current_time()
            # 添加修改时间
            if '$set' not in update_dict:
                update_dict['$set'] = {}
            update_dict['$set']['update_time'] = now

            # 如果是upsert操作，设置创建时间
            if upsert:
                if '$setOnInsert' not in update_dict:
                    update_dict['$setOnInsert'] = {}
                update_dict['$setOnInsert']['create_time'] = now

            result = collection.update_many(filter_dict, update_dict, upsert=upsert)
            logger.info(f"批量更新成功: {collection_name}, 匹配: {result.matched_count}, 修改: {result.modified_count}")
            return result.modified_count
        except Exception as e:
            logger.error(f"批量更新失败: {e}")
            raise

    def delete_one(self, collection_name: str, filter_dict: Dict[str, Any]) -> int:
        try:
            collection = self.get_collection(collection_name)
            filter_dict = self._handle_object_id(filter_dict)
            result = collection.delete_one(filter_dict)
            logger.info(f"文档删除成功: {collection_name}, 删除数量: {result.deleted_count}")
            return result.deleted_count
        except Exception as e:
            logger.error(f"删除文档失败: {e}")
            raise

    def delete_many(self, collection_name: str, filter_dict: Dict[str, Any]) -> int:
        try:
            collection = self.get_collection(collection_name)
            result = collection.delete_many(filter_dict)
            logger.info(f"批量删除成功: {collection_name}, 删除数量: {result.deleted_count}")
            return result.deleted_count
        except Exception as e:
            logger.error(f"批量删除失败: {e}")
            raise

    def count_documents(self, collection_name: str, filter_dict: Dict[str, Any] = None) -> int:
        try:
            collection = self.get_collection(collection_name)
            return collection.count_documents(filter_dict or {})
        except Exception as e:
            logger.error(f"统计文档数量失败: {e}")
            raise

    def create_index(self, collection_name: str, index_spec: Union[str, List[tuple]],
                     unique: bool = False, background: bool = True) -> str:
        try:
            collection = self.get_collection(collection_name)
            index_name = collection.create_index(index_spec, unique=unique, background=background)
            logger.info(f"索引创建成功: {collection_name}, 索引名: {index_name}")
            return index_name
        except Exception as e:
            logger.error(f"创建索引失败: {e}")
            raise

    @staticmethod
    def _get_current_time():
        now = datetime.now()  # 获取当前时间
        return now.strftime("%Y-%m-%d %H:%M:%S")
    
    def drop_collection(self, collection_name: str):
        try:
            collection = self.get_collection(collection_name)
            collection.drop()
            logger.info(f"集合删除成功: {collection_name}")
        except Exception as e:
            logger.error(f"删除集合失败: {e}")
            raise
    
    def list_collections(self) -> List[str]:
        try:
            if self._db is None:
                raise RuntimeError("数据库连接未建立")
            return self._db.list_collection_names()
        except Exception as e:
            logger.error(f"获取集合列表失败: {e}")
            raise
    
    def close(self):
        if self._client:
            self._client.close()
            logger.info("MongoDB连接已关闭")
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# 模块级别实例，可直接调用方法
mongo = MongoDBUtil()