import httpx
from httpx._client import Client

http_client: Client = httpx.Client(timeout=10)
