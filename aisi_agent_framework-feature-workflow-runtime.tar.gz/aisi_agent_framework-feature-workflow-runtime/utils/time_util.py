from datetime import datetime, date, timedelta


def get_current_time_seq() -> str:
    """获取当前时间并输出包含时间、星期几和季度信息的句子"""
    now = datetime.now() # 获取当前时间
    current_time = now.strftime("%Y年%m月%d日%H时%M分%S秒") # 格式化时间（精确到秒）
    num_zh = ["一", "二", "三", "四", "五", "六", "日"] # 中文数字映射
    weekday = num_zh[now.weekday()] # 获取星期几（中文）
    quarter = num_zh[(now.month - 1) // 3] # 计算季度
    return f"现在是{current_time}，星期{weekday}，当前处于第{quarter}季度"


def get_current_time() -> str:
    now = datetime.now()  # 获取当前时间
    return now.strftime("%Y-%m-%d %H:%M:%S")


def get_time_msg() -> str:
    return f"当前系统日期: {date.today().strftime('%Y-%m-%d')}，按需使用。"


def get_timestamp(specify_time: str = '') -> int:
    """
    获取时间戳
    Args:
        specify_time: 指定日期 格式：yyyy-MM-dd HH:mm:ss
    Returns:

    """
    if specify_time:
        return int(datetime.strptime(specify_time, "%Y-%m-%d %H:%M:%S").timestamp() * 1000)
    return int(datetime.now().timestamp() * 1000)


def get_date_range(period: str) -> tuple[str, str]:
    """
    根据时间段标识返回 start_time, end_time，格式与 MongoDB create_time 一致：YYYY-MM-DD HH:MM:SS
    period: today / week / month / last_month / all
    返回空字符串表示不筛选
    """
    now = datetime.now()
    today = now.date()

    if period == 'today':
        start = datetime.combine(today, datetime.min.time())
        end = datetime.combine(today, datetime.max.time())
    elif period == 'week':
        # 本周一到今天结束
        monday = today - timedelta(days=today.weekday())
        start = datetime.combine(monday, datetime.min.time())
        end = datetime.combine(today, datetime.max.time())
    elif period == 'month':
        # 本月1号到今天结束
        start = datetime.combine(today.replace(day=1), datetime.min.time())
        end = datetime.combine(today, datetime.max.time())
    elif period == 'last_month':
        # 上月1号到上月最后一天
        first_of_this_month = today.replace(day=1)
        last_of_prev_month = first_of_this_month - timedelta(days=1)
        first_of_prev_month = last_of_prev_month.replace(day=1)
        start = datetime.combine(first_of_prev_month, datetime.min.time())
        end = datetime.combine(last_of_prev_month, datetime.max.time())
    elif period == 'all':
        return '', ''
    else:
        return '', ''

    return start.strftime("%Y-%m-%d %H:%M:%S"), end.strftime("%Y-%m-%d %H:%M:%S")