"""
提示词加载工具

从 prompt_templetes/ 目录加载提示词模板。
"""
from pathlib import Path

# 提示词模板目录
PROMPT_TEMPLATE_DIR = Path(__file__).parent.parent / "prompt_templetes"


def load_prompt(prompt_name: str) -> str:
    """
    加载提示词模板。

    Args:
        prompt_name: 提示词文件名，如 "sys_image_recognition_prompt.md"

    Returns:
        提示词内容

    Raises:
        FileNotFoundError: 提示词文件不存在
    """
    prompt_file = PROMPT_TEMPLATE_DIR / f"{prompt_name}"
    if not prompt_file.exists():
        raise FileNotFoundError(f"提示词文件不存在：{prompt_file}")
    return prompt_file.read_text(encoding="utf-8")