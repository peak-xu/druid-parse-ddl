"""
群聊工具封装

提供以下功能：
1. 创建群
2. 发送自定义消息
"""

import hashlib
import json

from config import get_logger
from config.env_config import IM_MANAGE_HOST, IM_SECRET_KEY
from utils.http_util import http_client
from utils.time_util import get_timestamp

logger = get_logger(__name__)

class IMUtil:

    def __init__(self, app_id: str):
        self.app_id = app_id
        self.create_group_url = f"{IM_MANAGE_HOST}/api/s1/serve/group/v1/create/3"
        self.send_msg_url = f"{IM_MANAGE_HOST}/api/s1/serve/message/v1/send"

    @staticmethod
    def _generate_access_token() -> tuple[str, str]:
        """
        生成时间戳和访问令牌。
        """
        timestamp = str(get_timestamp())
        token_string = f"{IM_SECRET_KEY}{timestamp}"
        access_token = hashlib.md5(token_string.encode()).hexdigest()
        return timestamp, access_token

    def _headers(self) -> dict:
        timestamp, access_token = self._generate_access_token()
        return {
            "appId": self.app_id,
            "timestamp": timestamp,
            "accessToken": access_token,
            "Content-Type": "application/json"
        }

    def create_group(
        self,
        conversation_id: str,
        group_name: str,
        owner_user_id: int,
        friend_user_id: int,
        ai_user_id: str = '086000200044',
    ) -> dict:
        """
        创建群。

        Args:
            conversation_id: 会诊 ID
            owner_user_id: 发起者 ID
            friend_user_id: 添加群成员 ID
            ai_user_id: AI 系统号 userID（可选，不传则不包含 AI 成员）
            group_name: 群名称（默认"群聊"）

        Returns:
            dict: 包含 groupID、groupName 等群信息

        Raises:
            ValueError: 参数验证失败
            httpx.HTTPError: 请求失败
        """
        # 构建请求体
        member_users = [
            {"archiveId": friend_user_id}
        ]

        # 如果提供了 AI userID，添加到成员列表
        if ai_user_id:
            member_users.append({
                "userType": 2,
                "userID": ai_user_id
            })

        body = {
            "appId": self.app_id,
            "relatedId": conversation_id,
            "ownerUser": {
                "archiveId": owner_user_id
            },
            "memberUsers": member_users,
            "groupInfo": {
                "groupName": group_name,
                "introduction": "",  # 群介绍
                "needVerification": 2,  # 直接进群
                "lookMemberInfo": 0,    # 允许看成员
                "applyMemberFriend": 0  # 允许互加好友
            }
        }

        # 发送请求
        logger.info(f"创建群聊：{group_name}, conversation_id={conversation_id}")

        response = http_client.post(self.create_group_url, headers=self._headers(), json=body, timeout=30)

        result = response.json()

        if result.get("code") != 0:
            logger.error(f"创建群聊失败：{result}")
            raise ValueError(f"创建群聊失败：{result.get('msg')}")

        logger.info(f"创建群聊成功：{result.get('data', {}).get('groupID')}")
        return result.get("data", {})


    def send_message(
        self,
        group_id: str,
        send_user_id: str,
        data: dict,
        description: str = "",
        custom_type: int = 2003,
        session_type: int = 3,
        is_online_only: bool = False,
        not_offline_push: bool = True
    ) -> dict:
        """
        向指定群发送自定义消息。

        Args:
            group_id: 群组 ID
            send_user_id: 发送者 userID（通常为 AI 系统号 userID）
            data: 消息数据内容
            description: 客户端摘要（如"会诊通知"）
            custom_type: 自定义消息类型
                - 2000: 公共号/业务通知（业务主动向群/单聊发通知）
                - 2001: AI 公共号上行
                - 2002: chatbot AI 回复（@AI 自动投递，业务一般不调）
            session_type: 会话类型
                - 1: 单聊
                - 3: 群聊（默认）
                - 4: 系统通知
            is_online_only: 是否仅在线可达
            not_offline_push: 是否跳过离线推送

        Returns:
            dict: 包含 serverMsgID、sendTime 等消息信息

        Raises:
            ValueError: 参数验证失败
            httpx.HTTPError: 请求失败
        """
        # 构建自定义消息内容
        custom_content = {
            "customType": custom_type,
            "data": data
        }

        # 构建请求体
        body = {
            "sendArchiveId": send_user_id,
            "groupID": group_id,
            "sessionType": session_type,
            "contentType": 110,  # 自定义消息
            "content": {
                "data": json.dumps(custom_content, ensure_ascii=False),
                "description": description,
                "extension": ""
            },
            "isOnlineOnly": is_online_only,
            "notOfflinePush": not_offline_push
        }

        # 发送请求
        logger.info(f"发送自定义消息到群 {group_id}, customType={custom_type}")

        response = http_client.post(self.send_msg_url, headers=self._headers(), json=body, timeout=30)

        result = response.json()

        if result.get("code") != 0:
            logger.error(f"发送自定义消息失败：{result}")
            raise ValueError(f"发送自定义消息失败：{result.get('msg')}")

        logger.info(f"自定义消息发送成功：{result.get('data', {}).get('serverMsgID')}")
        return result.get("data", {})


    # def register_notification_account(
    #     business_id: str,
    #     business_type: int = 2,
    #     app_manager_level: int = 4,
    #     nick_name: str = "AI 助手",
    #     face_url: str = "",
    #     im_manage_host: Optional[str] = None,
    #     app_id: Optional[int] = None,
    #     secret_key: Optional[str] = None
    # ) -> str:
    #     """
    #     注册通知账号（AI 系统号）。
    #
    #     注意：此接口只需调用一次，注册后获取的 userID 可复用。
    #
    #     Args:
    #         business_id: 业务 ID（如 "pig_disease_ai"）
    #         business_type: 业务类型（默认 2）
    #         app_manager_level: 应用管理级别（默认 4）
    #         nick_name: 昵称
    #         face_url: 头像 URL
    #         im_manage_host: IM 服务地址（可选，不传则从配置读取）
    #         app_id: 应用 ID（可选，不传则从配置读取）
    #         secret_key: 密钥（可选，不传则从配置读取）
    #
    #     Returns:
    #         str: 注册成功后返回的 userID
    #
    #     Raises:
    #         ValueError: 注册失败
    #         httpx.HTTPError: 请求失败
    #     """
    #     if im_manage_host is None:
    #         im_manage_host, app_id, secret_key = _get_im_config()
    #
    #     # 生成鉴权令牌
    #     access_token, timestamp = _generate_access_token(secret_key)
    #
    #     # 构建请求头
    #     headers = {
    #         "appId": str(app_id),
    #         "timestamp": timestamp,
    #         "accessToken": access_token,
    #         "Content-Type": "application/json"
    #     }
    #
    #     # 构建请求体
    #     body = {
    #         "businessId": business_id,
    #         "businessType": business_type,
    #         "appMangerLevel": app_manager_level,
    #         "nickName": nick_name,
    #         "faceURL": face_url
    #     }
    #
    #     # 发送请求
    #     url = f"{im_manage_host}/api/s1/serve/notification-account/v1/add"
    #     logger.info(f"注册通知账号：{business_id}")
    #
    #     response = httpx.post(url, headers=headers, json=body, timeout=30)
    #
    #     result = response.json()
    #
    #     if result.get("code") != 0:
    #         logger.error(f"注册通知账号失败：{result}")
    #         raise ValueError(f"注册通知账号失败：{result.get('data', '未知错误')}")
    #
    #     user_id = result.get("data", {}).get("userID")
    #     logger.info(f"通知账号注册成功：{user_id}")
    #     return user_id
