from config import get_logger

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, ToolMessage, ToolCall
from langchain_core.tools import BaseTool


logger = get_logger(__name__)


async def _force_call_tool(
    llm: BaseChatModel,
    tool: BaseTool,
    context_messages: list[BaseMessage],
) -> tuple[ToolCall | None, str | None]:
    """
    强制模型调用指定的单个工具，并实际执行该工具。

    返回 (tool_call, result)：
    - 如果模型成功给出 tool_call 并执行成功，返回 (call, str(result))
    - 如果模型未返回 tool_calls，或工具执行失败，返回 (None, None) / (call, 错误信息)
    """
    llm_forced = llm.bind_tools([tool], tool_choice=tool.name)
    ai_msg = await llm_forced.ainvoke(context_messages)

    if not ai_msg.tool_calls:
        logger.warning(f"{tool.name} 强制调用未返回 tool_calls，跳过")
        return None, None

    call = ai_msg.tool_calls[0]  # 强制单工具，理论上只有一个
    logger.info(f"=== {tool.name} 抽取的参数 ===\n{call['args']}")

    try:
        result = await tool.ainvoke(call["args"])
    except Exception as e:
        logger.exception(f"{tool.name} 执行失败")
        result = f"工具 {tool.name} 执行出错: {e}"

    logger.info(f"=== {tool.name} 执行结果 ===\n{result}")

    return call, str(result)


async def run_all_tools_forced(
    llm: BaseChatModel,
    tools: list[BaseTool],
    context_messages: list[BaseMessage],
) -> list[BaseMessage]:
    """
    依次强制调用所有工具，并把调用+结果组装成可追加进对话历史的消息列表。
    若没有任何工具成功调用，返回空列表。
    """
    all_tool_calls = []
    all_tool_results = []

    for tool in tools:
        call, result = await _force_call_tool(llm, tool, context_messages)
        if call is None:
            continue
        all_tool_calls.append(call)
        all_tool_results.append((call["id"], result))

    if not all_tool_calls:
        return []

    messages: list[BaseMessage] = [AIMessage(content="", tool_calls=all_tool_calls)]
    for call_id, result in all_tool_results:
        messages.append(ToolMessage(content=result, tool_call_id=call_id))

    return messages