from config.env_config import ZSK_API_KEY, ZSK_HOST, ONLINE_SEARCH_URL
from utils.http_util import http_client
from config import get_logger

logger = get_logger(__name__)

class KnowledgeRetrieverUtil:
    """知识库检索工具"""

    @staticmethod
    async def zsk_retriever(
        query: str,
        knowledge_base_ids: list[str],
        knowledge_ids: list[str],
    ) -> str:
        method_name = 'zsk_retriever'
        logger.info(
            f"[{method_name}] 入参: query={query}, "
            f"knowledge_base_ids={knowledge_base_ids}, knowledge_ids={knowledge_ids}"
        )
        data = {
            'query': query,
            'knowledge_base_ids': knowledge_base_ids,
            'knowledge_ids': knowledge_ids,
            'match_count': 7,
        }
        headers = {'X-Open-Retrieve-Api-Key': ZSK_API_KEY}
        result = ''
        try:
            response = http_client.post(
                f'{ZSK_HOST}/api/v1/open/knowledge/retrieve',
                json=data,
                headers=headers,
            )
            result = response.json()
            content_list = [item['content'] for item in result['data']]
            content_str = str(content_list)
            logger.info(f"[{method_name}] 调用结果: {content_str}")
            return content_str
        except Exception as e:
            logger.exception(
                f"[{method_name}] 调用异常: {type(e).__name__}: {e}, raw_result={result}"
            )
            return None

    """联网检索"""
    @staticmethod
    async def online_search(
            query: str
    ) -> str:
        method_name = 'online_search'
        logger.info(f"[{method_name}] 入参: query={query}")
        try:
            data = {
                'question': query
            }
            response = http_client.post(
                f'{ONLINE_SEARCH_URL}',
                json=data
            )
            result = response.json()
            content_list = [item['content'] for item in result['data']]
            content_str = str(content_list)
            logger.info(f"[{method_name}] 调用结果: {content_str}")
            return content_str
        except Exception as e:
            logger.exception(f"[{method_name}] 调用异常: {type(e).__name__}: {e}")
            return None
