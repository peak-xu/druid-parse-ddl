import json
from enum import Enum

from entity.chat_request import ChatRequest


class EventType(str, Enum):
    """事件类型枚举"""
    GENERATING      = 'generating'
    CAPTION_SEARCH  = 'caption_search'
    CAPTION         = 'caption'
    PLUGIN          = 'plugin'
    REPLY           = 'reply'
    CAPTION_GENERATING = 'captionGenerating'
    CAPTION_REASONING = 'captionReasoning'
    TOOL_RESULT     = 'tool_result'

    START = 'start'
    END = 'end'


class StreamResponseGenerator:
    """SSE 流式响应生成器。

    将 AI 输出内容格式化为 SSE 事件的 JSON 字符串。
    支持多种事件类型（生成中/字幕搜索/字幕/插件/最终回复/推理链），
    客户端根据 type 字段区分处理。
    """

    def __init__(self, request: ChatRequest):
        self.feedback_id = request.feedback_id
        self.conversation_id = request.conversation_id or ''
        self.question_id = request.feedback_id.split("#")[-1]
        self.last_type = None
        self.caption_search = ''
        self.captions = []
        self.temp_caption_reason = ''
        self.caption_reasons = []


    def start(self, start_time):
        return json.dumps({
            "type": EventType.START,
            "time": int(start_time),
            "feedback_id": self.feedback_id,
            "question_id": self.question_id,
            "conversation_id": self.conversation_id}
        ) + "\n\n"


    def end(self, time, tk_count):
        return json.dumps({
            'type': EventType.END,
            'time': time,
            'feedback_id': self.feedback_id,
            'question_id': self.question_id,
            'conversation_id': self.conversation_id,
            'token_total': tk_count,
        }) + '\n\n'


    def output(self, content: str, current_type: EventType=EventType.GENERATING, extra_info: dict=None):
        self._record_reply(content, current_type)
        self.last_type = current_type
        # 输出当前type的内容
        return self._create_content_chunk(content, current_type, extra_info)


    def _create_content_chunk(self, content: str, current_type: EventType, extra_info: dict=None):
        response_data = {
            "type": current_type,
            "feedback_id": self.feedback_id,
            "conversation_id": self.conversation_id,
            "content": content,
            "content_type": "markdown" if current_type == EventType.REPLY else "text",
        }
        if extra_info:
            response_data.update(extra_info)
        return json.dumps(response_data, ensure_ascii=False) + '\n\n'


    def _record_reply(self, content: str, current_type: EventType):
        if current_type == EventType.CAPTION_SEARCH:
            self.caption_search = content
        if current_type == EventType.CAPTION:
            self.captions.append(content)
        self._record_caption_reason(content, current_type)


    def _record_caption_reason(self, content, current_type):
        if current_type == EventType.CAPTION_GENERATING and self.last_type in [EventType.CAPTION, EventType.CAPTION_GENERATING]:
            self.temp_caption_reason += content
        elif current_type != EventType.CAPTION_GENERATING and self.last_type == EventType.CAPTION_GENERATING:
            self.caption_reasons.append(self.temp_caption_reason)
            self.temp_caption_reason = ''


    def reply(self, title: str='', llm_ans: str='', final_msg: str='', file_url: str=''):
        reply_content = f"""
        <caption>
            {''.join([f'<caption_item reasoning="{reason}">{caption}</caption_item>' 
                      for caption, reason in zip(self.captions, self.caption_reasons)])}
        </caption>
        <plugin>
            <title>{title}</title>{llm_ans}
        </plugin>
        {final_msg}
        {f'<file_url>{file_url}</file_url>' if file_url else ''}"""
        return self._create_content_chunk(reply_content, EventType.REPLY)
