"""
LangGraph 会话管理 —— 查看 conversation 的消息与工具调用
"""
from fastapi import APIRouter, Request, Query
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage, SystemMessage
from langgraph.graph.state import CompiledStateGraph

from config import get_logger
from entity.api_response import APIResponse

bg_router = APIRouter(prefix='/bg')

logger = get_logger(__name__)


def _serialize_message(msg) -> dict:
    """将 LangChain message 序列化为前端可读的 dict"""
    role = msg.type  # 'human', 'ai', 'tool', 'system'
    content = msg.content if isinstance(msg.content, str) else str(msg.content)

    result = {
        'role': role,
        'content': content,
    }

    # AIMessage 可能携带 tool_calls
    if isinstance(msg, AIMessage) and msg.tool_calls:
        result['tool_calls'] = [
            {
                'id': tc.get('id', ''),
                'name': tc.get('name', ''),
                'args': tc.get('args', {}),
            }
            for tc in msg.tool_calls
        ]

    # ToolMessage 回复某个 tool_call
    if isinstance(msg, ToolMessage):
        result['tool_call_id'] = msg.tool_call_id
        result['name'] = msg.name or ''

    # HumanMessage 可能有附加信息
    if isinstance(msg, HumanMessage):
        if msg.name:
            result['name'] = msg.name

    # 通用：附加 id 和 metadata
    if msg.id:
        result['id'] = msg.id

    return result


def _serialize_state(state) -> dict:
    """将 LangGraph StateSnapshot 序列化"""
    values = state.values or {}
    messages = values.get('messages', [])

    serialized = {
        'messages': [_serialize_message(m) for m in messages],
        'next': state.next or [],
        'metadata': state.metadata or {},
    }

    # 附加其他 state 字段
    for key in ('tool_choice', 'enable_thinking', 'enable_web_search', 'upload_image', 'classify_type'):
        if key in values:
            serialized[key] = values[key]

    return serialized


@bg_router.get("/conversation/{conversation_id}", description='查看会话详情（消息+工具调用）')
async def get_conversation(conversation_id: str, req: Request):
    """获取指定 conversation_id 的当前会话状态"""
    try:
        workflow: CompiledStateGraph = req.app.state.workflow
        config = {"configurable": {"thread_id": conversation_id}}
        state = await workflow.aget_state(config)
        if not state or not state.values:
            return APIResponse.fail('会话不存在或无数据')
        return APIResponse.succeed(_serialize_state(state))
    except Exception as e:
        logger.error(f'获取会话详情失败：{e}')
        return APIResponse.fail(f'获取会话详情失败：{str(e)}')


@bg_router.get("/conversation/{conversation_id}/history", description='查看会话状态历史')
async def get_conversation_history(
        conversation_id: str,
        req: Request,
        limit: int = Query(default=10, description='返回条数'),
):
    """获取指定 conversation_id 的状态变更历史（每一步的 snapshot）"""
    try:
        workflow: CompiledStateGraph = req.app.state.workflow
        config = {"configurable": {"thread_id": conversation_id}}
        history_states = []
        async for state in workflow.aget_state_history(config):
            history_states.append(_serialize_state(state))
            if len(history_states) >= limit:
                break
        return APIResponse.succeed(history_states)
    except Exception as e:
        logger.error(f'获取会话历史失败：{e}')
        return APIResponse.fail(f'获取会话历史失败：{str(e)}')
