"""
猪病通
"""
import json
from typing import Literal
from uuid import uuid4

from fastapi import APIRouter, Query, Body, Request
from langchain_core.messages import HumanMessage, AnyMessage, AIMessage
from langgraph.graph.state import CompiledStateGraph
from pydantic import BaseModel, Field

from config import get_logger
from config.env_config import LlmFactory, ZBT_IM_APP_ID
from entity.api_response import APIResponse
from utils.db_mongo import mongo
from utils.group_chat_util import IMUtil
from utils.prompt_loader import load_prompt
from utils.time_util import get_date_range, get_timestamp

zbt_router = APIRouter(prefix='/zbt')

logger = get_logger(__name__)

DEFAULT_DIAGNOSE_STATUS = '1'

class VetAPI:
    """
    兽医管理
    """
    COLLECTION_NAME = 'zbt_vet'

    class Vet(BaseModel):
        vet_id: str = Field(description='兽医id')
        vet_name: str = Field(description='兽医姓名')
        domain: str = Field(default='', description='擅长领域')
        experience_year: str = Field(default='', description='从业年限')
        detail_introduction: str = Field(default='', description='简介')

    @staticmethod
    @zbt_router.post("/vet", description='新增兽医')
    async def save(vet: Vet):
        try:
            mongo.insert_one(VetAPI.COLLECTION_NAME, vet.model_dump())
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'新增兽医失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/vet", description='获取兽医列表')
    async def page(
        page_num: int = Query(default=1, description='当前页'),
        page_size: int = Query(default=10, description='每页显示条数'),
    ):
        try:
            skip = (page_num - 1) * page_size
            total, list_data = mongo.page_list(
                collection_name=VetAPI.COLLECTION_NAME,
                limit=page_size,
                skip=skip,
                sort=[('update_time', -1)]
            )
            return APIResponse.succeed({'list': list_data, 'total': total})
        except Exception as e:
            logger.error(f'获取兽医列表失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/role", description='获取用户角色')
    async def get_role(user_id: str = Query(description='用户 id')):
        try:
            super_user_ids = []
            if super_user:= mongo.find_many('zbt_super_user', projection={'user_id': 1}):
                super_user_ids = [su['user_id'] for su in super_user]
            if user_id in super_user_ids:
                # 超级管理员
                return APIResponse.succeed({'role': 'root'})

            user_id = mongo.find_one(VetAPI.COLLECTION_NAME, {'vet_id': user_id})

            if user_id:
                # 兽医
                return APIResponse.succeed({'role': 'vet'})
            else:
                # 普通用户
                return APIResponse.succeed({'role': 'user'})
        except Exception as e:
            logger.error(f'获取兽医列表失败：{e}')
            return APIResponse.fail()


class CardAPI:
    """
    卡片管理
    """
    COLLECTION_NAME = 'zbt_card'

    class Card(BaseModel):
        conversation_id: str    = Field(description='会话ID')
        symptom: str            = Field(default='', description='主要症状')
        onset_time: str         = Field(default='', description='发病时间')
        house: str              = Field(default='', description='栋舍名称')
        stage: str              = Field(default='', description='猪群阶段')
        temperature: str        = Field(default='', description='体温')
        remark: str             = Field(default='', description='补充说明')
        images: str             = Field(default='', description='图片URL')

    @staticmethod
    @zbt_router.post("/card", description='保存卡片信息')
    async def save(request: Card):
        try:
            existing = CardAPI.get_card(request.conversation_id)
            update_dict = request.model_dump(exclude_unset=True) if existing else request.model_dump()
            mongo.update_one(
                collection_name=CardAPI.COLLECTION_NAME,
                filter_dict={'conversation_id': request.conversation_id},
                update_dict=update_dict,
                upsert=True
            )
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'保存卡片信息失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/card/{conversation_id}", description='获取保存的卡片信息')
    async def get(conversation_id: str):
        try:
            result = CardAPI.get_card(conversation_id)
            return APIResponse.succeed(result)
        except Exception as e:
            logger.error(f'获取保存的卡片信息失败：{e}')
            return APIResponse.fail()

    @staticmethod
    def get_card(conversation_id: str):
        return mongo.find_one(CardAPI.COLLECTION_NAME, {'conversation_id': conversation_id})


diagnose_status = {
    "LCCC": ("running", "临床初查"),
    "BYQR": ("loading", "病因确认"),
    "FAND": ("loading", "方案拟定"),
    "ZXCZ": ("loading", "执行处置"),
    "XGFK": ("loading", "效果反馈"),
}


class DiagnoseStatusAPI:
    """
    诊断状态管理
    """
    @staticmethod
    @zbt_router.post("/record_status", description='记录诊断状态')
    async def save(
            conversation_id: str = Body(description='会话 ID'),
            tag: str = Body(description='状态更改标记，控制诊断流程各阶段状态流转'),
            send_user_id: str = Body(description='消息发送者 user_id')
    ):
        """
        记录诊断状态，根据 tag 标记更新诊断流程各阶段的状态
        Tag 标记说明:
            - LCCC_DOWN: 临床初查完成，启动病因确认
            - BYQR_DRAFT: 病因确认草稿，启动方案拟定
            - BYQR_DOWN: 病因确认完成
            - FAND_DOWN: 方案拟定完成，启动执行处置
            - ZXCZ_DOWN: 执行处置完成，启动效果反馈
            - XGFK_DOWN: 效果反馈完成
        """
        status = ConsultationAPI.get_status(conversation_id)
        match tag:
            case 'LCCC_DOWN':
                status['LCCC'] = 'down'
                status['BYQR'] = 'running'
            case 'BYQR_DRAFT':
                status['FAND'] = 'running'
            case 'BYQR_DOWN':
                status['BYQR'] = 'down'
            case 'FAND_DOWN':
                status['FAND'] = 'down'
                status['ZXCZ'] = 'running'
            case 'ZXCZ_DOWN':
                status['ZXCZ'] = 'down'
                status['XGFK'] = 'running'
            case 'XGFK_DOWN':
                status['XGFK'] = 'down'
            case _:
                return APIResponse.fail('不支持的tag')

        try:
            # 记录诊断状态
            mongo.update_one(
                collection_name=ConsultationAPI.COLLECTION_NAME,
                filter_dict={'conversation_id': conversation_id},
                update_dict=status,
                upsert=True
            )
            # 向 IM 发送自定义消息
            if send_user_id:
                click_tag = tag.split('_')[0]
                conversation_info = ConversationAPI.get_conversation_info(conversation_id)
                im_response = IMUtil(ZBT_IM_APP_ID).send_message(
                    group_id=conversation_info['group_id'],
                    send_user_id=send_user_id,
                    data={
                        "type": 5, # 诊断进度卡片
                        "stepIndex": tag,
                        "stepLabel": diagnose_status[click_tag][1],
                        "status": status[click_tag],
                        "statusText": "",
                        "cardInstanceId": f"{conversation_id}:{tag}",
                        "cardType": "consult_progress",
                        "version": get_timestamp()
                    },
                    description=f'诊断进度.{tag}',
                )
                if server_msg_id := im_response.get('serverMsgID'):
                    logger.info(f'发送给 IM 消息成功, server_msg_id: {server_msg_id}')
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'记录诊断状态失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/diagnose_status/{conversation_id}", description='获取诊断状态')
    async def get(conversation_id: str):
        try:
            status = ConsultationAPI.get_status(conversation_id)
            return APIResponse.succeed(status)
        except Exception as e:
            logger.error(f'获取保存的卡片信息失败：{e}')
            return APIResponse.fail()


class TreatmentRecordAPI:
    """
    治疗记录管理
    """
    COLLECTION_NAME = 'zbt_treatment_record'

    @staticmethod
    @zbt_router.post("/treatment_record", description='新增治疗记录')
    async def save(
            conversation_id: str = Body(description='会话 ID'),
            pig_signs: str = Body(description='病猪表现'),
            medication: str = Body(description='用药情况')
    ):
        try:
            mongo.insert_one(
                TreatmentRecordAPI.COLLECTION_NAME,
                dict(
                    conversation_id=conversation_id,
                    pig_signs=pig_signs,
                    medication=medication,
                )
            )
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'新增治疗记录失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/treatment_record", description='获取治疗记录列表')
    async def list(conversation_id: str = Query(description='会话 id')):
        try:
            result = mongo.find_many(
                TreatmentRecordAPI.COLLECTION_NAME,
                filter_dict={'conversation_id': conversation_id}
            )
            return APIResponse.succeed(result)
        except Exception as e:
            logger.error(f'获取治疗记录列表失败：{e}')
            return APIResponse.fail()


class ConsultationAPI:
    """
    会诊管理
    """
    COLLECTION_NAME = 'zbt_consultation'

    class Consultation(BaseModel):
        conversation_id: str    = Field(description='会话ID')
        user_id: str            = Field(description='用户ID')
        vet_id: str             = Field(description='兽医ID')
        # diagnose_status: str    = Field(default=DEFAULT_DIAGNOSE_STATUS, description='诊断状态')
        ai_house: str           = Field(default='', description='AI栋舍名称')
        basis: str              = Field(default='', description='AI诊断依据(病情分析)')
        disease_type: str       = Field(default='', description='AI疾病类型(诊断结果)')
        suggest_medicine: str   = Field(default='', description='AI推荐用药(建议使用药物)')
        treatment_course: str   = Field(default='', description='用药疗程')
        remark: str             = Field(default='', description='补充说明')
        is_necropsy: bool       = Field(default=False, description='是否进行病理剖检')
        consultation_date: str = Field(default='', description='日期')
        house: str             = Field(default='', description='栋舍')
        surface_pathological_exam : str = Field(default='', description='体表病理检查')
        report: str             = Field(default='', description='病理剖检报告')
        pre_result: str         = Field(default='', description='初步诊断结果')
        is_examination: bool    = Field(default=False, description='是否进行实验室检测')
        operate_quarantine: str = Field(default='', description='实际操作(隔离)')
        operate_disinfect: str  = Field(default='', description='实际操作(消毒)')
        operate_medication: str = Field(default='', description='实际操作(用药)')
        operate_nursing: str    = Field(default='', description='实际操作(护理)')
        operate_other: str      = Field(default='', description='实际操作(其他)')
        is_feedback: bool       = Field(default=False, description='效果反馈是否有效')
        feedback_content: str   = Field(default='', description='效果反馈内容')

    @staticmethod
    @zbt_router.post("/consultation", description='保存会诊填写信息')
    async def save(request: Consultation):
        try:
            existing = mongo.find_one(ConsultationAPI.COLLECTION_NAME, {'conversation_id': request.conversation_id})
            update_dict = request.model_dump(exclude_unset=True) if existing else request.model_dump()
            mongo.update_one(
                collection_name=ConsultationAPI.COLLECTION_NAME,
                filter_dict={'conversation_id': request.conversation_id},
                update_dict=update_dict,
                upsert=True
            )
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'保存会诊填写信息失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/consultation/{conversation_id}", description='获取会诊填写信息')
    async def get(conversation_id: str):
        try:
            result = mongo.find_one(ConsultationAPI.COLLECTION_NAME, {'conversation_id': conversation_id})
            return APIResponse.succeed(result)
        except Exception as e:
            logger.error(f'获取会诊填写信息失败：{e}')
            return APIResponse.fail()

    @staticmethod
    def is_start_group(conversation_id: str) -> bool:
        """是否已创建群聊"""
        result = mongo.find_one(ConsultationAPI.COLLECTION_NAME, {'conversation_id': conversation_id})
        return bool(result)

    @staticmethod
    @zbt_router.get("/group_chat/page", description='问诊室分页查询')
    async def group_chat_page(
        page_num: int = Query(default=1, description='当前页'),
        page_size: int = Query(default=10, description='每页显示条数'),
        diagnose_status: str = Query(default='', description='诊断状态'),
        date_period: str = Query(default='all', description='日期范围：today/week/month/last_month/all'),
    ):
        try:
            filter_dict = {}
            if diagnose_status:
                filter_dict[diagnose_status] = 'running'
            start_time, end_time = get_date_range(date_period)
            if start_time:
                filter_dict['create_time'] = {'$gte': start_time, '$lte': end_time}

            skip = (page_num - 1) * page_size
            projection = {
                'conversation_id': 1, 'vet_id': 1, 'house': 1, 'basis': 1, 'disease_type': 1,
                'create_time': 1, 'LCCC': 1, 'BYQR': 1, 'FAND': 1, 'ZXCZ': 1, 'XGFK': 1
            }
            total, list_data = mongo.page_list(
                collection_name=ConsultationAPI.COLLECTION_NAME,
                filter_dict=filter_dict,
                projection=projection,
                limit=page_size,
                skip=skip,
                sort=[('create_time', -1)]
            )
            for data in list_data or []:
                status = None
                for key, value in data.items():
                    if value == 'running':
                        status = key
                        break
                if status:
                    data['diagnose_status'] = status
            return APIResponse.succeed({'list': list_data, 'total': total})
        except Exception as e:
            logger.error(f'问诊室分页查询失败：{e}')
            return APIResponse.fail()

    @staticmethod
    def get_status(conversation_id: str):
        status = mongo.find_one(
            collection_name=ConsultationAPI.COLLECTION_NAME,
            filter_dict={'conversation_id': conversation_id},
            projection={'_id': 0, 'LCCC': 1, 'BYQR': 1, 'FAND': 1, 'ZXCZ': 1, 'XGFK': 1}
        )
        return status

    @staticmethod
    @zbt_router.post("/share", description='添加到案例库')
    def share(conversation_id: str = Body(embed=True, description='会话 ID')):
        try:
            mongo.update_one(
                collection_name=ConsultationAPI.COLLECTION_NAME,
                filter_dict={'conversation_id': conversation_id},
                update_dict={'share': True},
                upsert=True
            )
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'添加案例库失败：{e}')
            return APIResponse.fail()


class ConversationAPI:
    COLLECTION_NAME = 'zbt_conversation'

    @staticmethod
    @zbt_router.get("/conversation/list", description='获取当前用户会话列表')
    async def get_conversation_list(user_id: str):
        try:
            result = mongo.find_many(
                ConversationAPI.COLLECTION_NAME,
                {'$or': [{'user_id': user_id}, {'vet_id': user_id}]}
            )
            return APIResponse.succeed(result)
        except Exception as e:
            logger.error(f'获取会话列表失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.post("/conversation/rename", description='重命名会话标题')
    async def rename_title(conversation_id: str = Body(description='会话 ID'), title: str = Body(description='新标题')):
        try:
            mongo.update_one(
                collection_name=ConversationAPI.COLLECTION_NAME,
                filter_dict={'conversation_id': conversation_id},
                update_dict={'title': title},
            )
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'重命名会话标题失败：{e}')
            return APIResponse.fail()

    @staticmethod
    def get_conversation_info(conversation_id):
        return mongo.find_one(ConversationAPI.COLLECTION_NAME, {'conversation_id': conversation_id})

    @staticmethod
    @zbt_router.post("/start_group", description='找兽医建群聊')
    async def start_group(
        req: Request,
        conversation_id: str = Body(default='', description='会话 ID'),
        vet_id: str = Body(description='兽医 ID'),
        user_id: str = Body(description='用户 ID'),
        ai_id: str = Body(description='AI ID'),
    ):
        conversation_id = conversation_id or str(uuid4())
        if ConversationAPI.get_conversation_info(conversation_id):
            return APIResponse.succeed(msg='会话已存在，无需创建群聊')

        # 获取用户最新[已确认]后的AI诊断结果
        try:
            llm_result = await ConversationAPI._get_llm_result(req, conversation_id)
        except Exception as e:
            llm_result = ''
        logger.info(f'用户最近一次[已确认]后的AI诊断结果：\n{llm_result}')

        # 格式化诊断结果为json数据
        ai_msg = await ConversationAPI._result_to_json(llm_result) if llm_result else {}
        logger.info(f'诊断结果 json：\n{json.dumps(ai_msg, ensure_ascii=False, default=str)}')

        # IM 创建群聊会话
        title = f'会诊-{ai_msg.get('disease_type', '')}'
        try:
            im_util = IMUtil(ZBT_IM_APP_ID)
            im_response = im_util.create_group(conversation_id, title, int(user_id), int(vet_id), ai_id)
            if group_id := im_response.get('groupID'):
                logger.info(f'IM 创建群聊成功, group_id: {group_id}')
        except Exception as e:
            return APIResponse.fail(f"IM 创建群聊失败: {e}")

        # 维护 group_id 和 其他信息
        mongo.insert_one(
            ConversationAPI.COLLECTION_NAME,
            dict(
                conversation_id=conversation_id,
                group_id=group_id,
                user_id=user_id,
                vet_id=vet_id,
                title=title,
            )
        )

        # 初始化会诊信息
        init_consultation = {
            'conversation_id': conversation_id,
            'user_id': user_id,
            'vet_id': vet_id,
            **ai_msg,
        }
        for k, (code, _) in diagnose_status.items():
            init_consultation[k] = code
        mongo.update_one(
            collection_name=ConsultationAPI.COLLECTION_NAME,
            filter_dict={'conversation_id': conversation_id},
            update_dict=init_consultation,
            upsert=True
        )
        logger.info(f'初始化会诊信息：{init_consultation}')
        return APIResponse.succeed(data=group_id)

    @staticmethod
    async def _get_llm_result(req: Request, conversation_id):
        """获取用户最新[已确认]后的AI回复"""
        llm_result = ''
        workflow: CompiledStateGraph = req.app.state.workflow
        state = await workflow.aget_state(config={"configurable": {"thread_id": conversation_id}})
        messages: list[AnyMessage] = state.values["messages"]
        final_messages = []
        for message in reversed(messages):
            final_messages.append(message)
            if isinstance(message, HumanMessage) and '[已确认]' in message.content:
                break
        for message in reversed(final_messages):
            if isinstance(message, AIMessage) and isinstance(message.content, str):
                llm_result = message.content
        return llm_result

    @staticmethod
    async def _result_to_json(llm_result) -> dict:
        """通过大模型格式化诊断结果为json数据"""
        try:
            prompt = llm_result + load_prompt('zbt_ai_result_to_json_prompt.md')
            response = await LlmFactory.create_llm().ainvoke([HumanMessage(content=prompt)])
            consultation = json.loads(response.text)
            ai_msg = {
                'basis': consultation.get('basis'), # 病情分析
                'disease_type': consultation.get('disease_type'), # 诊断结果
                'suggest_medicine': consultation.get('suggest_medicine', []), # 推荐用药
            }
            logger.info(f'AI解析病情成功：{ai_msg}')
            return ai_msg
        except Exception as e:
            logger.error(f'AI解析病情失败：{e}')
            return {}


class TestingCenterAPI:
    """
    检测中心
    """
    COLLECTION_NAME = 'zbt_testing_center'

    TESTING_RESULT_MAP = {
        'positive': '阳性',
        'abnormal': '异常',
        'normal': '正常',
    }

    REPORT_TYPE_MAP = {
        'alone': '独立报告',
        'link': '异常',
    }

    class TestingReport(BaseModel):
        id: str                 = Field(default='', description='id，新增为空，修改不为空必传')
        folder_id: str          = Field(description='文件夹 id')
        title: str              = Field(description='标题')
        conversation_id: str    = Field(description='会话id（问诊室）')
        sample_type: str        = Field(default='', description='样品类型')
        testing_item: str       = Field(description='检测项目')
        testing_result: str     = Field(default='', description='检测结果（阳性/异常/正常）')
        result_summary: str     = Field(default='', description='结果说明')
        vet_analysis: str       = Field(default='', description='兽医解读')
        attachments: list[str]  = Field(default_factory=list, description='上传附件')

    @staticmethod
    @zbt_router.post("/testing_report", description='保存检测报告')
    async def save(report: TestingReport):
        try:
            if report.id:
                # 修改：根据 _id 更新已有记录
                update_dict = report.model_dump(exclude={'id'}, exclude_unset=True)
                mongo.update_one(
                    collection_name=TestingCenterAPI.COLLECTION_NAME,
                    filter_dict={'_id': report.id},
                    update_dict=update_dict,
                )
            else:
                # 新增：插入新记录
                mongo.insert_one(TestingCenterAPI.COLLECTION_NAME, report.model_dump(exclude={'id'}))
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'保存检测报告失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/testing_report", description='检测报告列表')
    async def page(
        page_num: int = Query(default=1, description='当前页'),
        page_size: int = Query(default=10, description='每页显示条数'),
        folder_id: str = Query(default='', description='文件夹 id'),
        keyword: str = Query(default='', description='搜索关键词（匹配猪场名称或检测项目）'),
    ):
        try:
            # 构建查询过滤条件
            conditions = []
            if folder_id:
                conditions.append({'folder_id': folder_id})
            if keyword:
                conditions.append({
                    '$or': [
                        {'title': {'$regex': keyword, '$options': 'i'}},
                        {'testing_item': {'$regex': keyword, '$options': 'i'}}
                    ]
                })
            filter_dict = {'$and': conditions} if conditions else {}

            skip = (page_num - 1) * page_size
            total, list_data = mongo.page_list(
                collection_name=TestingCenterAPI.COLLECTION_NAME,
                filter_dict=filter_dict,
                limit=page_size,
                skip=skip,
                sort=[('update_time', -1)]
            )
            return APIResponse.succeed({'list': list_data, 'total': total})
        except Exception as e:
            logger.error(f'获取检测报告列表失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/testing_result", description='检测结果下拉列表')
    async def testing_result():
        return APIResponse.succeed(data=TestingCenterAPI.TESTING_RESULT_MAP)

    @staticmethod
    @zbt_router.get("/report_type", description='报告类型')
    async def report_type():
        return APIResponse.succeed(data=TestingCenterAPI.REPORT_TYPE_MAP)


class CaseCenterAPI:
    """
    案例中心
    """
    COLLECTION_NAME = 'zbt_case_center'

    class Case(BaseModel):
        id: str = Field(default='', description='id，新增为空，修改不为空必传')
        folder_id: str = Field(description='文件夹 id')
        title: str = Field(description='案例标题')
        word_file: str = Field(description='word 文件')

    @staticmethod
    @zbt_router.post("/case", description='导入案例')
    async def save(case: Case):
        try:
            if case.id:
                # 修改：根据 _id 更新已有记录
                update_dict = case.model_dump(exclude={'id'}, exclude_unset=True)
                mongo.update_one(
                    collection_name=CaseCenterAPI.COLLECTION_NAME,
                    filter_dict={'_id': case.id},
                    update_dict=update_dict,
                )
            else:
                # 新增：插入新记录
                mongo.insert_one(CaseCenterAPI.COLLECTION_NAME, case.model_dump(exclude={'id'}))
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'新增案例失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/case", description='导入案例列表')
    async def page(
        page_num: int = Query(default=1, description='当前页'),
        page_size: int = Query(default=10, description='每页显示条数'),
        folder_id: str = Query(default='', description='文件夹 id'),
        title: str = Query(default=None, description='案例标题(模糊查询)'),
    ):
        try:
            filter_dict = {}
            if folder_id:
                filter_dict['folder_id'] = folder_id
            if title:
                filter_dict['title'] = {'$regex': title, '$options': 'i'}
            skip = (page_num - 1) * page_size
            total, list_data = mongo.page_list(
                collection_name=CaseCenterAPI.COLLECTION_NAME,
                filter_dict=filter_dict,
                limit=page_size,
                skip=skip,
                sort=[('update_time', -1)]
            )
            return APIResponse.succeed({'list': list_data, 'total': total})
        except Exception as e:
            logger.error(f'获取案例列表失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/case/share", description='共享案例库列表')
    async def page(
            page_num: int = Query(default=1, description='当前页'),
            page_size: int = Query(default=10, description='每页显示条数'),
            title: str = Query(default='', description='案例标题(模糊查询)'),
    ):
        try:
            filter_dict = {'share': True}
            if title:
                filter_dict['disease_type'] = {'$regex': title, '$options': 'i'}
            skip = (page_num - 1) * page_size
            total, list_data = mongo.page_list(
                collection_name=ConsultationAPI.COLLECTION_NAME,
                filter_dict=filter_dict,
                limit=page_size,
                skip=skip,
                sort=[('update_time', -1)]
            )
            for data in list_data or []:
                status = None
                for key, value in data.items():
                    if value == 'running':
                        status = key
                        break
                if status:
                    data['diagnose_status'] = status
            return APIResponse.succeed({'list': list_data, 'total': total})
        except Exception as e:
            logger.error(f'获取案例列表失败：{e}')
            return APIResponse.fail()


class FolderAPI:
    """
    文件夹管理
    """
    COLLECTION_NAME = 'zbt_folder'

    class Folder(BaseModel):
        folder_type: Literal['testing', 'case'] = Field(description='文件夹类型')
        folder_name: str = Field(description='文件夹名称')
        create_user_id: str = Field(description='创建人')

    @staticmethod
    @zbt_router.post("/folder", description='新建文件夹')
    async def save(folder: Folder):
        try:
            mongo.insert_one(FolderAPI.COLLECTION_NAME, folder.model_dump())
            return APIResponse.succeed()
        except Exception as e:
            logger.error(f'新建文件夹失败：{e}')
            return APIResponse.fail()

    @staticmethod
    @zbt_router.get("/folder", description='获取新建文件夹列表')
    async def list(folder_type: Literal['testing', 'case'] = Query(description='文件夹类型')):
        try:
            result = mongo.find_many(FolderAPI.COLLECTION_NAME, filter_dict={'folder_type': folder_type})
            return APIResponse.succeed(result)
        except Exception as e:
            logger.error(f'获取新建文件夹列表失败：{e}')
            return APIResponse.fail()



if __name__ == '__main__':
    # 添加超级管理员
    s_u_ids = ['']
    for u_id in s_u_ids:
        mongo.insert_one('zbt_super_user', {'user_id': u_id})
        print(f'`{u_id}` 添加成功')