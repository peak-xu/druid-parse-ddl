from json import loads
from typing import List, Any

code_alias = ['code', 'Code', 'status']
data_alias = ['data', 'Data']
msg_alias = ['msg', 'error', 'errMsg']
ok_alias = [0, '0', 1]

class ToolExtractor:
    """工具调用返回结果的 JSON 提取器。

    从工具返回的 JSON 字符串中提取标准字段（code/data/msg），
    支持多种字段别名（如 code/Code/status、msg/error/errMsg）。
    """

    def __init__(self, content: str):
        self.jo = loads(content)

    def is_ok(self) -> bool:
        code = self._get_prop(code_alias)
        if code is None:
            return False
        for it in ok_alias:
            if code == it:
                return True
        return False

    def get_msg(self) -> str:
        msg = self._get_prop(msg_alias)
        if msg is None:
            return ''
        return msg

    def get_data(self) -> Any:
        return self._get_prop(data_alias)

    def _get_prop(self, alias: List[str]) -> Any:
        for name in alias:
            prop = self.jo.get(name)
            if prop is not None:
                return prop
        return None