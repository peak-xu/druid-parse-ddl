"""
PPTUtil.py
FastAPI 后端：POST /generate
- 接收任意文本（Markdown、大纲、普通文字均可）
- 以 SSE 流式推送执行进度
- 返回可下载的 .pptx 文件

样式参考：专业深绿商务报告风格
- 封面：深绿全背景 + 白色主标题 + 金色副标题
- 章节页：左侧深绿色块 + 右侧编号卡片网格
- 内容页：白色背景 + 深色标题区 + 卡片式布局
- 强调色：金黄 (#C9A84C) / 青绿 (#2ECC71)
"""
import asyncio
import io

import requests
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt
from PIL import Image

from utils.file_util import file_upload_client


# ─── 颜色主题 ────────────────────────────────────────────────────────────────
# 三套主题，均参照参考 PPT 的专业商务风格

THEMES = {
    # 深绿商务（默认，最接近参考样式）
    "dark": {
        "cover_bg":       RGBColor(0x1A, 0x3A, 0x35),  # 深绿封面底色
        "section_bg":     RGBColor(0x1A, 0x3A, 0x35),  # 章节页左侧大块
        "content_bg":     RGBColor(0xFF, 0xFF, 0xFF),  # 内容页底色（白）
        "header_bg":      RGBColor(0x1A, 0x3A, 0x35),  # 内容页顶部标题栏
        "card_bg":        RGBColor(0xF5, 0xF7, 0xF6),  # 卡片背景（浅灰绿）
        "card_alt_bg":    RGBColor(0xE8, 0xF0, 0xED),  # 交替卡片色
        "accent":         RGBColor(0xC9, 0xA8, 0x4C),  # 金黄强调色
        "accent2":        RGBColor(0x2E, 0x7D, 0x6B),  # 青绿次强调色
        "title_fg":       RGBColor(0xFF, 0xFF, 0xFF),  # 封面/深色背景标题文字
        "header_fg":      RGBColor(0xFF, 0xFF, 0xFF),  # 标题栏文字
        "body_fg":        RGBColor(0x1A, 0x1A, 0x1A),  # 正文文字（深色页）
        "body_fg_light":  RGBColor(0xFF, 0xFF, 0xFF),  # 正文文字（深色背景）
        "sub_fg":         RGBColor(0xAA, 0xCC, 0xBB),  # 副标题/浅色文字（深色底）
        "sub_fg_dark":    RGBColor(0x55, 0x77, 0x66),  # 副标题（白色底）
        "number_fg":      RGBColor(0xC9, 0xA8, 0x4C),  # 编号/大数字
        "bullet_dot":     RGBColor(0x2E, 0x7D, 0x6B),
        "stat_fg":        RGBColor(0x1A, 0x3A, 0x35),  # 统计数字色
        "slide_num_fg":   RGBColor(0x88, 0xAA, 0x99),
        "divider":        RGBColor(0xC9, 0xA8, 0x4C),
    },
    # 深蓝商务
    "light": {
        "cover_bg":       RGBColor(0x1A, 0x25, 0x40),
        "section_bg":     RGBColor(0x1A, 0x25, 0x40),
        "content_bg":     RGBColor(0xFF, 0xFF, 0xFF),
        "header_bg":      RGBColor(0x1A, 0x25, 0x40),
        "card_bg":        RGBColor(0xF2, 0xF5, 0xFA),
        "card_alt_bg":    RGBColor(0xE5, 0xEC, 0xF7),
        "accent":         RGBColor(0xF5, 0xA6, 0x23),
        "accent2":        RGBColor(0x23, 0x6F, 0xCE),
        "title_fg":       RGBColor(0xFF, 0xFF, 0xFF),
        "header_fg":      RGBColor(0xFF, 0xFF, 0xFF),
        "body_fg":        RGBColor(0x1A, 0x1A, 0x1A),
        "body_fg_light":  RGBColor(0xFF, 0xFF, 0xFF),
        "sub_fg":         RGBColor(0xAA, 0xBB, 0xDD),
        "sub_fg_dark":    RGBColor(0x55, 0x66, 0x88),
        "number_fg":      RGBColor(0xF5, 0xA6, 0x23),
        "bullet_dot":     RGBColor(0x23, 0x6F, 0xCE),
        "stat_fg":        RGBColor(0x1A, 0x25, 0x40),
        "slide_num_fg":   RGBColor(0x99, 0xAA, 0xCC),
        "divider":        RGBColor(0xF5, 0xA6, 0x23),
    },
    # 深紫高端
    "colorful": {
        "cover_bg":       RGBColor(0x1A, 0x10, 0x35),
        "section_bg":     RGBColor(0x1A, 0x10, 0x35),
        "content_bg":     RGBColor(0xFF, 0xFF, 0xFF),
        "header_bg":      RGBColor(0x1A, 0x10, 0x35),
        "card_bg":        RGBColor(0xF5, 0xF3, 0xFA),
        "card_alt_bg":    RGBColor(0xEC, 0xE8, 0xF7),
        "accent":         RGBColor(0xE5, 0xA3, 0x00),
        "accent2":        RGBColor(0x7C, 0x4D, 0xFF),
        "title_fg":       RGBColor(0xFF, 0xFF, 0xFF),
        "header_fg":      RGBColor(0xFF, 0xFF, 0xFF),
        "body_fg":        RGBColor(0x1A, 0x1A, 0x1A),
        "body_fg_light":  RGBColor(0xFF, 0xFF, 0xFF),
        "sub_fg":         RGBColor(0xBB, 0xAA, 0xDD),
        "sub_fg_dark":    RGBColor(0x66, 0x55, 0x88),
        "number_fg":      RGBColor(0xE5, 0xA3, 0x00),
        "bullet_dot":     RGBColor(0x7C, 0x4D, 0xFF),
        "stat_fg":        RGBColor(0x1A, 0x10, 0x35),
        "slide_num_fg":   RGBColor(0xAA, 0x99, 0xCC),
        "divider":        RGBColor(0xE5, 0xA3, 0x00),
    },
}


def pick_theme(style: str) -> dict:
    if style in THEMES:
        return THEMES[style]
    return THEMES["dark"]


# async def plan_slides(markdown: str, style: str) -> dict:
#     llm = ChatOpenAI()
#     user_msg = f"主题风格偏好：{style}\n\nMarkdown 内容：\n{markdown}"
#     response = await llm.ainvoke([
#         {"role": "system", "content": PLAN_SYSTEM},
#         {"role": "user", "content": user_msg},
#     ])
#     raw = response.content.strip()
#     # 去除可能存在的 ```json 代码块标记
#     raw = re.sub(r"^```[a-z]*\n?", "", raw)
#     raw = re.sub(r"\n?```$", "", raw)
#     return json.loads(raw)


# ─── 圆角矩形辅助 ────────────────────────────────────────────────────────────

def _add_rounded_rect(slide, left, top, width, height,
                      fill_color: RGBColor, radius_emu: int = 120000):
    """添加圆角矩形（MSO形状类型=5）"""
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    shape = slide.shapes.add_shape(5, left, top, width, height)
    shape.line.fill.background()
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    # 设置圆角
    try:
        adj = shape.adjustments
        if len(adj) > 0:
            adj[0] = radius_emu
    except Exception:
        pass
    return shape


# ─── 图片下载工具 ────────────────────────────────────────────────────────────

def fetch_image_bytes(url: str) -> bytes | None:
    try:
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200:
            return resp.content
    except Exception:
        pass
    return None


def image_bytes_to_stream(raw: bytes) -> io.BytesIO:
    """将图片字节流转换为 JPEG BytesIO，自动处理透明通道。"""
    img = Image.open(io.BytesIO(raw))
    if img.mode in ("RGBA", "P", "LA"):
        bg = Image.new("RGB", img.size, (255, 255, 255))
        if img.mode == "P":
            img = img.convert("RGBA")
        bg.paste(img, mask=img.split()[-1] if img.mode in ("RGBA", "LA") else None)
        img = bg
    elif img.mode != "RGB":
        img = img.convert("RGB")
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=92)
    buf.seek(0)
    return buf


# ─── PPTX 幻灯片渲染 ─────────────────────────────────────────────────────────

SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)


def _add_bg(slide, color: RGBColor):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = color


def _add_rect(slide, left, top, width, height, fill_color: RGBColor):
    shape = slide.shapes.add_shape(1, left, top, width, height)
    shape.line.fill.background()
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    return shape


def _textbox(slide, left, top, width, height,
             text: str, font_size: int, bold: bool, color: RGBColor,
             align=PP_ALIGN.LEFT, italic=False, word_wrap=True,
             font_name: str = "Arial") -> None:
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = word_wrap
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    run.font.name = font_name


# ─── 封面页 ──────────────────────────────────────────────────────────────────

def render_title_slide(prs, slide_data: dict, theme: dict):
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    _add_bg(slide, theme["cover_bg"])

    # 顶部细装饰线（金色）
    _add_rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(0.06), theme["accent"])

    # 英文标签小字（参考样式：INDUSTRY INSIGHT & STRATEGY REPORT）
    label = slide_data.get("label", "STRATEGY REPORT")
    _textbox(slide, Inches(0.7), Inches(0.35), Inches(11), Inches(0.45),
             label, font_size=11, bold=False, color=theme["sub_fg"],
             align=PP_ALIGN.LEFT, font_name="Arial")

    # 主标题（大）
    _textbox(slide, Inches(0.7), Inches(2.0), Inches(11.5), Inches(2.2),
             slide_data.get("title", ""), font_size=44, bold=True,
             color=theme["title_fg"], align=PP_ALIGN.LEFT, font_name="Arial")

    # 金色装饰横线
    _add_rect(slide, Inches(0.7), Inches(4.3), Inches(2.5), Inches(0.05), theme["accent"])

    # 副标题
    sub = slide_data.get("subtitle", "")
    if sub:
        _textbox(slide, Inches(0.7), Inches(4.5), Inches(11), Inches(0.8),
                 sub, font_size=20, bold=False, color=theme["accent"],
                 align=PP_ALIGN.LEFT, font_name="Arial")

    # 作者/日期信息
    info_parts = []
    if slide_data.get("author"):
        info_parts.append(slide_data["author"])
    if slide_data.get("date"):
        info_parts.append(slide_data["date"])
    if info_parts:
        _textbox(slide, Inches(0.7), Inches(6.6), Inches(10), Inches(0.5),
                 "  |  ".join(info_parts), font_size=13, bold=False,
                 color=theme["sub_fg"], font_name="Arial")

    # 底部细装饰线
    _add_rect(slide, Inches(0), SLIDE_H - Inches(0.06), SLIDE_W, Inches(0.06), theme["accent"])

    _set_notes(slide, slide_data.get("notes", ""))


# ─── 章节/目录页 ─────────────────────────────────────────────────────────────

def render_section_slide(prs, slide_data: dict, theme: dict):
    """
    左侧深色大块（约占1/3宽），右侧网格卡片展示章节条目
    """
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    _add_bg(slide, theme["content_bg"])

    left_w = Inches(3.8)

    # 左侧深色背景块
    _add_rect(slide, Inches(0), Inches(0), left_w, SLIDE_H, theme["section_bg"])

    # 左侧装饰细线（金色）
    _add_rect(slide, left_w - Inches(0.05), Inches(0), Inches(0.05), SLIDE_H, theme["accent"])

    # 左侧章节编号（如 01）
    sec_num = slide_data.get("section_number", "")
    if sec_num:
        _textbox(slide, Inches(0.4), Inches(0.5), Inches(3.0), Inches(1.2),
                 sec_num, font_size=60, bold=True, color=theme["accent"],
                 font_name="Arial")

    # 左侧标题
    _textbox(slide, Inches(0.4), Inches(1.8), Inches(3.0), Inches(2.0),
             slide_data.get("title", ""), font_size=26, bold=True,
             color=theme["title_fg"], word_wrap=True, font_name="Arial")

    # 左侧副标题
    sub = slide_data.get("subtitle", "")
    if sub:
        _textbox(slide, Inches(0.4), Inches(4.0), Inches(3.0), Inches(1.5),
                 sub, font_size=13, bold=False, color=theme["sub_fg"],
                 word_wrap=True, font_name="Arial")

    # 左下 "CONTENTS" 标签
    _textbox(slide, Inches(0.4), Inches(6.5), Inches(3.2), Inches(0.6),
             "CONTENTS", font_size=11, bold=False, color=theme["sub_fg"],
             font_name="Arial")

    # 右侧网格卡片
    items = slide_data.get("items", [])
    if items:
        right_x = left_w + Inches(0.35)
        right_w = SLIDE_W - left_w - Inches(0.5)
        _render_grid_items(slide, items, right_x, Inches(0.4),
                           right_w, SLIDE_H - Inches(0.6), theme)

    _set_notes(slide, slide_data.get("notes", ""))


def _render_grid_items(slide, items: list, area_left, area_top,
                       area_w, area_h, theme: dict):
    """将 items 渲染为 2 列网格卡片"""
    n = len(items)
    cols = 2
    rows = (n + 1) // 2

    cell_w = (area_w - Inches(0.2)) / cols
    cell_h = min((area_h - Inches(0.2)) / rows, Inches(2.8))

    for idx, item in enumerate(items):
        col = idx % cols
        row = idx // cols
        x = area_left + col * (cell_w + Inches(0.15))
        y = area_top + row * (cell_h + Inches(0.15))

        # 卡片背景（交替色）
        bg = theme["card_bg"] if idx % 2 == 0 else theme["card_alt_bg"]
        _add_rect(slide, x, y, cell_w, cell_h, bg)

        # 左侧强调色竖条
        _add_rect(slide, x, y, Inches(0.06), cell_h, theme["accent2"])

        # 编号
        num = item.get("number", str(idx + 1).zfill(2))
        _textbox(slide, x + Inches(0.18), y + Inches(0.1),
                 Inches(0.6), Inches(0.5),
                 num, font_size=20, bold=True, color=theme["accent"],
                 font_name="Arial")

        # 条目标题
        _textbox(slide, x + Inches(0.18), y + Inches(0.55),
                 cell_w - Inches(0.3), Inches(0.55),
                 item.get("title", ""), font_size=14, bold=True,
                 color=theme["body_fg"], word_wrap=True, font_name="Arial")

        # 条目描述
        desc = item.get("desc", "")
        if desc:
            _textbox(slide, x + Inches(0.18), y + Inches(1.1),
                     cell_w - Inches(0.3), cell_h - Inches(1.25),
                     desc, font_size=11, bold=False,
                     color=theme["sub_fg_dark"], word_wrap=True, font_name="Arial")


# ─── 要点列表页 ──────────────────────────────────────────────────────────────

def render_bullets_slide(prs, slide_data: dict, theme: dict):
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    _add_bg(slide, theme["content_bg"])

    # 顶部标题栏（深色）
    header_h = Inches(1.3)
    _add_rect(slide, Inches(0), Inches(0), SLIDE_W, header_h, theme["header_bg"])
    _add_rect(slide, Inches(0), Inches(0), Inches(0.1), header_h, theme["accent"])

    _textbox(slide, Inches(0.35), Inches(0.18), Inches(12.5), Inches(0.7),
             slide_data.get("title", ""), font_size=26, bold=True,
             color=theme["header_fg"], font_name="Arial")

    sub = slide_data.get("subtitle", "")
    if sub:
        _textbox(slide, Inches(0.35), Inches(0.88), Inches(12.5), Inches(0.36),
                 sub, font_size=13, bold=False, color=theme["sub_fg"],
                 font_name="Arial")

    # 要点列表区域
    points = slide_data.get("points", [])
    content_top = header_h + Inches(0.25)
    content_h = SLIDE_H - content_top - Inches(0.3)
    item_h = min(content_h / max(len(points), 1), Inches(1.35))

    for i, pt in enumerate(points):
        text = pt.get("text", pt) if isinstance(pt, dict) else pt
        detail = pt.get("detail", "") if isinstance(pt, dict) else ""
        y = content_top + i * (item_h + Inches(0.1))

        # 卡片背景
        _add_rect(slide, Inches(0.5), y, Inches(12.3), item_h,
                  theme["card_bg"] if i % 2 == 0 else theme["card_alt_bg"])

        # 左侧编号圆圈（用方块模拟）
        _add_rect(slide, Inches(0.5), y, Inches(0.08), item_h, theme["accent2"])

        # 编号文字
        _textbox(slide, Inches(0.68), y + Inches(0.05),
                 Inches(0.45), Inches(0.5),
                 str(i + 1).zfill(2), font_size=16, bold=True,
                 color=theme["accent"], font_name="Arial")

        # 要点文字
        txt_top = y + Inches(0.08) if not detail else y + Inches(0.05)
        _textbox(slide, Inches(1.3), txt_top,
                 Inches(11.2), Inches(0.55),
                 text, font_size=16, bold=True, color=theme["body_fg"],
                 font_name="Arial")

        if detail:
            _textbox(slide, Inches(1.3), y + Inches(0.6),
                     Inches(11.2), item_h - Inches(0.68),
                     detail, font_size=12, bold=False,
                     color=theme["sub_fg_dark"], word_wrap=True, font_name="Arial")

    _set_notes(slide, slide_data.get("notes", ""))


# ─── 双栏对比页 ──────────────────────────────────────────────────────────────

def render_two_col_slide(prs, slide_data: dict, theme: dict):
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    _add_bg(slide, theme["content_bg"])

    header_h = Inches(1.3)
    _add_rect(slide, Inches(0), Inches(0), SLIDE_W, header_h, theme["header_bg"])
    _add_rect(slide, Inches(0), Inches(0), Inches(0.1), header_h, theme["accent"])
    _textbox(slide, Inches(0.35), Inches(0.3), Inches(12.5), Inches(0.75),
             slide_data.get("title", ""), font_size=26, bold=True,
             color=theme["header_fg"], font_name="Arial")

    col_top = header_h + Inches(0.25)
    col_h = SLIDE_H - col_top - Inches(0.3)
    col_w = Inches(6.0)
    gap = Inches(0.33)

    for col_idx, (hkey, pkey, x) in enumerate([
        ("left_heading",  "left_points",  Inches(0.4)),
        ("right_heading", "right_points", Inches(0.4) + col_w + gap),
    ]):
        _add_rect(slide, x, col_top, col_w, col_h, theme["card_bg"])
        _add_rect(slide, x, col_top, col_w, Inches(0.6), theme["section_bg"])
        _add_rect(slide, x, col_top, Inches(0.08), Inches(0.6), theme["accent"])
        _textbox(slide, x + Inches(0.2), col_top + Inches(0.08),
                 col_w - Inches(0.3), Inches(0.45),
                 slide_data.get(hkey, ""), font_size=16, bold=True,
                 color=theme["header_fg"], font_name="Arial")

        pts = slide_data.get(pkey, [])
        pt_top = col_top + Inches(0.7)
        for j, pt in enumerate(pts):
            py = pt_top + j * Inches(0.7)
            _add_rect(slide, x + Inches(0.15), py, Inches(0.06), Inches(0.45), theme["accent2"])
            _textbox(slide, x + Inches(0.35), py,
                     col_w - Inches(0.55), Inches(0.55),
                     pt, font_size=13, bold=False, color=theme["body_fg"],
                     word_wrap=True, font_name="Arial")

    _set_notes(slide, slide_data.get("notes", ""))


# ─── 数据亮点页 ──────────────────────────────────────────────────────────────

def render_stats_slide(prs, slide_data: dict, theme: dict):
    """
    大数字展示页：类似参考 PPT slide5/9/10 的 +88%、+80% 等数据卡片
    """
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    _add_bg(slide, theme["content_bg"])

    header_h = Inches(1.3)
    _add_rect(slide, Inches(0), Inches(0), SLIDE_W, header_h, theme["header_bg"])
    _add_rect(slide, Inches(0), Inches(0), Inches(0.1), header_h, theme["accent"])
    _textbox(slide, Inches(0.35), Inches(0.18), Inches(12.5), Inches(0.7),
             slide_data.get("title", ""), font_size=26, bold=True,
             color=theme["header_fg"], font_name="Arial")

    sub = slide_data.get("subtitle", "")
    if sub:
        _textbox(slide, Inches(0.35), Inches(0.88), Inches(12.5), Inches(0.36),
                 sub, font_size=13, bold=False, color=theme["sub_fg"],
                 font_name="Arial")

    stats = slide_data.get("stats", [])
    n = len(stats)
    if n == 0:
        _set_notes(slide, slide_data.get("notes", ""))
        return

    content_top = header_h + Inches(0.4)
    content_h = SLIDE_H - content_top - Inches(0.4)
    card_w = (SLIDE_W - Inches(0.8) - Inches(0.25) * (n - 1)) / n
    card_h = content_h

    for i, stat in enumerate(stats):
        x = Inches(0.4) + i * (card_w + Inches(0.25))
        _add_rect(slide, x, content_top, card_w, card_h, theme["card_bg"])
        # 顶部强调色条
        _add_rect(slide, x, content_top, card_w, Inches(0.08), theme["accent"])

        val = stat.get("value", "")
        label = stat.get("label", "")

        # 大数字居中
        _textbox(slide, x + Inches(0.1), content_top + Inches(0.6),
                 card_w - Inches(0.2), Inches(1.6),
                 val, font_size=52, bold=True,
                 color=theme["stat_fg"], align=PP_ALIGN.CENTER,
                 font_name="Arial")

        # 分隔线
        _add_rect(slide, x + Inches(0.3), content_top + Inches(2.3),
                  card_w - Inches(0.6), Inches(0.04), theme["accent"])

        # 标签文字
        _textbox(slide, x + Inches(0.15), content_top + Inches(2.5),
                 card_w - Inches(0.3), card_h - Inches(2.7),
                 label, font_size=14, bold=False,
                 color=theme["sub_fg_dark"], align=PP_ALIGN.CENTER,
                 word_wrap=True, font_name="Arial")

    _set_notes(slide, slide_data.get("notes", ""))


# ─── 金句页 ──────────────────────────────────────────────────────────────────

def render_quote_slide(prs, slide_data: dict, theme: dict):
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    _add_bg(slide, theme["cover_bg"])

    # 大引号装饰
    _textbox(slide, Inches(0.6), Inches(0.4), Inches(2.5), Inches(1.8),
             "\u201C", font_size=110, bold=True, color=theme["accent"],
             font_name="Arial")

    # 左侧金色竖线
    _add_rect(slide, Inches(0.6), Inches(1.5), Inches(0.07), Inches(4.0), theme["accent"])

    # 引文
    _textbox(slide, Inches(1.1), Inches(1.6), Inches(11.0), Inches(3.8),
             slide_data.get("quote", ""), font_size=26, bold=False,
             italic=True, color=theme["title_fg"], word_wrap=True,
             font_name="Arial")

    # 来源
    source = slide_data.get("source", "")
    if source:
        _textbox(slide, Inches(1.1), Inches(5.8), Inches(11.0), Inches(0.7),
                 f"— {source}", font_size=16, bold=False,
                 color=theme["accent"], font_name="Arial")

    _set_notes(slide, slide_data.get("notes", ""))


# ─── 结尾页 ──────────────────────────────────────────────────────────────────

def render_closing_slide(prs, slide_data: dict, theme: dict):
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    _add_bg(slide, theme["cover_bg"])

    # 顶部细装饰线
    _add_rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(0.06), theme["accent"])

    # 主标题（THANK YOU 风格）
    _textbox(slide, Inches(1.0), Inches(2.3), Inches(11.3), Inches(1.8),
             slide_data.get("title", "THANK YOU"), font_size=56, bold=True,
             color=theme["title_fg"], align=PP_ALIGN.LEFT, font_name="Arial")

    # 金色横线
    _add_rect(slide, Inches(1.0), Inches(4.2), Inches(3.0), Inches(0.06), theme["accent"])

    # 寄语
    msg = slide_data.get("message", "")
    if msg:
        _textbox(slide, Inches(1.0), Inches(4.45), Inches(11.3), Inches(1.4),
                 msg, font_size=18, bold=False, color=theme["sub_fg"],
                 word_wrap=True, font_name="Arial")

    # 联系方式
    contact = slide_data.get("contact", "")
    if contact:
        _textbox(slide, Inches(1.0), Inches(6.5), Inches(11.3), Inches(0.5),
                 contact, font_size=13, bold=False, color=theme["accent"],
                 font_name="Arial")

    # 底部细装饰线
    _add_rect(slide, Inches(0), SLIDE_H - Inches(0.06), SLIDE_W, Inches(0.06), theme["accent"])

    _set_notes(slide, slide_data.get("notes", ""))


def _set_notes(slide, text: str):
    if not text:
        return
    notes_slide = slide.notes_slide
    tf = notes_slide.notes_text_frame
    if tf is not None:
        tf.text = text


# ─── 渲染分发 ────────────────────────────────────────────────────────────────

RENDERERS = {
    "title":     render_title_slide,
    "section":   render_section_slide,
    "bullets":   render_bullets_slide,
    "two_col":   render_two_col_slide,
    "stats":     render_stats_slide,
    "quote":     render_quote_slide,
    "closing":   render_closing_slide,
}


def build_pptx(plan: dict, style_override: str) -> bytes:
    # 确定最终主题：优先使用用户传入的 style，否则采用 LLM 规划的主题
    theme_key = style_override if style_override in THEMES else plan.get("theme", "dark")
    if theme_key not in THEMES:
        theme_key = "dark"
    theme = THEMES[theme_key]

    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    for slide_data in plan.get("slides", []):
        slide_type = slide_data.get("type", "bullets")
        renderer = RENDERERS.get(slide_type, render_bullets_slide)
        renderer(prs, slide_data, theme)

    buf = io.BytesIO()
    prs.save(buf)
    buf.seek(0)
    return buf.read()


async def gen_ppt(markdown_plan: dict, style: str = 'auto', filename: str = 'report.pptx') -> str:
    """
    生成PPT，返回下载地址
    Args:
        markdown_plan: md计划json
        style: 风格
        filename: 文件名（需携带扩展名）
    """
    # 在线程池中执行 pptx 构建，避免阻塞事件循环
    loop = asyncio.get_event_loop()
    pptx_bytes = await loop.run_in_executor(None, build_pptx, markdown_plan, style)

    # 上传文件服务器
    return file_upload_client.upload_file(pptx_bytes, filename)