from typing import Iterable, Iterator, Sequence, List, Callable, Optional


class ColUtil:
    """集合工具类，提供函数式风格的过滤/查找/映射静态方法。

    泛型方法：
    - where(): 按条件过滤，返回满足条件的元素列表
    - single(): 查找第一个满足条件的元素，无匹配返回 None
    - map(): 对每个元素执行转换函数，返回结果列表
    """

    @staticmethod
    def where[T](data: Iterable[T] | Iterator[T] | Sequence[T], fn: Callable[[T], bool]) -> List[T]:
        """过滤：保留 fn(item) 为 True 的元素，返回列表。"""
        return [it for it in data if fn(it)]

    @staticmethod
    def single[T](data: Iterable[T] | Iterator[T] | Sequence[T], fn: Callable[[T], bool]) -> Optional[T]:
        """查找：返回第一个 fn(item) 为 True 的元素，无匹配返回 None。"""
        return next(filter(lambda it: fn(it), data), None)

    @staticmethod
    def map[A, B](data: Iterable[A] | Iterator[A], fn: Callable[[A], B]) -> List[B]:
        """转换：对每个元素执行 fn 映射，返回结果列表。"""
        return [fn(it) for it in data]