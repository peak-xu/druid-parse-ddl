import os
import re

import requests
from datetime import datetime
from typing import BinaryIO, Union, List, Dict, Any
import logging

logger = logging.getLogger(__name__)


class FileUploadClient:
    """文件上传客户端"""

    def __init__(self):
        self.file_server_url = f"{os.getenv('file.host')}/persistentUpload"
        self.headers = {"Referer": "chatapi.nxin.com"}

    def upload_file(self, file: Union[BinaryIO, bytes], filename: str = "file") -> str:
        """
        上传文件到服务器

        Args:
            file: 文件对象或字节数据
            filename: 文件名（含扩展名）

        Returns:
            str: 文件URL，失败返回空字符串
        """
        filename = self.clear_filename(filename)
        path_filename, file_suffix = filename.split(".") # 通过文件后缀名对文件路径（目录）分类
        date_str = datetime.now().strftime("%Y_%m_%d")

        key = f"{file_suffix}/{date_str}/{path_filename}"
        files = {"file": (filename, file.read() if hasattr(file, 'read') else file)}

        try:
            response = requests.post(self.file_server_url, files=files, data={"key": key}, headers=self.headers)
            result = response.json()
            if result.get("code") == 0:
                return result.get("data", {}).get("url", "")
            else:
                logger.warning(f"文件上传失败: key={key}, response={result}")
                return ""
        except Exception as e:
            logger.error(f"文件上传异常: {e}")
            return ""


    @staticmethod
    def clear_filename(filename: str) -> str:
        filename = filename.strip()
        # 清理文件系统非法字符
        filename = re.sub(r'[<>:"/\\|?*\s]+', '_', filename)
        # 清理 URL 保留字符
        filename = re.sub(r'[#\[\]@!$&\'()*+,;=%]+', '_', filename)
        # 截断到 100 个字符，保留文件扩展名
        if len(filename) > 100:
            parts = filename.rsplit('.', 1)
            if len(parts) == 2 and len(parts[1]) <= 10:  # 有扩展名且扩展名合理
                name, ext = parts
                max_name_len = 100 - len(ext) - 1  # -1 for the dot
                filename = f'{name[:max_name_len]}.{ext}'
            else:  # 无扩展名或扩展名过长
                filename = filename[:100]
        return filename


file_upload_client = FileUploadClient()