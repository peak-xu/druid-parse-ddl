import json
from enum import Enum

from entity import ChatRequest

class EventType(str, Enum):
    GENERATING      = 'generating'
    CAPTION_SEARCH  = 'caption_search'
    CAPTION         = 'caption'
    PLUGIN          = 'plugin'
    REPLY           = 'reply'
    CAPTION_GENERATING = 'captionGenerating'
    CAPTION_REASONING = 'captionReasoning'


class StreamResponseGenerator:
    """SSE 流式响应生成器。

    将 AI 输出内容格式化为 SSE 事件的 JSON 字符串。
    支持多种事件类型（生成中/字幕搜索/字幕/插件/最终回复/推理链），
    客户端根据 type 字段区分处理。
    """

    def __init__(self, request: ChatRequest):
        self.feedback_id = request.feedback_id
        self.conversation_id = request.conversation_id

    def output(self, message_content: str, current_type: EventType = EventType.GENERATING, extra_info: dict = None):
        """生成一条 SSE 事件 JSON。

        Args:
            message_content: 消息正文
            current_type: 事件类型（GENERATING/REPLY/PLUGIN 等），决定 content_type 为 text 或 markdown
            extra_info: 额外字段（如图表 URL），会合并到输出的 JSON 中

        Returns:
            序列化为字符串的 JSON 对象，包含 type/feedback_id/conversation_id/content/content_type
        """
        response_data = {
            "type": current_type,
            "feedback_id": self.feedback_id,
            "conversation_id": self.conversation_id,
            "content": message_content,
            "content_type": "markdown" if current_type == EventType.REPLY else "text",
        }
        if extra_info:
            response_data.update(extra_info)
        return json.dumps(response_data, ensure_ascii=False)
