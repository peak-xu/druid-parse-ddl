import uuid
from json import dumps
from typing import Any, Mapping, Optional

from pydantic import BaseModel


def substr(content: Optional[str], first: int, length: int) -> str:
    """安全截取字符串子串，避免 IndexError。
    
    Args:
        content: 源字符串（可为 None）
        first: 起始索引
        length: 截取长度

    Returns:
        截取后的字符串，越界则返回可截取部分
    """
    if content is None:
        return ''
    if first > len(content) - 1:
        return ''
    if first + length > len(content) - 1:
        return content[first:]
    return content[first:first + length]


def get_uuid() -> str:
    """生成不含短横线的 UUID 字符串（32 位十六进制）。"""
    return str(uuid.uuid4()).replace('-', '')


def format_log_value(value: Any) -> str:
    """日志格式化：字符串/primitive 直接输出，对象转 JSON。"""
    if value is None:
        return ''
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, BaseModel):
        return value.model_dump_json(by_alias=True)
    if isinstance(value, Mapping):
        return dumps(dict(value), ensure_ascii=False)
    if isinstance(value, (list, tuple, set)):
        return dumps(list(value), ensure_ascii=False)
    try:
        return dumps(value, ensure_ascii=False)
    except (TypeError, ValueError):
        return str(value)