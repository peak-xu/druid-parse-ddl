"""
多模态工具
"""
import logging
from io import BytesIO

import requests
import pdfplumber
from pypdf import PdfReader

from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P

from pptx import Presentation


class WordUtil:

    def parse_word(self, file: BytesIO|str) -> str:
        """
        解析 Word 文件，提取所有文本内容。

        Args:
            file: 文件（支持 BytesIO、文件对象、文件路径等）

        Returns:
            提取的文本字符串
        """
        doc = Document(file)
        parts = []

        # 提取正文段落和表格（按文档顺序）
        for block in self._iter_block_items(doc):
            if block["type"] == "paragraph":
                para = block["element"]
                text = para.text.strip()
                if not text:
                    continue

                # 判断标题级别
                style_name = para.style.name if para.style else ""
                if style_name.startswith("Heading"):
                    level = style_name.replace("Heading", "").strip()
                    prefix = "#" * int(level) if level.isdigit() else "#"
                    parts.append(f"{prefix} {text}")
                else:
                    parts.append(text)

            elif block["type"] == "table":
                table = block["element"]
                parts.append(self._extract_table(table))

        return "\n\n".join(parts)


    @staticmethod
    def _iter_block_items(doc):
        """
        按顺序迭代文档主体中的段落和表格。
        """
        body = doc.element.body
        for child in body.iterchildren():
            if isinstance(child, CT_P):
                yield {"type": "paragraph", "element": Paragraph(child, doc)}
            elif isinstance(child, CT_Tbl):
                yield {"type": "table", "element": Table(child, doc)}


    @staticmethod
    def _extract_table(table) -> str:
        """
        将表格提取为 Markdown 格式字符串。
        """
        rows = []
        for i, row in enumerate(table.rows):
            cells = [cell.text.strip().replace("\n", " ") for cell in row.cells]
            rows.append("| " + " | ".join(cells) + " |")
            # 在表头后插入分隔行
            if i == 0:
                rows.append("| " + " | ".join(["---"] * len(cells)) + " |")
        return "\n".join(rows)


class PdfUtil:

    def parse_pdf(self, file: BytesIO|str) -> str:
        """
        解析 PDF 文件，提取所有文本和表格内容。

        Args:
            file: 文件（支持 BytesIO、文件对象、文件路径等）

        Returns:
            提取的文本字符串（Markdown 格式）
        """
        logging.getLogger("pdfminer").setLevel(logging.ERROR)
        # 读入内存，允许多次读取
        if isinstance(file, str):
            with open(file, 'rb') as f:
                file_stream = BytesIO(f.read())
        elif not isinstance(file, BytesIO):
            file_stream = BytesIO(file.read())
        else:
            file_stream = file

        # 先用 pypdf 获取元信息，检测是否为扫描版
        file_stream.seek(0)
        reader = PdfReader(file_stream)
        total_pages = len(reader.pages)

        # 快速检测：前两页能否提取到文字
        sample_text = "".join(
            reader.pages[i].extract_text() or ""
            for i in range(min(2, total_pages))
        )
        if not sample_text.strip():
            return (
                f"[提示] 该 PDF 共 {total_pages} 页，未检测到可提取的文本层，"
                "可能是扫描版图片 PDF，需要 OCR 才能提取内容。"
            )

        # 用 pdfplumber 正式提取（支持表格识别）
        file_stream.seek(0)
        parts = []

        with pdfplumber.open(file_stream) as pdf:
            for page_num, page in enumerate(pdf.pages, start=1):
                page_parts = []

                # 提取该页的表格区域，用于后续排除文本重叠
                tables = page.extract_tables()
                table_bboxes = [table_obj.bbox for table_obj in page.find_tables()]

                # 提取正文文本（排除表格覆盖区域）
                if table_bboxes:
                    # 裁去表格区域后再提取文字，避免重复
                    cropped = page
                    for bbox in table_bboxes:
                        try:
                            cropped = cropped.filter(
                                lambda obj, b=bbox: not self._in_bbox(obj, b)
                            )
                        except Exception:
                            pass
                    text = cropped.extract_text()
                else:
                    text = page.extract_text()

                if text and text.strip():
                    page_parts.append(text.strip())

                # 将表格转为 Markdown 格式
                for table in tables:
                    md_table = self._table_to_markdown(table)
                    if md_table:
                        page_parts.append(md_table)

                if page_parts:
                    parts.append(f"<!-- 第 {page_num} 页 -->\n" + "\n\n".join(page_parts))

        return "\n\n".join(parts)


    @staticmethod
    def _in_bbox(obj: dict, bbox: tuple) -> bool:
        """判断 PDF 对象是否位于指定边界框内。"""
        x0, top, x1, bottom = bbox
        obj_x0 = obj.get("x0", 0)
        obj_top = obj.get("top", 0)
        return x0 <= obj_x0 <= x1 and top <= obj_top <= bottom


    @staticmethod
    def _table_to_markdown(table: list[list]) -> str:
        """将 pdfplumber 表格（list of list）转为 Markdown 格式。"""
        if not table or not table[0]:
            return ""

        rows = []
        for i, row in enumerate(table):
            cells = [str(cell).strip().replace("\n", " ") if cell is not None else "" for cell in row]
            rows.append("| " + " | ".join(cells) + " |")
            if i == 0:
                rows.append("| " + " | ".join(["---"] * len(cells)) + " |")

        return "\n".join(rows)


class PPTUtil:

    def parse_ppt(self, file: BytesIO|str) -> str:
        """
        解析 PPTX 文件，提取所有幻灯片的文本、表格和备注内容。

        Args:
            file: 文件流对象（支持 BytesIO、文件对象、文件路径等）

        Returns:
            提取的文本字符串（Markdown 格式）
        """
        if isinstance(file, str):
            with open(file, 'rb') as f:
                file_stream = BytesIO(f.read())
        elif not isinstance(file, BytesIO):
            file_stream = BytesIO(file.read())
        else:
            file_stream = file

        prs = Presentation(file_stream)
        total_slides = len(prs.slides)
        slide_parts = []

        for slide_num, slide in enumerate(prs.slides, start=1):
            parts = [f"## 第 {slide_num} 页 / 共 {total_slides} 页"]

            # 提取幻灯片标题（如果有）
            title = self._get_slide_title(slide)
            if title:
                parts.append(f"### {title}")

            # 按形状从上到下、从左到右排序提取内容
            shapes = sorted(slide.shapes, key=lambda s: (s.top or 0, s.left or 0))

            for shape in shapes:
                content = self._extract_shape_content(shape, title)
                if content:
                    parts.append(content)

            # 提取演讲者备注
            notes = self._get_slide_notes(slide)
            if notes:
                parts.append(f"> **备注：** {notes}")

            slide_parts.append("\n\n".join(parts))

        return "\n\n---\n\n".join(slide_parts)

    # ──────────────────────────────────────────────
    # 内部辅助函数
    # ──────────────────────────────────────────────

    @staticmethod
    def _get_slide_title(slide) -> str:
        """提取幻灯片标题（占位符标题或第一个文本框）。"""
        if slide.shapes.title and slide.shapes.title.has_text_frame:
            return slide.shapes.title.text_frame.text.strip()
        return ""

    @staticmethod
    def _get_slide_notes(slide) -> str:
        """提取演讲者备注文本。"""
        try:
            notes_slide = slide.notes_slide
            tf = notes_slide.notes_text_frame
            text = tf.text.strip() if tf else ""
            return text
        except Exception:
            return ""

    def _extract_shape_content(self, shape, slide_title: str = "") -> str:
        """
        递归提取单个形状的文本内容，支持：
        - 普通文本框 / 占位符
        - 表格
        - 组合形状（GroupShape）
        """
        results = []

        # 跳过已作为标题输出的内容
        if shape == getattr(shape.part.slide.shapes, "title", None):
            return ""

        # 组合形状：递归处理子形状
        if shape.shape_type == 6:  # MSO_SHAPE_TYPE.GROUP = 6
            try:
                for child in shape.shapes:
                    child_content = self._extract_shape_content(child, slide_title)
                    if child_content:
                        results.append(child_content)
            except Exception:
                pass
            return "\n".join(results)

        # 表格
        if shape.has_table:
            return self._extract_table(shape.table)

        # 文本框 / 占位符
        if shape.has_text_frame:
            text = self._extract_text_frame(shape.text_frame, slide_title)
            if text:
                return text

        return ""

    @staticmethod
    def _extract_text_frame(text_frame, slide_title: str = "") -> str:
        """提取文本框内容，保留段落层级（列表项加 - 前缀）。"""
        lines = []
        for para in text_frame.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            # 跳过与幻灯片标题重复的内容
            if text == slide_title:
                continue
            level = para.level  # 0 = 顶级，1+ = 缩进层级
            indent = "  " * level
            prefix = f"{indent}- " if level > 0 else ""
            lines.append(f"{prefix}{text}")

        return "\n".join(lines)

    @staticmethod
    def _extract_table(table) -> str:
        """将 pptx 表格转为 Markdown 格式。"""
        rows = []
        for i, row in enumerate(table.rows):
            cells = [
                cell.text_frame.text.strip().replace("\n", " ")
                if cell.text_frame else ""
                for cell in row.cells
            ]
            rows.append("| " + " | ".join(cells) + " |")
            if i == 0:
                rows.append("| " + " | ".join(["---"] * len(cells)) + " |")
        return "\n".join(rows)


def parse_file_type(file_path) -> str:
    return str(file_path.rsplit('.', 1)[-1]).lower()


async def parse_file_url_content(file_url, file_type: str=None) -> str:
    if not file_type:
        file_type = parse_file_type(file_url)
    resp = requests.get(file_url)
    file_stream = BytesIO(resp.content)
    match file_type:
        case 'csv' | 'txt':
            return resp.text
        case 'docx':
            return WordUtil().parse_word(file_stream)
        case 'pdf':
            return PdfUtil().parse_pdf(file_stream)
        case 'pptx':
            return PPTUtil().parse_ppt(file_stream)
        case _:
            return ''