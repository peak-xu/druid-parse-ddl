import json
import random
import ssl
from collections.abc import AsyncGenerator, Generator
from io import StringIO
from logging import Logger
from typing import Literal, Mapping, Optional, Callable, Any, List, Awaitable, Union
from urllib.parse import quote
import certifi
from aiohttp import ClientSession, ClientResponse, FormData, ClientTimeout, TCPConnector

type HttpMethod = Literal['GET', "POST", 'PUT', 'DELETE', 'HEAD', 'OPTIONS', 'TRACE', 'CONNECT', 'get', 'post', 'put', 'delete', 'head', 'options', 'trace', 'connect']
type ArgValue = str | int | float | bool
type Args = Mapping[str, Union[ArgValue, List[ArgValue], None]]

class HttpClient:
    """通用 HTTP 客户端，基于 aiohttp 封装。

    功能：
    - 自动管理连接池（keepalive、连接上限 100）
    - 随机 User-Agent 反爬
    - 支持 GET/POST（JSON/Form）请求
    - TLS 证书绕过（内网环境）
    - 统一的错误日志和 null 值安全返回
    """

    def __init__(self, timeout: float, logger: Logger):
        self.agents = ['Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.76', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36']
        self.headers = {
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Sec-Ch-Ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Google Chrome";v="116"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1'
        }
        context = ssl.create_default_context(cafile=certifi.where())
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        self.timeout = ClientTimeout(connect=15, total=timeout)
        self.session = ClientSession(connector=TCPConnector(keepalive_timeout=15, limit=100, ssl_context=context))
        self.context = context
        self.logger = logger

    def __del__(self):
        self.session.close()

    async def request[T](self, method: HttpMethod, url: str, query: Optional[Args], data: Optional[bytes | FormData | AsyncGenerator[bytes, None] | Generator[bytes, None, None]], headers: Optional[Mapping[str, Optional[str]]], timeout: Optional[float], fn: Callable[[ClientResponse], Awaitable[T]]) -> Optional[T]:
        """通用 HTTP 请求方法。

        Args:
            method: 请求方法（GET/POST/PUT/DELETE 等）
            url: 目标 URL
            query: URL 查询参数
            data: 请求体
            headers: 自定义请求头（会合并默认 headers）
            timeout: 超时时间（秒），None 使用默认值
            fn: 响应处理回调，接收 ClientResponse 返回任意类型

        Returns:
            回调 fn 的返回值，请求失败时返回 None
        """
        header = self.headers.copy()
        header['User-Agent'] = self.agents[random.randint(0, len(self.agents) - 1)]
        if headers is not None:
            header.update({k: v for k, v in headers.items() if v is not None and len(v) > 0})
        try:
            async with self.session.request(method.upper(), url if query is None else f'{url}?{self._form_data(query)}', data=data, headers=header, ssl=self.context, timeout=ClientTimeout(total=timeout) if timeout is not None else self.timeout) as resp:
                if resp.status == 200:
                    return await fn(resp)
                else:
                    self.logger.error(f'请求失败[url:{url},method:{method},status:{resp.status}]')
                    return None
        except Exception as e:
            self.logger.error(f'请求接口失败[url:{url}]', exc_info=e, stack_info=True)
            self.logger.info(f'连接池统计：[{self.session.connector}]')
            return None

    async def post_json[T](self, url: str, query: Optional[Args], data: str | Mapping[str, Any], headers: Optional[Mapping[str, Optional[str]]], timeout: Optional[float], fn: Callable[[ClientResponse], Awaitable[T]]) -> Optional[T]:
        """POST JSON 请求。自动设置 Content-Type: application/json。"""
        content = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False)
        return await self.request('POST', url, query, content.encode('utf-8'), self._merge_headers(headers, {'Content-Type': 'application/json'}), timeout, fn)

    async def post_form[T](self, url: str, query: Optional[Args], data: str | Args, headers: Optional[Mapping[str, Optional[str]]], timeout: Optional[float], fn: Callable[[ClientResponse], Awaitable[T]]) -> Optional[T]:
        """POST Form 请求。自动设置 Content-Type: application/x-www-form-urlencoded。"""
        content = data if isinstance(data, str) else self._form_data(data)
        return await self.request('POST', url, query, content.encode('utf8'), self._merge_headers(headers, {'Content-Type': 'application/x-www-form-urlencoded'}), timeout, fn)
    async def get_json(self, url: str, query: Optional[Args], headers: Optional[Mapping[str, Optional[str]]], timeout: Optional[float]) -> Optional[Any]:
        """GET 请求并解析 JSON 响应。"""
        return await self.request('GET', url, query, None, headers, timeout, lambda x: x.json(content_type=None))

    async def download(self, url: str, query: Optional[Args], headers: Optional[Mapping[str, Optional[str]]], timeout: Optional[float]) -> bytes:
        """下载文件，返回原始 bytes。用于 OCR 等场景。"""
        return await self.request('GET', url, query, None, headers, timeout, lambda x: x.read())

    def _form_data(self, data: Args) -> str:
        si = StringIO()
        for k, v in data.items():
            if v is None:
                continue
            if isinstance(v, list):
                for x in v:
                    si.write(f'&{quote(k)}={self._encode(x)}')
            else:
                si.write(f'&{quote(k)}={self._encode(v)}')
        return si.getvalue()[1:]

    def _encode(self, value: ArgValue) -> str | int | float:
        if isinstance(value, str):
            return quote(value)
        elif isinstance(value, int):
            return value
        elif isinstance(value, float):
            return value
        else:
            return 'true' if value is True else 'false'

    def _merge_headers(self, headers: Optional[Mapping[str, Optional[str]]], hs: Optional[Mapping[str, Optional[str]]]) -> Optional[Mapping[str, Optional[str]]]:
        if headers is None and hs is None:
            return None
        if headers is None:
            return hs
        elif hs is not None:
            return {**headers, **hs}
