from typing import override, Sequence, Optional

from rapidfuzz import process

from .nlp import Nlp


class RapidfuzzNlp(Nlp):
    """基于 rapidfuzz 的模糊匹配实现。

    使用 process.extractOne 查找最佳匹配，
    相似度阈值 70 分以下视为无匹配返回 None。
    """

    @override
    def similarity(self, source: str, target: Sequence[str]) -> Optional[str]:
        v = process.extractOne(source, target)
        if v is None or v[1] < 70:
            return None
        return v[0]