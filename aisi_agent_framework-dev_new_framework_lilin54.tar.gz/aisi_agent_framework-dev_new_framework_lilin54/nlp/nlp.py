from abc import ABC, abstractmethod
from typing import Optional, Sequence


class Nlp(ABC):
    """NLP 文本相似度匹配抽象基类。

    提供字符串与候选序列的模糊匹配能力，
    返回最相似的候选字符串，或 None（低于阈值时）。
    """

    @abstractmethod
    def similarity(self, source: str, target: Sequence[str]) -> Optional[str]:
        pass