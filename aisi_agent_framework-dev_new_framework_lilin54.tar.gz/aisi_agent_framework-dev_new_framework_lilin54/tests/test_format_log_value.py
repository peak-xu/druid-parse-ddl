"""format_log_value 单元测试。"""

import json
import unittest

from entity import Tool
from entity.tool_arg import ToolArg
from utils.str_util import format_log_value


class TestFormatLogValue(unittest.TestCase):
    def test_string_direct(self):
        self.assertEqual(format_log_value('hello'), 'hello')

    def test_primitive_direct(self):
        self.assertEqual(format_log_value(42), '42')
        self.assertEqual(format_log_value(True), 'True')

    def test_dict_to_json(self):
        self.assertEqual(format_log_value({'a': 1}), '{"a": 1}')

    def test_list_to_json(self):
        self.assertEqual(format_log_value([1, 2]), '[1, 2]')

    def test_tool_to_json(self):
        tool = Tool(
            name='t1',
            description='desc',
            url='http://x',
            args=[ToolArg(name='p1', description='param')],
        )
        parsed = json.loads(format_log_value(tool))
        self.assertEqual(parsed['name'], 't1')

    def test_none_empty(self):
        self.assertEqual(format_log_value(None), '')


if __name__ == '__main__':
    unittest.main()
