"""工具参数抽取 prompt 与 helper 单元测试（不依赖 LLM）。"""

import unittest
from datetime import date
from logging import getLogger
from unittest.mock import MagicMock

from jinja2 import Environment, FileSystemLoader

from channelV2 import ChannelV2, _TOOL_PARAM_EXTRACTION_TMPL
from entity import ChatRequest, Env, Tool
from entity.chat_request import AgentData, Chat
from entity.tool_arg import ToolArg


def _make_tool(args: list[ToolArg]) -> Tool:
    return Tool(
        name='query_psy',
        description='查询 PSY 指标',
        url='http://example.com/psy',
        args=args,
    )


def _make_request(query: str, env: Env | None = None) -> ChatRequest:
    return ChatRequest(
        callback_api='',
        streaming_callback_api='',
        feedback_id='fb1',
        agent_data=AgentData(role_name='test', llm_name='test-model'),
        env=env or Env(),
        user_chats=[Chat(role='user', content=query)],
    )


class TestToolParamHelpers(unittest.TestCase):
    def test_tool_has_date_params_by_name(self):
        tool = _make_tool([
            ToolArg(name='start_date', description='开始日期'),
            ToolArg(name='farm_id', description='猪场 id'),
        ])
        self.assertTrue(ChannelV2._tool_has_date_params(tool))

    def test_tool_has_date_params_by_description(self):
        tool = _make_tool([
            ToolArg(name='begin', description='查询开始时间'),
        ])
        self.assertTrue(ChannelV2._tool_has_date_params(tool))

    def test_tool_has_no_date_params(self):
        tool = _make_tool([
            ToolArg(name='farm_id', description='猪场 id'),
            ToolArg(name='metric', description='指标名称'),
        ])
        self.assertFalse(ChannelV2._tool_has_date_params(tool))

    def test_format_tool_info(self):
        tool = _make_tool([
            ToolArg(
                name='start_date',
                arg_type='string',
                description='开始日期',
                required=True,
                default='2026-01-01',
            ),
            ToolArg(
                name='pig_farm_id',
                arg_type='integer',
                description='猪场 id',
                required=False,
                default=None,
            ),
        ])
        info = ChannelV2._format_tool_info(tool)
        self.assertIn('name=start_date', info)
        self.assertIn('default=2026-01-01', info)
        self.assertIn('name=pig_farm_id', info)
        self.assertIn('default=(无)', info)


class TestToolParamPromptRender(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.jinja_env = Environment(loader=FileSystemLoader('templates'))
        channel = ChannelV2(
            store=MagicMock(),
            client=MagicMock(),
            langflow_client=MagicMock(),
            knowledge_retriever=MagicMock(),
            llm_repository=MagicMock(),
            nlp=MagicMock(),
            env=self.jinja_env,
            logger=getLogger('test'),
        )
        self.channel = channel

    async def test_prompt_includes_date_rules_when_date_param(self):
        tool = _make_tool([
            ToolArg(name='start_date', description='开始日期'),
            ToolArg(name='end_date', description='结束日期'),
        ])
        request = _make_request(
            '帮我查询昨天的 PSY 数据',
            Env(user_id=1, pig_farm_id=100, farm_name='测试猪场'),
        )
        prompt = await self.channel._build_tool_param_extraction_prompt(
            tool, '帮我查询昨天的 PSY 数据', request
        )
        self.assertIn('函数参数抽取专家', prompt)
        self.assertIn('帮我查询昨天的 PSY 数据', prompt)
        self.assertIn('pigFarmId', prompt)
        self.assertIn('时间参数专项规则', prompt)
        self.assertIn('query_psy', prompt)
        self.assertIn(date.today().strftime('%Y-%m-%d'), prompt)

    async def test_prompt_omits_date_rules_without_date_param(self):
        tool = _make_tool([
            ToolArg(name='metric', description='指标名称', default='PSY'),
        ])
        request = _make_request('查一下 PSY')
        prompt = await self.channel._build_tool_param_extraction_prompt(
            tool, '查一下 PSY', request
        )
        self.assertNotIn('时间参数专项规则', prompt)
        self.assertIn('name=metric', prompt)

    async def test_template_file_renders_with_jinja_flags(self):
        """直接渲染模板，确认 has_date_params 条件分支有效。"""
        tmpl = self.jinja_env.get_template(_TOOL_PARAM_EXTRACTION_TMPL)
        with_date = await tmpl.render_async({
            'query': 'q1',
            'global_param': '{}',
            'tool_info': '- name=start_date',
            'system_date': '2026-06-08',
            'tool_name': 't1',
            'has_date_params': True,
        })
        without_date = await tmpl.render_async({
            'query': 'q2',
            'global_param': '{}',
            'tool_info': '- name=id',
            'system_date': '2026-06-08',
            'tool_name': 't2',
            'has_date_params': False,
        })
        self.assertIn('时间参数专项规则', with_date)
        self.assertNotIn('时间参数专项规则', without_date)


if __name__ == '__main__':
    unittest.main()
