from typing import Annotated, Literal, Optional, List, Union

from pydantic import BaseModel, Field

type Role = Literal['system', 'user', 'assistant', 'tool', 'function']


class ZxhToolCall(BaseModel):
    id: Annotated[str, Field(description='id')]
    name: Annotated[str, Field(description='工具名称')]
    arguments: Annotated[str, Field(description='参数')]


class ChatTextContentPart(BaseModel):
    type: Annotated[Literal['text'], Field(description='类型')]
    text: Annotated[str, Field(description='文本内容')]


class ChatImgContentPart(BaseModel):
    type: Annotated[Literal['image_url'], Field(description='类型')]
    url: Annotated[str, Field(description='图片base64地址')]
    detail: Annotated[Literal['auto', 'low', 'high'], Field(description='图片质量')]


class ChatAudioContentPart(BaseModel):
    type: Annotated[Literal['input_audio'], Field(description='类型')]
    data: Annotated[str, Field(description='音频base64地址')]
    format: Annotated[Literal['wav', 'mp3'], Field(description='音频类型')]


type ChatContentPart = Union[ChatTextContentPart, ChatImgContentPart, ChatAudioContentPart]


class Message(BaseModel):
    id: Annotated[str, Field(exclude=True, description='消息id', default='')]
    role: Annotated[Role, Field(description='角色')]
    content: Annotated[Optional[Union[str, List[ChatContentPart], List[dict]]], Field(description='内容', default=None)]
    assistant: Annotated[str, Field(description='来自于哪个助手')]
    tool_calls: Annotated[Optional[List[ZxhToolCall]], Field(description='工具调用', default=None)]
    tool_call_id: Annotated[Optional[str], Field(description='工具调用id', default=None)]
    function_name: Annotated[Optional[str], Field(description='函数名称', default=None)]
    reasoning_content: Annotated[Optional[str], Field(description='思维链', default=None)]


class AsyncTask(BaseModel):
    title: Annotated[str, Field(description='标题')]
    code: Annotated[str, Field(description='code')]
    process: Annotated[int, Field(description='process', default=1)]