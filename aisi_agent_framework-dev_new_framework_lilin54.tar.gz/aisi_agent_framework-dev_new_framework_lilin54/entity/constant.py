from enum import Enum

class EChartsType(Enum):
    """echarts类型枚举"""
    BAR     = ("bar",       "柱状图（条形图）")
    LINE    = ("line",      "折线图（趋势图）")
    PIE     = ("pie",       "扇形图（饼图）")
    SCATTER = ("scatter",   "散点图")
    GAUGE   = ("gauge",     "仪表盘")
    RADAR   = ("radar",     "雷达图")
    FUNNEL  = ("funnel",    "漏斗图")
    HEATMAP = ("heatmap",   "热力图")

    @classmethod
    def get_name(cls, chart_type: str) -> str:
        """根据echarts的type获取中文图表名"""
        for item in cls:
            if item.value[0] == chart_type:
                return item.value[1]
        return "图表"