from typing import Dict

Knowledge = Dict[str, str | int | float | bool]