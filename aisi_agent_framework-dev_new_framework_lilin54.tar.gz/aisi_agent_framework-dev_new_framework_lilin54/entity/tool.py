from json import dumps
from pydantic import BaseModel, Field
from typing import Annotated, Literal, Optional, List
from .tool_arg import ToolArg


class Tool(BaseModel):
    """工具"""
    name: Annotated[str, Field(description='工具名称')]
    summary: Annotated[str, Field(description='技能展示名称', default='')]
    description: Annotated[str, Field(description='描述信息')]
    category: Annotated[str, Field(description='分类', default=None)]
    return_description: Annotated[str, Field(description='返回值描述', default=None)]
    url: Annotated[Optional[str], Field(description='工具地址', default=None)]
    method: Annotated[Optional[Literal['GET', "POST", 'PUT', 'DELETE', 'post', 'get']], Field(description='请求方式', default=None)]
    content_type: Annotated[Optional[Literal['application/json', 'application/x-www-form-urlencoded']], Field(description='content type', default=None)]
    args: Annotated[List[ToolArg], Field(description='参数列表', default=[])]
    timeout: Annotated[Optional[float], Field(description='超时时间', default=5000000)]
    output_example: Annotated[Optional[str], Field(description='输出样式')]
    first_classify: Annotated[List[str], Field(description='一级分类', alias='first_classify', default=[])]
    second_classify: Annotated[List[str], Field(description='二级分类', alias='second_classify', default=[])]
    tags: Annotated[Optional[List[str]], Field(description='标签', default=None)]
    skill_caption: Annotated[Optional[str], Field(description='推理提示', default=None)]
    is_async: Annotated[Optional[int], Field(description='是否异步', default=False)]


    @staticmethod
    def parse_tool(skill, category: str) -> "Tool":
        from entity import Skill
        assert isinstance(skill, Skill)
        args = [ToolArg(name=p.name, location=p.location, arg_type=p.type, description=p.display_name, required=p.required, example=[], arg_mapping=p.arg_mapping, default=p.default) for p in skill.parameters.in_parameters]
        rd = {it.name: it.display_name for it in skill.parameters.out_parameters}
        return Tool(name=skill.name, summary=skill.summary, description=skill.description, return_description=dumps(rd, ensure_ascii=False), url=skill.url, method=skill.method, content_type='application/json', args=args, category=category, output_example=skill.analyze_output_example, tags=skill.tags, skill_caption=skill.skill_caption, is_async=skill.is_async)
