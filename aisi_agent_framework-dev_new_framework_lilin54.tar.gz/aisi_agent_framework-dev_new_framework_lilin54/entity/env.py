from typing import Annotated, Optional

from pydantic import BaseModel, Field


class Env(BaseModel):
    user_id: Annotated[int, Field(alias='userId', description='当前登录用户id', default=0)]
    enterprise_id: Annotated[int, Field(alias='enterpriseId', description='企业id', default=0)]
    group_id: Annotated[int, Field(alias='groupId', description='集团id', default=0)]
    location_info: Annotated[str, Field(description='当前城市', default='')]
    pig_farm_id: Annotated[int, Field(alias='pigFarmId', description='猪场id', default=0)]
    farm_name: Annotated[Optional[str], Field(description='猪场名称', default=None)]
    deep_analysis: Annotated[int, Field(alias='expert_channel', description='专家探索', default=0)]
    device_id: Annotated[Optional[str], Field(alias='deviceId', description='设备id', default=None)]
    reply_id: Annotated[Optional[str], Field(description='reply id', default=None)]