from typing import Annotated, Optional, Dict, List

from pydantic import BaseModel, Field

from .env import Env
from .message import Role


class InParameter(BaseModel, extra='ignore'):
    name: Annotated[Optional[str], Field(description='名称', default=None)]
    type: Annotated[Optional[str], Field(description='类型', default=None)]
    display_name: Annotated[Optional[str], Field(description='', default=None)]
    default: Annotated[Optional[str], Field(description='默认值', default=None)]
    arg_mapping: Annotated[Optional[Dict[str, str]], Field(description='', alias='input_param_enumeration', default=None)]
    location: Annotated[Optional[str], Field(description='参数位置', default='body')]
    required: Annotated[Optional[bool], Field(description='是否必传', default=True)]


class OutParameter(BaseModel, extra='ignore'):
    name: Annotated[Optional[str], Field(description='名称', default=None)]
    type: Annotated[Optional[str], Field(description='', default=None)]
    display_name: Annotated[Optional[str], Field(description='', default=None)]


class Parameters(BaseModel):
    in_parameters: Annotated[Optional[List[InParameter]], Field(description='入参', default=None)]
    out_parameters: Annotated[Optional[List[OutParameter]], Field(description='出参', default=None)]


class Skill(BaseModel, extra='ignore'):
    """技能"""
    url: Annotated[str, Field(description='技能地址', default=None)]
    summary: Annotated[str, Field(description='技能展示名称', default=None)]
    name: Annotated[str, Field(description='技能名称', default=None)]
    method: Annotated[str, Field(description='请求方式', default=None)]
    parameters: Annotated[Optional[Parameters], Field(description='参数', default=None)]
    description: Annotated[str, Field(description='技能描述', default=None)]
    first_classify: Annotated[List[str], Field(description='一级分类', default=[])]
    second_classify: Annotated[List[str], Field(description='二级分类', default=[])]
    analyze_output_example: Annotated[Optional[str], Field(description='输出样例', default=None)]
    tags: Annotated[Optional[List[str]], Field(description='标签', default=None)]
    skill_caption: Annotated[Optional[str], Field(description='', alias='caption', default=None)]
    is_async: Annotated[Optional[int], Field(description='是否异步', default=False)]


class FunctionSkillInfo(BaseModel, extra='ignore'):
    """技能串"""
    skill_execute_type: Annotated[int, Field(description='技能执行类型', default=None)]
    skill_meta_list: Annotated[List[Skill], Field(description='技能列表', default=None)]
    dataset_meta_list: Annotated[List[Skill], Field(description='数据集列表', default=None)]


class GeneralSkillInfo(BaseModel, extra='ignore'):
    """爱思大脑————关联技能"""
    dataset_meta_list: Annotated[List[Skill], Field(description='绑定数据集', default=None)]
    skill_meta_list: Annotated[List[Skill], Field(description='绑定工具', default=None)]
    skill_prompt: Annotated[Optional[str], Field(description='技能提示', default=None)]


class Chat(BaseModel):
    role: Annotated[Role, Field(description="角色", default=None)]
    content: Annotated[str, Field(description='聊天内容', default=None)]
    file_url: Annotated[Optional[str], Field(description='文件地址', alias='fileUrl', default=None)]
    file_type: Annotated[Optional[str], Field(description='文件类型', alias='fileType', default=None)]
    deep_thinking: Annotated[Optional[int], Field(description='深度思考开关', alias='deepThinking', default=0)]
    search_type: Annotated[Optional[int], Field(description='搜索开关', alias='searchType', default=0)]
    exId: Annotated[Optional[str], Field(description='设备id', default=None)]
    dataset_token: Annotated[Optional[str], Field(description='数据集token', alias='datasetToken', default='')]


class AgentData(BaseModel):
    role_name: Annotated[str, Field(description='角色名称', default=None)]
    role_settings: Annotated[str, Field(description='角色设定', default=None)]
    llm_name: Annotated[str, Field(description='模型名称', alias='model_name', default=None)]
    temperature: Annotated[str, Field(description='温度', default=None)]


class LangFlow(BaseModel):
    id: Annotated[str, Field(description='流程id')]
    name: Annotated[str, Field(description='流程名称')]
    description: Annotated[str, Field(description='流程描述')]
    node_id_list: Annotated[List[str], Field(description='节点id列表', alias='nodeIdList', default=[])]


class KnowledgeItem(BaseModel):
    id: str
    name: str
    type: int


class ZskKnowledge(BaseModel):
    knowledge_base_ids: Annotated[List[str], Field(description='库级范围', default=None)]
    knowledge_ids: Annotated[List[str], Field(description='知识 ID 级范围', default=None)]


class ChatRequest(BaseModel):
    """会话请求"""
    conversation_id: Annotated[Optional[str], Field(description='会话id', default=None)]
    callback_api: Annotated[str, Field(description='回调地址', default='')]
    streaming_callback_api: Annotated[str, Field(description='流式回调地址', default='')]
    feedback_id: Annotated[str, Field(description='反馈id', default=None)]
    agent_data: Annotated[AgentData, Field(description='代理信息', default=None)]
    env: Annotated[Env, Field(description='会话对象信息', default=None)]
    expert_mindset: Annotated[Optional[dict[str, str]], Field(description='专家思路', default=None)]
    knowledge_base: Annotated[List[KnowledgeItem], Field(description='涉及的知识库', default=[])]
    zsk_knowledge: Annotated[Optional[ZskKnowledge], Field(description='用户指定的知识库', default=None)]
    skills: Annotated[Optional[List[Skill]], Field(description='技能列表', default=None)]
    function_skills_info: Annotated[Optional[FunctionSkillInfo], Field(description='技能串', default=None)]
    user_chats: Annotated[List[Chat], Field(description='会话列表', default=None)]
    knowledge_base_type: Annotated[int, Field(description='选用的知识库类型', default=2)]
    langflow: Annotated[List[LangFlow], Field(description='langflow工作流列表', alias='workflowDetail', default=[])]
    at_general_skill_info: Annotated[Optional[GeneralSkillInfo], Field(description='@通用技能列表', default=None)]
    general_skills_info: Annotated[Optional[List[GeneralSkillInfo]], Field(description='通用技能列表（没@情况）', default=[])]
    at_dataset_meta_list: Annotated[Optional[List[Skill]], Field(description='@通用数据集列表', default=[])]
    dataset_meta_list: Annotated[Optional[List[Skill]], Field(description='通用数据集列表（没@情况）', default=[])]

    def have_zsk_knowledge(self) -> bool:
        try:
            return bool(self.zsk_knowledge.knowledge_base_ids) or bool(self.zsk_knowledge.knowledge_ids)
        except Exception as e:
            return False

    def have_at_skill(self) -> bool:
        if self.at_general_skill_info is None:
            return False
        info = self.at_general_skill_info
        return len(info.dataset_meta_list or []) > 0 or len(info.skill_meta_list or []) > 0

    def have_at_dataset_meta_list(self) -> bool:
        return len(self.at_dataset_meta_list) > 0


