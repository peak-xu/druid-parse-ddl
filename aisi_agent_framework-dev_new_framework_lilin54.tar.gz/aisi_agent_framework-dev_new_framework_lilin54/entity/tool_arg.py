from pydantic import BaseModel, Field
from typing import Annotated, Literal, List, Optional, Dict


class ToolArg(BaseModel):
    """工具参数"""
    name: Annotated[str, Field(description='参数名称')]
    location: Annotated[Optional[Literal['header', 'path', 'query', 'body']], Field(description='参数位置', default='body')]
    arg_type: Annotated[str, Field(description='参数类型', default='string')]
    description: Annotated[str, Field(description='参数描述', default='')]
    required: Annotated[bool, Field(description='是否必须', default=True)]
    example: Annotated[Optional[List[str]], Field(description='示例值')]
    arg_mapping: Annotated[Optional[Dict[str, str]], Field(description='参数映射', default=None)]
    default: Annotated[Optional[str], Field(description='默认值', default=None)]
