from typing import Type, List
from json import loads, dumps

from pydantic import BaseModel
from sqlalchemy import TypeDecorator, VARCHAR, Dialect


class EntityListType(TypeDecorator):
    """SQLAlchemy 自定义列类型：List[Pydantic BaseModel] ↔ VARCHAR（JSON 数组字符串）。

    自动处理序列化/反序列化：
    - 写入：对列表中每个元素调用 model_dump() 后 dumps 为 JSON 数组
    - 读取：loads 后逐元素 model_validate()

    Args:
        item_type: 列表元素的 Pydantic 模型类
        use_alias: 是否使用字段别名序列化
    """

    def __init__(self, item_type: Type[BaseModel], use_alias: bool = False) -> None:
        super().__init__()
        self.item_type = item_type
        self.use_alias = use_alias

    impl = VARCHAR
    def process_bind_param(self, value: List[Type[BaseModel]], dialect: Dialect):
        if value is None:
            return None
        return dumps([it.model_dump(by_alias=self.use_alias) for it in value], ensure_ascii=False)

    def process_result_value(self, value: str, dialect: Dialect):
        if value is None:
            return None
        return [self.item_type.model_validate(it) for it in loads(value)]