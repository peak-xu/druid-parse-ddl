from typing import Type

from pydantic import BaseModel
from sqlalchemy import TypeDecorator, Dialect, VARCHAR


class EntityType(TypeDecorator):
    """SQLAlchemy 自定义列类型：Pydantic BaseModel ↔ VARCHAR（JSON 字符串）。

    自动处理序列化/反序列化：
    - 写入：model_dump_json(by_alias=use_alias)
    - 读取：model_validate_json(value)

    Args:
        entity_type: 目标 Pydantic 模型类
        use_alias: 是否使用字段别名序列化
    """

    def __init__(self, entity_type: Type[BaseModel], use_alias: bool = False) -> None:
        super().__init__()
        self.entity_type = entity_type
        self.use_alias = use_alias

    impl = VARCHAR
    def process_bind_param(self, value: Type[BaseModel], dialect: Dialect):
        if value is None:
            return None
        return value.model_dump_json(by_alias=self.use_alias)

    def process_result_value(self, value: str, dialect: Dialect):
        if value is None:
            return None
        return self.entity_type.model_validate_json(value)