from typing import Annotated, List

from sqlmodel import SQLModel, Field, JSON

from entity import Env, Message, Tool, Knowledge
from .handlers import EntityType, EntityListType


class ChatMsg(SQLModel, table=True):
    """聊天信息"""
    __tablename__ = 'chat_msg'
    id: Annotated[str, Field(primary_key=True, description='会话id')]
    env: Annotated[Env, Field(sa_type=EntityType(entity_type=Env, use_alias=True), description='环境变量')]
    llm_id: Annotated[int, Field(description='大模型id')]
    temperature: Annotated[float, Field(description='温度')]
    tools: Annotated[List[Tool], Field(sa_type=EntityListType(item_type=Tool), description='工具列表')]
    knowledge: Annotated[Knowledge, Field(sa_type=JSON, description='知识库')]
    msg: Annotated[List[Message], Field(sa_type=EntityListType(item_type=Message), description='消息列表')]
