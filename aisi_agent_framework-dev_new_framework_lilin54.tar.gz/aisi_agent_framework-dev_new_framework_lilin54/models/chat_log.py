from typing import Annotated

from pydantic import PlainSerializer
from sqlalchemy import func
from sqlmodel import SQLModel, Field, Column, DateTime


class ChatLog(SQLModel, table=True):
    """会话日志"""
    __tablename__ = "chat_log"
    id: Annotated[int, Field(description='id', primary_key=True)]
    conversation_id: Annotated[str, Field(description='会话id')]
    stage: Annotated[str, Field(description='阶段描述')]
    agent_name: Annotated[str, Field(description='agent名称')]
    prompt: Annotated[str, Field(description='prompt')]
    content: Annotated[str, Field(description='内容')]
    answer: Annotated[str, Field(description='回复')]
    create_time: Annotated[str, Field(sa_column=Column('create_time', DateTime, default=func.now()), description='创建时间'), PlainSerializer(lambda x: x.strftime('%Y-%m-%d %H:%M:%S'), return_type=str)]
