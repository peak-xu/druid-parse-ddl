from typing import Annotated
from datetime import datetime

from sqlmodel import SQLModel, Field, Column, DateTime, Integer, String


class LlmConfig(SQLModel, table=True):
    """大模型配置"""
    __tablename__ = 'llm_config'
    id: Annotated[int, Field(primary_key=True, description='id')]
    type: Annotated[int, Field(description='类型')]
    name: Annotated[str, Field(description='名称')]
    endpoint: Annotated[str, Field(description='大模型url')]
    key: Annotated[str, Field(sa_column=Column('secret', String), description='大模型秘钥')]
    llm_name: Annotated[str, Field(sa_column=Column('model_name', String), description='模型名称')]
    llm_version: Annotated[str, Field(sa_column=Column('model_version', String), description='模型版本')]
    encoding_name: Annotated[str, Field(description='计算token的模型名称')]
    max_tokens: Annotated[int, Field(sa_column=Column('max_token', Integer),description='最大token数量')]
    max_response_token: Annotated[int, Field(description='最大回复token')]
    token_per_msg: Annotated[int, Field(description='消息间额外消耗token')]
    replay_token: Annotated[int, Field(description='回复额外消耗token')]
    create_time: Annotated[datetime, Field(sa_column=Column('create_time', DateTime, insert_default=datetime.now()), description='创建时间')]
    update_time: Annotated[datetime, Field(sa_column=Column('update_time', DateTime, insert_default=datetime.now(), onupdate=datetime.now()), description='更新时间')]