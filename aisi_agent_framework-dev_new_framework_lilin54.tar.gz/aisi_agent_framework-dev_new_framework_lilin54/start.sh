#!/bin/bash
# ═════════════════════════════════════════════════════════════════════════════════
# ChannelV2 服务启动脚本
# 用法: ./start.sh {prod|dev}
#   prod  →  生产环境 (.env)
#   dev   →  开发环境 (.env.dev)
# ═════════════════════════════════════════════════════════════════════════════════
set -euo pipefail

# ── 环境参数解析 ─────────────────────────────────────────────────────────────────
ENV_ARG="${1:-}"

if [ -z "$ENV_ARG" ]; then
    echo "错误: 缺少环境参数"
    echo "用法: $(basename "$0") {prod|dev}"
    echo "  prod  →  生产环境 (.env)"
    echo "  dev   →  开发环境 (.env.dev)"
    exit 1
fi

case "$ENV_ARG" in
    prod|dev) ;;
    *)
        echo "错误: 无效的环境参数 '$ENV_ARG'，仅支持: prod, dev"
        echo "用法: $(basename "$0") {prod|dev}"
        echo "  prod  →  生产环境 (.env)"
        echo "  dev   →  开发环境 (.env.dev)"
        exit 1
        ;;
esac

# 映射到实际文件名
case "$ENV_ARG" in
    prod) ENV_FILE=".env" ;;
    dev)  ENV_FILE=".env.dev" ;;
esac

# ── 配置 ────────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PYTHON_BIN="${PYTHON_BIN:-python}"
APP_MODULE="main:app"
LOG_DIR="$SCRIPT_DIR/logs"
STARTUP_LOG="$LOG_DIR/startup.log"
PID_FILE="$LOG_DIR/channelv2.pid"

# ── 日志函数 ────────────────────────────────────────────────────────────────────
log() {
    local level="$1"
    shift
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $*"
}

log_info()  { log "INFO"  "$@"; }
log_warn()  { log "WARN"  "$@"; }
log_error() { log "ERROR" "$@"; }

# ── 初始化日志目录 ───────────────────────────────────────────────────────────────
mkdir -p "$LOG_DIR"

# ═════════════════════════════════════════════════════════════════════════════════
# 启动前检查
# ═════════════════════════════════════════════════════════════════════════════════
log_info "=========================================="
log_info "ChannelV2 服务启动"
log_info "=========================================="
log_info "脚本路径  : $SCRIPT_DIR"
log_info "Python    : $PYTHON_BIN"
log_info "日志目录  : $LOG_DIR"

# 1) Python 可用性
if ! command -v "$PYTHON_BIN" &>/dev/null; then
    log_error "未找到 Python 解释器: $PYTHON_BIN"
    exit 1
fi
PYTHON_VERSION=$("$PYTHON_BIN" --version 2>&1)
log_info "Python 版本: $PYTHON_VERSION"

# 2) 环境变量文件
if [ ! -f "$ENV_FILE" ]; then
    log_error "未找到环境文件: $ENV_FILE"
    exit 1
fi
log_info "运行环境  : $ENV_ARG"
log_info "环境文件  : $ENV_FILE (已找到)"

# 3) 关键依赖预检
log_info "检查关键依赖..."
DEPS_OK=true
for pkg in fastapi uvicorn dotenv; do
    if ! "$PYTHON_BIN" -c "import $pkg" 2>/dev/null; then
        log_error "缺少依赖: $pkg"
        DEPS_OK=false
    fi
done
if [ "$DEPS_OK" = false ]; then
    log_error "请先执行: pip install -r requirements.txt"
    exit 1
fi
log_info "关键依赖检查通过"

# 4) 检查是否已有实例在运行
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 "$OLD_PID" 2>/dev/null; then
        log_warn "已有实例运行中 (PID=$OLD_PID)，尝试停止..."
        kill "$OLD_PID" 2>/dev/null || true
        sleep 2
        if kill -0 "$OLD_PID" 2>/dev/null; then
            log_error "无法停止旧实例，请手动处理 PID=$OLD_PID"
            exit 1
        fi
    fi
    rm -f "$PID_FILE"
fi

# ═════════════════════════════════════════════════════════════════════════════════
# 信号处理 — 优雅关闭
# ═════════════════════════════════════════════════════════════════════════════════
cleanup() {
    log_info "收到终止信号，正在停止服务..."
    if [ -n "${SERVER_PID:-}" ] && kill -0 "$SERVER_PID" 2>/dev/null; then
        kill -TERM "$SERVER_PID" 2>/dev/null
        wait "$SERVER_PID" 2>/dev/null || true
        log_info "服务已停止 (PID=$SERVER_PID)"
    fi
    rm -f "$PID_FILE"
    log_info "ChannelV2 服务退出: $(date '+%Y-%m-%d %H:%M:%S')"
    exit 0
}

trap cleanup SIGTERM SIGINT SIGHUP

# ═════════════════════════════════════════════════════════════════════════════════
# 启动服务
# ═════════════════════════════════════════════════════════════════════════════════
log_info "启动 uvicorn (host=${SERVER_HOST:-0.0.0.0}, port=${SERVER_PORT:-7998})..."

"$PYTHON_BIN" -u main.py "$ENV_ARG" \
    >>"$STARTUP_LOG" 2>&1 &

SERVER_PID=$!
echo "$SERVER_PID" > "$PID_FILE"

log_info "服务进程 PID: $SERVER_PID"
log_info "启动日志: tail -f $STARTUP_LOG"
log_info "应用日志: tail -f $SCRIPT_DIR/zxh.log"

# ── 等待服务就绪 ────────────────────────────────────────────────────────────────
HOST="${SERVER_HOST:-0.0.0.0}"
PORT="${SERVER_PORT:-7998}"
MAX_WAIT=30
WAIT_COUNT=0

while [ $WAIT_COUNT -lt $MAX_WAIT ]; do
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
        log_error "服务进程异常退出，请检查日志: $STARTUP_LOG"
        rm -f "$PID_FILE"
        exit 1
    fi
    if curl -sf "http://${HOST}:${PORT}/health" >/dev/null 2>&1; then
        HEALTH_RESP=$(curl -s "http://${HOST}:${PORT}/health")
        log_info "服务就绪! 健康检查: $HEALTH_RESP"
        log_info "=========================================="
        log_info "ChannelV2 运行中 (PID=$SERVER_PID)"
        log_info "=========================================="
        # 后台等待进程结束
        wait "$SERVER_PID"
        log_info "服务进程已退出"
        break
    fi
    sleep 1
    WAIT_COUNT=$((WAIT_COUNT + 1))
    if [ $((WAIT_COUNT % 5)) -eq 0 ]; then
        log_info "等待服务就绪... (${WAIT_COUNT}s/${MAX_WAIT}s)"
    fi
done

if [ $WAIT_COUNT -ge $MAX_WAIT ]; then
    log_error "服务启动超时 (${MAX_WAIT}s)，请检查日志: $STARTUP_LOG"
    kill "$SERVER_PID" 2>/dev/null || true
    rm -f "$PID_FILE"
    exit 1
fi
