"""
日志配置模块
- 每天一个日志文件（按日期自动轮转）
- 同时输出到控制台和文件
- 不影响 print 语句
"""
import logging
import os
import sys
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime


# ANSI 颜色代码
class Colors:
    RESET = '\033[0m'
    # 前景色
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    # 亮色
    BRIGHT_BLACK = '\033[90m'
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    # 粗体
    BOLD = '\033[1m'


class ColoredFormatter(logging.Formatter):
    """彩色日志格式化器"""
    
    # 日志级别颜色映射
    LEVEL_COLORS = {
        'DEBUG': Colors.BRIGHT_BLACK,
        'INFO': Colors.BRIGHT_GREEN,
        'WARNING': Colors.BRIGHT_YELLOW,
        'ERROR': Colors.BRIGHT_RED,
        'CRITICAL': Colors.BOLD + Colors.BRIGHT_RED,
    }
    
    def format(self, record):
        import re
        
        # 保存原始值
        levelname_orig = record.levelname
        name_orig = record.name
        
        # 时间 - 青色
        log_time = Colors.CYAN + self.formatTime(record, self.datefmt) + Colors.RESET
        
        # 级别 - 根据级别不同颜色
        level_color = self.LEVEL_COLORS.get(record.levelname, Colors.WHITE)
        levelname = level_color + record.levelname + Colors.RESET
        
        # 模块名 - 蓝色
        name = Colors.BLUE + record.name + Colors.RESET
        
        # 文件名和行号 - 灰色
        location = Colors.BRIGHT_BLACK + f'{record.filename}:{record.lineno}' + Colors.RESET
        
        # 消息 - 给数字添加颜色
        message = record.getMessage()
        # 匹配数字（整数、小数、百分比等）
        message = re.sub(
            r'\b(\d+\.?\d*%?|\d*\.\d+%?)\b',
            Colors.BRIGHT_MAGENTA + r'\1' + Colors.RESET,
            message
        )
        
        # 组合格式化字符串
        formatted = f'{log_time} - {levelname} - {name} - {location} - {message}'
        
        # 如果有异常信息，添加异常堆栈
        if record.exc_info:
            if not record.exc_text:
                record.exc_text = self.formatException(record.exc_info)
        if record.exc_text:
            formatted += '\n' + record.exc_text
        if record.stack_info:
            formatted += '\n' + self.formatStack(record.stack_info)
            
        return formatted


def setup_logging(log_dir='log', log_level='INFO'):
    """
    配置项目日志系统
    
    Args:
        log_dir: 日志文件目录，默认为 'log'
        log_level: 日志级别，默认为 INFO
    """
    # 确保日志目录存在
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 日志文件路径（使用当前日期）
    log_file = os.path.join(log_dir, f'{datetime.now().strftime("%Y-%m-%d")}.log')
    
    # 创建根日志记录器
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    
    # 清除已有的处理器（避免重复配置）
    if root_logger.handlers:
        root_logger.handlers.clear()
    
    # 日志格式 - 文件用普通格式（不带颜色）
    file_formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(name)s - %(filename)s:%(lineno)d - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 控制台用彩色格式
    console_formatter = ColoredFormatter(datefmt='%Y-%m-%d %H:%M:%S')
    
    # 1. 文件处理器 - 每天轮转一次
    file_handler = TimedRotatingFileHandler(
        filename=log_file,
        when='midnight',  # 每天午夜轮转
        interval=1,       # 间隔1天
        backupCount=30,   # 保留30天的日志
        encoding='utf-8'
    )
    file_handler.setLevel(log_level)
    file_handler.setFormatter(file_formatter)  # 文件不用彩色
    # 设置日志文件名后缀格式
    file_handler.suffix = "%Y-%m-%d.log"
    root_logger.addHandler(file_handler)
    
    # 2. 控制台处理器 - INFO 级别输出到 stdout（彩色）
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_handler.setFormatter(console_formatter)  # 控制台用彩色
    # 只处理 INFO 及以下级别
    console_handler.addFilter(lambda record: record.levelno <= logging.INFO)
    root_logger.addHandler(console_handler)
    
    # 3. 错误控制台处理器 - WARNING 及以上输出到 stderr（彩色）
    error_console_handler = logging.StreamHandler(sys.stderr)
    error_console_handler.setLevel(logging.WARNING)
    error_console_handler.setFormatter(console_formatter)  # 控制台用彩色
    root_logger.addHandler(error_console_handler)
    
    # 禁用第三方库的日志输出到控制台（避免进度条等信息干扰）
    # 这些库的日志仍会写入文件，但不会在控制台显示
    logging.getLogger('sentence_transformers').setLevel(logging.WARNING)
    logging.getLogger('transformers').setLevel(logging.WARNING)
    logging.getLogger('torch').setLevel(logging.WARNING)
    logging.getLogger('faiss').setLevel(logging.WARNING)
    logging.getLogger('tqdm').setLevel(logging.WARNING)
    
    return root_logger


def get_logger(name):
    """
    获取指定名称的日志记录器
    
    Args:
        name: 日志记录器名称，通常使用 __name__
    
    Returns:
        logging.Logger: 日志记录器实例
    """
    return logging.getLogger(name)
