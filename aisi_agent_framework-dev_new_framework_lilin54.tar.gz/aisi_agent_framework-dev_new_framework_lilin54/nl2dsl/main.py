import json
import logger_config
import os

from config import LOG_LEVEL

logger_config.setup_logging(log_dir='log', log_level=LOG_LEVEL)

import traceback

import uvicorn
from fastapi import FastAPI
from fastapi import Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from langgraph.graph.state import CompiledStateGraph
from graph.query_agent_graph import QueryAgentGraph
from graph.query_agent_state import QueryAgentState

# 节点名 → 展示标签映射（供前端展示用）
NODE_LABELS = {
    "preprocessing":       "预处理",
    "dataEnrichment":      "数据补全",
    "tableMatching":       "表匹配",
    "fieldExtraction":     "字段提取",
    "dslBuilding":         "DSL 构建",
    "sqlExecution":        "SQL 执行",
    "knowledgeRetrieval":  "知识检索",
    "ragSummarization":    "RAG 摘要",
}

app = FastAPI(title="NL2DSL Query Agent")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

graph: CompiledStateGraph = QueryAgentGraph().build()


def _sse(payload: dict) -> str:
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


NODE_ORDER = list(NODE_LABELS.keys())


def _next_node(after: str | None) -> str | None:
    if after is None:
        return NODE_ORDER[0] if NODE_ORDER else None
    try:
        idx = NODE_ORDER.index(after)
    except ValueError:
        return None
    return NODE_ORDER[idx + 1] if idx + 1 < len(NODE_ORDER) else None


def _msg_content(msg) -> str:
    content = msg.content
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
        return "".join(parts)
    return str(content) if content else ""


async def agent_stream_response(query, extra_info):
    """流式处理：逐节点推送进度 + token 流"""
    state = QueryAgentState()
    state.user_query = query
    state.extra_info = extra_info

    yield _sse({"type": "start", "content": "🚀 开始处理..."})

    started_nodes: set[str] = set()
    completed_nodes: set[str] = set()

    first = _next_node(None)
    if first:
        yield _sse({"type": "node_start", "node": first, "label": NODE_LABELS[first]})
        started_nodes.add(first)

    try:
        async for chunk in graph.astream(
            state,
            stream_mode=["updates", "messages"],
            version="v2",
        ):
            if chunk["type"] == "updates":
                for node_name in chunk["data"]:
                    if node_name not in NODE_LABELS or node_name in completed_nodes:
                        continue
                    yield _sse({
                        "type":  "node_end",
                        "node":  node_name,
                        "label": NODE_LABELS[node_name],
                    })
                    completed_nodes.add(node_name)
                    nxt = _next_node(node_name)
                    if nxt and nxt not in started_nodes:
                        yield _sse({
                            "type":  "node_start",
                            "node":  nxt,
                            "label": NODE_LABELS[nxt],
                        })
                        started_nodes.add(nxt)

            elif chunk["type"] == "messages":
                # nostream 标签在此模式下生效，中间节点 LLM 不会进入此流
                msg, _metadata = chunk["data"]
                content = _msg_content(msg)
                if content:
                    yield _sse({"type": "token", "content": content})

        yield _sse({"type": "end", "content": "✅ 完成"})

    except Exception as e:
        traceback.print_exc()
        yield _sse({"type": "error", "content": f"错误: {str(e)}"})


async def agent_response(query: str):
    """非流式：等待全部完成后一次性返回 summary"""
    state = QueryAgentState()
    state.user_query = query

    yield _sse({"type": "start", "content": "🚀 开始处理..."})

    try:
        state_result = await graph.ainvoke(state)
        yield _sse({"type": "response", "content": state_result["summary"]})
        yield _sse({"type": "end", "content": "✅ 完成"})
    except Exception as e:
        traceback.print_exc()
        yield _sse({"type": "error", "content": f"错误: {str(e)}"})


@app.post("/chat")
async def chat(request: Request):
    body = await request.json()
    return StreamingResponse(agent_response(body["query"]), media_type="text/event-stream")


@app.post("/chat/stream")
async def chat_stream(request: Request):
    body = await request.json()
    query = body.get("query")
    extra_info: dict = body.get("extra_info", {})

    return StreamingResponse(agent_stream_response(query, extra_info), media_type="text/event-stream")


if __name__ == "__main__":
    print("=" * 60)
    print("🚀 NL2SQL Query Agent")
    print("📍 http://localhost:8000")
    print("=" * 60)
    uvicorn.run(app, host="0.0.0.0", port=8000)