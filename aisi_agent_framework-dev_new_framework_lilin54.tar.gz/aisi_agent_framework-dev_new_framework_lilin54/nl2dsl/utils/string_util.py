import re
import uuid


def get_prompt_template(template_name: str) -> str:
    with open(f'prompt_templates/{template_name}', 'r', encoding='utf-8') as f:
        return f.read()


def get_uuid() -> str:
    return str(uuid.uuid4()).replace('-', '').upper()


def extract_json(llm_response: str) -> str:
    patterns = [
        r"```json\s+(.*?)```",  # 优先匹配带 ```json 标签的代码块
        r"```(.*?)```",         # 再匹配普通代码块
        r"任务：(\[.*?\])",      # 特定格式，任务：[json]
        r"(\[.*?\])",           # JSON 数组
        r"(\{.*?\})",           # JSON 对象
    ]
    for pattern in patterns:
        matches = re.findall(pattern, llm_response, re.DOTALL)
        if matches:
            return matches[-1].strip()
    return ''


def extract_code_block(llm_response: str, code_block_type: str = '') -> str:
    """从LLM响应中提取指定类型的代码块"""
    code_block_type = code_block_type.strip().lower()
    patterns = [
        rf"```{code_block_type}\s*(.*?)```",   # 优先匹配带 {code_block_type} 标签的代码块
        r"```(.*?)```",         # 其次匹配普通代码块
    ]
    for pattern in patterns:
        match = re.findall(pattern, llm_response, re.DOTALL | re.IGNORECASE)
        if match:
            return match[-1].strip()
    # 如果没有代码块，返回原始响应
    return llm_response.strip()


def cut_ddl(ddl: str) -> str:
    matches = list(re.finditer(r"COMMENT\s*'.*?'", ddl, re.S))
    return (ddl[:matches[-1].end()] + ";") if matches else ddl