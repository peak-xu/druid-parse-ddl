"""Doris数据库工具类"""

import logging
import os
from typing import Dict, List, Any, Optional, Union
import pymysql
from pymysql.constants import CLIENT
from pymysql.cursors import DictCursor
from pymysql.connections import Connection

from config import DORIS_HOST, DORIS_PORT, DORIS_USER, DORIS_PASSWORD

logger = logging.getLogger(__name__)

class DorisDBUtil:

    def __init__(self):
        self._connection: Optional[Connection] = None

    def _initialize(self):
        """初始化Doris数据库连接"""
        if self._connection is None:
            try:
                self._connection = pymysql.connect(
                    host=DORIS_HOST,
                    port=DORIS_PORT,
                    user=DORIS_USER,
                    password=DORIS_PASSWORD,
                    database='',
                    connect_timeout=10,
                    read_timeout=10,
                    charset='utf8mb4',
                    cursorclass=DictCursor,
                    client_flag=CLIENT.MULTI_STATEMENTS,
                    autocommit=False
                )
                logger.info("Doris数据库连接建立成功")
            except Exception as e:
                logger.error(f"Doris数据库连接失败: {e}")
                raise

    def _ensure_connection(self):
        try:
            if self._connection is None:
                self._initialize()
            else:
                self._connection.ping(reconnect=True)
        except Exception as e:
            logger.warning(f"Doris连接失效，重新初始化：{e}")
            self.close()
            self._initialize()

    def execute_query(self, sql: str, params: Optional[Union[str, tuple, dict]] = None) -> List[Dict[str, Any]]:
        """执行查询SQL语句"""
        self._ensure_connection()
        params = (params,) if isinstance(params, str) else params
        try:
            with self._connection.cursor() as cursor:
                cursor.execute(sql, params)
                result = cursor.fetchall()
                logger.info(f"查询执行成功，返回 {len(result)} 条记录")
                return result
        except Exception as e:
            logger.error(f"SQL:{sql} 查询执行失败: {e}")
            raise

    def execute_query_with_msg(
            self, sql: str, params: Optional[Union[str, tuple, dict]] = None
    ) -> tuple[List[Dict[str, Any]], str]:
        """执行查询SQL语句"""
        self._ensure_connection()
        params = (params,) if isinstance(params, str) else params
        try:
            with self._connection.cursor() as cursor:
                result = []
                cursor.execute(sql, params)
                if cursor.description:
                    result = cursor.fetchall()
                logger.info(f"查询执行成功，返回 {len(result)} 条记录")
                return result, ''
        except Exception as e:
            logger.exception(f"查询执行失败: {e}")
            return [], str(e)

    def close(self):
        """关闭数据库连接"""
        if self._connection:
            self._connection.close()
            self._connection = None
            logger.info("Doris数据库连接已关闭")


# 模块级实例
doris = DorisDBUtil()