import logging
import os
from enum import Enum

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI


load_dotenv()
logger = logging.getLogger(__name__)


# 日志级别
LOG_LEVEL = os.getenv('LOG_LEVEL').upper()

# Doris连接信息
DORIS_DRIVER = os.getenv('DORIS.DRIVER')
DORIS_HOST = os.getenv('DORIS.HOST')
DORIS_PORT = int(os.getenv('DORIS.PORT'))
DORIS_DATABASE = os.getenv('DORIS.DATABASE')
DORIS_USER = os.getenv('DORIS.USER')
DORIS_PASSWORD = os.getenv('DORIS.PASSWORD')

# 数据库表元信息接口
TABLE_META_URL = os.getenv('TABLE_META_URL')
# 生效的表(格式：“数据库名.表名”，多个表名用英文逗号隔开)
ENABLE_TABLES = os.getenv('ENABLE_TABLES')


class LLMType(str, Enum):
    BASE        = 'BASE'
    CODE        = 'CODE'
    THINKING    = 'THINKING'
    MULTIMODAL  = 'MULTIMODAL'


class LlmFactory:
    @staticmethod
    def create_llm(llm_type: LLMType = LLMType.CODE, *, stream_output: bool = False) -> ChatOpenAI:
        """
        创建 LLM 实例。

        stream_output=False（默认）时打上 LangGraph 的 nostream 标签，
        中间节点的 LLM 结果不会进入 stream_mode="messages" 流。
        注意：nostream 对 astream_events / on_chat_model_stream 无效。
        """
        llm_type = llm_type.value
        logger.info(f'加载{os.getenv(f'{llm_type}_MODEL.NAME')}模型')
        llm = ChatOpenAI(
            model=os.getenv(f'{llm_type}_MODEL.NAME'),
            base_url=os.getenv(f'{llm_type}_MODEL.BASE_URL'),
            api_key=os.getenv(f'{llm_type}_MODEL.API_KEY'),
            temperature=0 if llm_type == LLMType.CODE else 0.7
        )
        if not stream_output:
            llm = llm.with_config({"tags": ["nostream"]})
        return llm