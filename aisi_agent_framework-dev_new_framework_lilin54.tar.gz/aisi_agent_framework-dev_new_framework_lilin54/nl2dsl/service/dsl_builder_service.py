class DSLBuilderService:

    def __init__(self):
        pass


    def build_sql(self, table_name: str, dimensions: list, metrics: list, filter_map: dict):
        """
        构建 SQL (简化版本，带 SQL 注入防护)
        Args:
            table_name: 表名
            dimensions: 维度列表
            metrics: 指标列表
            filter_map: 过滤条件
        Returns:
            sql: 生成的SQL
        """
        sql = 'SELECT '
        select_fields = []

        # 添加维度+指标字段
        for field in (dimensions + metrics) or []:
            select_fields.append(field)

        sql += ', '.join(select_fields) if select_fields else '*'

        # FROM 部分（表名已校验）
        sql += f' FROM {table_name}'

        # WHERE 部分（使用转义方法处理值）
        if filter_map:
            sql += ' WHERE '
            conditions = []
            for field, value in filter_map.items():
                if field == 'data_date':
                    if value:
                        if start := value.get('start'):
                            conditions.append(f"data_date >= '{start}'")
                        if end := value.get('end'):
                            conditions.append(f"data_date <= '{end}'")
                else:
                    if isinstance(value, str):
                        conditions.append(f'{field} = {self._escape_sql_string(value)}')
                    else:
                        conditions.append(f'{field} = {value}')
            sql += ' AND '.join(conditions)
        return sql + ';'


    @staticmethod
    def _escape_sql_string(value:str) -> str:
        """转义 SQL 字符串值，防止 SQL 注入"""
        if value is None:
            return "NULL"
        escaped = value.replace("'", "''")
        return f"'{escaped}'"