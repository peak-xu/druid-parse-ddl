class KnowledgeBaseService:

    def __init__(self):
        self.knowledge_base: dict[str, str] = {}
        self._init_knowledge_base()

    def _init_knowledge_base(self):
        # PSY 知识
        self.knowledge_base['PSY'] = 'PSY是指每头母猪每年所能提供的断奶仔猪头数，是衡量猪场效益和母猪繁殖成绩的核心指标。计算公式：PSY = 母猪年产胎次 × 平均窝产活仔数 × 哺乳仔猪成活率。行业参考标准：国内平均水平约18-20头，优秀猪场可达24头以上，国际领先水平可达30头。解读思路：(1) PSY越高，说明母猪繁殖效率越好，单头母猪贡献越大；(2) 需结合饲料成本、死淘率综合分析；(3) PSY过高可能增加管理难度，需关注仔猪质量而非仅追求数量。'
        # MSY 知识
        self.knowledge_base['MSY'] = 'MSY为每年每头母猪出栏肥猪头数，是衡量猪场整体经济效益的关键指标。计算公式：MSY = PSY × 育肥猪成活率。行业参考标准：国内平均水平约16-18头，优秀猪场可达20头以上。解读思路：(1) MSY直接反映猪场的变现能力；(2) 需关注育肥阶段的饲养管理和疾病防控；(3) MSY与PSY、育肥成活率三者需协调发展。'
        # 出栏率 知识
        self.knowledge_base['out_rate'] = '出栏率是反映养殖效率的重要指标。计算公式：出栏率 = 出栏数量 / 期初存栏 × 100%。解读思路：(1) 出栏率越高，说明养殖周转越快，资金效率越高；(2) 需结合存栏结构分析；(3) 过高出栏率可能影响可持续性。'
        # 产奶量 知识
        self.knowledge_base['milk_yield'] = '日产奶量是衡量奶牛产奶能力的核心指标。计算公式：日产奶量 = 当日总产量 / 泌乳牛头数。行业参考标准：优质牧场日产奶量可达30-40公斤/头。解读思路：(1) 产奶量与饲料质量、饲养管理密切相关；(2) 需关注奶品质指标如乳脂率、乳蛋白率；(3) 高产奶量需平衡奶牛健康和繁殖性能。'
        # 繁殖率 知识
        self.knowledge_base['breeding_rate'] = '繁殖率是衡量奶牛繁殖性能的重要指标。计算公式：繁殖率 = 成功配种数 / 配种总数 × 100%。行业参考标准：健康牧场繁殖率应在60%-80%之间。解读思路：(1) 繁殖率直接影响产奶周期和牛群更新；(2) 需关注配种时机和技术；(3) 过高或过低都需分析原因。'


    def get_interpretations(self, metric_list: list[str]) -> dict[str, str]:
        """
        根据指标列表获取解读
        """
        result = {}
        if not metric_list:
            return result
        for metric in metric_list:
            interpretation = self.knowledge_base.get(metric)
            result[metric] = interpretation if interpretation else "暂无该指标的解读知识，请咨询专业人士。"
        return result