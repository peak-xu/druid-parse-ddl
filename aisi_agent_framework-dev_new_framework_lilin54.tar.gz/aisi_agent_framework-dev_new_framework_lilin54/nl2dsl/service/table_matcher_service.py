import json
import logging
import traceback

import requests
from langchain_core.messages import HumanMessage, SystemMessage

from config import TABLE_META_URL, ENABLE_TABLES, LlmFactory
from entity.table_meta import TableMeta, FieldMeta
from test.temp.temp_table_metas import temp_table_desc_map
from utils.string_util import get_prompt_template

logger = logging.getLogger(__name__)


enable_tables = [t.strip() for t in ENABLE_TABLES.split(',') if t.strip()]


def get_ori_table_metas() -> list[TableMeta]|None:
    """
    获取数据库表元信息
    """
    try:
        response = requests.post(TABLE_META_URL, timeout=10)

        if response.status_code != 200:
            raise Exception(f"获取数据库表元信息失败，状态码：{response.status_code}")

        logger.info(f'获取数据库表元信息成功')
        return response.json()['data']
    except Exception as e:
        logger.error(f'获取数据库表元信息失败：{str(e)}')
        traceback.print_exc()


def init_table_meta():
    """
    初始化表Meta数据
    """
    table_meta_list: list[TableMeta] = []

    for ori_table_meta in get_ori_table_metas():
        # 拼接数据库名和表名
        table_name=f"{ori_table_meta['table_schema']}.{ori_table_meta['table_name']}"

        # 过滤不需要的表
        if table_name not in enable_tables:
            continue

        columns = json.loads(ori_table_meta['COLUMNS'])
        if table_name == 'nxin_hqb.vw_hqb_price_day_area':
            # 跳过表`nxin_hqb.vw_hqb_price_day_area`
            continue
        if table_name == 'nxin_hqb.hqb_price_day':
            # 把表`nxin_hqb.hqb_price_day`替换为表`nxin_hqb.vw_hqb_price_day_area`，并添加`area_full_name`字段
            table_meta = TableMeta(
                table_name='nxin_hqb.vw_hqb_price_day_area',
                table_desc=temp_table_desc_map.get('nxin_hqb.hqb_price_day'),
                field_info=[
                    FieldMeta(
                        field_name=column['column_name'],
                        field_name_cn=column['column_comment'],
                        field_name_alias="",
                        field_type=column['data_type'],
                        stat_scope="",
                        field_desc="",
                    )
                    for column in columns
                ]
            )
            table_meta.field_info.append(
                FieldMeta(
                    field_name='area_full_name',
                    field_name_cn='区域中文名',
                    field_name_alias="",
                    field_type='varchar',
                    stat_scope="",
                    field_desc="",
                )
            )
        else:
            # 其他表正常初始化
            table_meta = TableMeta(
                table_name=table_name,
                table_desc=temp_table_desc_map.get(table_name, ori_table_meta['table_comment']),
                field_info=[
                    FieldMeta(
                        field_name=column['column_name'],
                        field_name_cn=column['column_comment'],
                        field_name_alias="",
                        field_type=column['data_type'],
                        stat_scope="",
                        field_desc="",
                    )
                    for column in columns
                ]
            )
        table_meta_list.append(table_meta)

    logger.info('初始化表Meta数据成功')

    return table_meta_list


class TableMatcherService:

    def __init__(self):
        self.table_meta_list: list[TableMeta] = init_table_meta()


    @staticmethod
    def match_table_with_llm(query, table_metas: list[TableMeta]) -> tuple[str, str]:
        """
        使用LLM进行表匹配
        Returns:
            表名，表描述
        """
        system_prompt = get_prompt_template('match_table_prompt_template.md')
        logger.debug(f"使用LLM进行表匹配 system_prompt=\n{system_prompt}")

        table_metas_list = []
        for table_meta in table_metas:
            table_metas_list.append({'table_name': table_meta.table_name, 'table_desc': table_meta.table_desc})

        human_msg = f'{query}\n{json.dumps(table_metas_list, ensure_ascii=False)}'
        logger.debug(f"使用LLM进行表匹配 human_msg=\n{human_msg}")


        response = LlmFactory.create_llm().invoke([
            SystemMessage(system_prompt),
            HumanMessage(human_msg),
        ]).content

        if response and response.strip().upper() != 'NONE':
            for table in table_metas:
                if response == table.table_name:
                    return table.table_name, table.table_desc
        return '', ''


    def get_table_meta_by_name(self, table_name) -> TableMeta:
        """
        根据表名获取Meta
        """
        for t in self.table_meta_list:
            if t.table_name == table_name:
                return t
        return None


    def get_all_table_metas(self) -> list[TableMeta]:
        return self.table_meta_list


    def get_field_info(self, table_name) -> list[FieldMeta]:
        table_meta: TableMeta = self.get_table_meta_by_name(table_name)
        return table_meta.field_info
