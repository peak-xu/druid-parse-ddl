import json
import logging
from datetime import datetime

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import PromptTemplate
from langgraph.types import Command

from config import LlmFactory
from entity.table_meta import TableMeta, FieldMeta
from graph.query_agent_state import QueryAgentState, StateField
from service.dsl_builder_service import DSLBuilderService
from service.knowledge_base_service import KnowledgeBaseService
from service.table_matcher_service import TableMatcherService
from utils.doris_util import doris
from utils.string_util import get_prompt_template


logger = logging.getLogger(__name__)


table_matcher = TableMatcherService()
dsl_builder = DSLBuilderService()
knowledge_base = KnowledgeBaseService()


def preprocessing_node(state: QueryAgentState):
    """
    节点1: 预处理
    功能：合法性检查 + 短文本拓展
    """
    ori_query = state.user_query
    # 暂定预处理只做去除首尾空格
    processed_query = ori_query.strip()

    logger.info(f"********** [preprocessing_node] ori_query={ori_query}, processed_query={processed_query}")

    if processed_query:
        # 预处理成功，更新用户查询
        return Command(update={StateField.USER_QUERY: processed_query})
    else:
        # 预处理失败
        return Command(update={StateField.ERROR: '查询内容不能为空'})


def table_matching_node(state: QueryAgentState):
    """
    节点2: 表匹配
    功能：基于向量/语义匹配找到最相关数据表
    """
    query = state.user_query
    # 获取所有表Meta
    table_metas: list[TableMeta] = table_matcher.get_all_table_metas()

    logger.info(f"********** [table_matching_node] query={query}, table_count={len(table_metas)}")

    if not table_metas:
        return Command(update={StateField.ERROR: '系统未配置数据表，请联系管理员'})

    matched_table_name, table_desc = table_matcher.match_table_with_llm(query, table_metas)

    logger.info(f"********** [table_matching_node] matched_table_name={matched_table_name}")

    if matched_table_name:
        return Command(update={
            StateField.MATCHING_TABLES: matched_table_name + ":" + table_desc,
            StateField.SCHEMA_INFO: table_metas
        })
    else:
        return Command(update={
            StateField.ERROR: "未找到匹配的数据表，请尝试使用养殖领域相关关键词（如猪、牛、羊、PSY、MSY等）"
        })



def field_extraction_node(state: QueryAgentState):
    """
    节点3: 字段抽取
    功能：LLM辅助抽取维度(dimension)和指标(metric)
    """
    query = state.user_query
    matching_tables = state.matching_tables

    if not matching_tables:
        return Command(update={StateField.ERROR: "未匹配到数据表"})

    table_name, table_desc = matching_tables.split(':')

    field_info: list[FieldMeta] = table_matcher.get_field_info(table_name)

    if not field_info:
        return Command(update={StateField.ERROR: "表字段信息获取失败"})

    system_prompt = get_prompt_template('field_extraction_prompt_template.md')
    logger.debug(f"字段抽取 system_prompt=\n{system_prompt}")

    # 构建字段描述
    table_meta = f'table_name: {table_name}\ntable_desc: {table_desc}\nfield_list:\n'

    for field in field_info:
        table_meta += f"\t{field.field_name}: ({field.field_type}){field.field_name_cn}\n"

    cur_date = datetime.now().strftime("%Y-%m-%d")

    human_msg = f'**query**：{query}\n**cur_date**：{cur_date}\n**table_meta**：{table_meta}'

    logger.debug(f"字段抽取 human_msg=\n{human_msg}")

    response = LlmFactory.create_llm().invoke([
        SystemMessage(system_prompt),
        HumanMessage(human_msg)
    ]).content

    logger.info(f"********** [field_extraction_node] query={query}, table_name={table_name}, llm_response={response}")

    # 解析LLM响应
    try:
        parsed_result: dict = json.loads(response)

        return Command(update={StateField.EXTRACTED_FIELDS: parsed_result})
    except Exception as e:
        return Command(update={StateField.ERROR: f'字段抽取失败: {str(e)}'})


def data_enrichment_node(state: QueryAgentState):
    """
    节点4: 数据增强
    功能：补充 tenantId, userId, currentTime
    """
    matching_tables = state.matching_tables

    if not matching_tables:
        return Command(update={StateField.ERROR: '未匹配到数据表'})

    # 额外信息过滤
    extra_info = state.extra_info
    field_info: list[FieldMeta] = table_matcher.get_field_info(matching_tables.split(':')[0])

    # 对额外信息和已有表字段求交集
    common_fields: set = set(extra_info.keys()) & {field.field_name for field in field_info}

    update_extra_info = {common_field: extra_info[common_field] for common_field in common_fields}

    logger.info(f"********** [data_enrichment_node] extra_info={update_extra_info}")

    return Command(update={StateField.EXTRA_INFO: update_extra_info})


def dsl_building_node(state: QueryAgentState):
    """
    节点5: DSL构建
    功能：构建 DSL 实例，生成 SQL
    """
    matching_tables = state.matching_tables
    extracted_fields = state.extracted_fields

    if not matching_tables:
        return Command(update={StateField.ERROR: '未匹配到数据表'})

    try:
        # 解析提取的字段
        table_name = matching_tables.split(':')[0]
        dimensions:list = extracted_fields.get('dimensions', [])
        metrics:list = extracted_fields.get('metrics', [])
        filters:dict = extracted_fields.get('filters', {}) | state.extra_info

        logger.info(f"********** [dsl_building_node] table_name={table_name}, dimensions={dimensions}, metrics={metrics}, filters={filters}")

        sql = dsl_builder.build_sql(table_name, dimensions, metrics, filters)

        logger.info(f"********** [dsl_building_node] sql=" + sql)

        return Command(update={StateField.SQL: sql})
    except Exception as e:
        return Command(update={StateField.ERROR: f'DSL构建失败: {str(e)}'})


def sql_execution_node(state: QueryAgentState):
    """
    节点6: SQL执行
    """
    sql_results, _ = doris.execute_query_with_msg(state.sql)
    return Command(update={StateField.SQL_RESULTS: sql_results})


def knowledge_retrieval_node(state: QueryAgentState):
    """
    节点7: 领域知识检索
    功能：从知识库获取指标解读
    """
    metric_list = state.extracted_fields.get('metrics', [])
    interpretations = knowledge_base.get_interpretations(metric_list)

    logger.info(f"********** [knowledge_retrieval_node] metric_list={metric_list}, interpretations={interpretations}")

    return Command(update={StateField.KNOWLEDGE_CONTEXT: interpretations})


def rag_summarization_node(state: QueryAgentState):
    """
    节点8: RAG总结
    功能：整合数据+解读，生成最终报告
    """
    query = state.user_query
    sql_results = state.sql_results
    knowledge_context = state.knowledge_context

    # knowledge_context = {"PSY":"PSY是衡量母猪繁殖性能的重要指标", "MSY":"MSY是指每头母猪每年提供的断奶仔猪数"}

    prompt = PromptTemplate.from_template(get_prompt_template('summarize_prompt_template.md')).format(
        query=query,
        sql_results=sql_results or '暂无数据',
        knowledge_context=str(knowledge_context) or '暂无解读'
    )

    logger.debug(f"RAG总结 prompt=\n{prompt}")

    summary = LlmFactory.create_llm(stream_output=True).invoke([HumanMessage(content=prompt)]).content

    logger.info(f"********** [RAGSummarizationNode] query={query}, summary={summary}")

    return Command(update={StateField.SUMMARY: summary})