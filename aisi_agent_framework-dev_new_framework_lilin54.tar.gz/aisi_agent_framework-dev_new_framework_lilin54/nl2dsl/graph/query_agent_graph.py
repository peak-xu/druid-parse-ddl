from langgraph.constants import START, END
from langgraph.graph import StateGraph

from graph.nodes import *
from graph.query_agent_state import QueryAgentState

NODE_PREPROCESSING = "preprocessing"
NODE_DATA_ENRICHMENT = "dataEnrichment"
NODE_TABLE_MATCHING = "tableMatching"
NODE_FIELD_EXTRACTION = "fieldExtraction"
NODE_DSL_BUILDING = "dslBuilding"
NODE_SQL_EXECUTION = "sqlExecution"
NODE_KNOWLEDGE_RETRIEVAL = "knowledgeRetrieval"
NODE_RAG_SUMMARIZATION = "ragSummarization"


class QueryAgentGraph:

    @staticmethod
    def build():
        """构建状态图 (简单顺序执行)"""
        graph = StateGraph(QueryAgentState)

        # 添加节点
        graph.add_node(NODE_PREPROCESSING, preprocessing_node)
        graph.add_node(NODE_TABLE_MATCHING, table_matching_node)
        graph.add_node(NODE_FIELD_EXTRACTION, field_extraction_node)
        graph.add_node(NODE_DATA_ENRICHMENT, data_enrichment_node)
        graph.add_node(NODE_DSL_BUILDING, dsl_building_node)
        graph.add_node(NODE_SQL_EXECUTION, sql_execution_node)
        graph.add_node(NODE_KNOWLEDGE_RETRIEVAL, knowledge_retrieval_node)
        graph.add_node(NODE_RAG_SUMMARIZATION, rag_summarization_node)

        # 设置入口和边 (顺序执行)
        graph.add_edge(START, NODE_PREPROCESSING)
        graph.add_edge(NODE_PREPROCESSING, NODE_TABLE_MATCHING)
        graph.add_edge(NODE_TABLE_MATCHING, NODE_FIELD_EXTRACTION)
        graph.add_edge(NODE_FIELD_EXTRACTION, NODE_DATA_ENRICHMENT)
        graph.add_edge(NODE_DATA_ENRICHMENT, NODE_DSL_BUILDING)
        graph.add_edge(NODE_DSL_BUILDING, NODE_SQL_EXECUTION)
        graph.add_edge(NODE_SQL_EXECUTION, NODE_KNOWLEDGE_RETRIEVAL)
        graph.add_edge(NODE_KNOWLEDGE_RETRIEVAL, NODE_RAG_SUMMARIZATION)
        graph.add_edge(NODE_RAG_SUMMARIZATION, END)

        return graph.compile()