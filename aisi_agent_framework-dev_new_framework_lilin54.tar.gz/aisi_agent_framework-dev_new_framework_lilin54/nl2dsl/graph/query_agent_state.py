from enum import Enum
from pydantic import BaseModel

from entity.table_meta import TableMeta


class QueryAgentState(BaseModel):
    """定义Agent的状态结构"""
    user_query: str = ''
    extra_info: dict = {}
    schema_info: list[TableMeta] = []
    extracted_fields: dict = {}
    matching_tables: str = ''
    sql: str = ''
    sql_results: list[dict] = []
    knowledge_context: dict[str, str] = {}
    summary: str = ''
    error: str = ''
    processing_nodes: str = ''


class StateField(str, Enum):
    USER_QUERY = 'user_query'
    EXTRA_INFO = 'extra_info'
    SCHEMA_INFO = 'schema_info'
    EXTRACTED_FIELDS = 'extracted_fields'
    MATCHING_TABLES = 'matching_tables'
    SQL = 'sql'
    SQL_RESULTS = 'sql_results'
    KNOWLEDGE_CONTEXT = 'knowledge_context'
    SUMMARY = 'summary'
    ERROR = 'error'
    PROCESSING_NODES = 'processing_nodes'