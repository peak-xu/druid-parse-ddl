from pydantic import BaseModel


class FieldMeta(BaseModel):
    field_name: str
    field_name_cn: str
    field_name_alias: str
    field_type: str
    stat_scope: str
    field_desc: str


class TableMeta(BaseModel):
    table_name: str
    table_desc: str
    field_info: list[FieldMeta]