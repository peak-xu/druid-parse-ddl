from service.table_matcher_service import TableMatcherService


table_matcher = TableMatcherService()

table_metas = table_matcher.get_all_table_metas()

print('>> 启用的表:')
for idx, meta in enumerate(table_metas, start=1):
    print(f'表{idx}：{meta.table_name}')
    print(f'\t描述：{meta.table_desc}')
    print(f'\t字段：')
    for field in meta.field_info:
        print(f'\t\t{field.field_name}: ({field.field_type}){field.field_name_cn}')