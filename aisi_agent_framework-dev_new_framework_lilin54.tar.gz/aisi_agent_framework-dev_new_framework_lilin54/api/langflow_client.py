"""LangFlow 客户端，调用可视化编排的工作流。

LangFlow 是一个可视化 AI 工作流平台，支持通过 HTTP API 调用编排好的 pipeline。
"""
from logging import Logger
from typing import List

from utils import HttpClient


class LangFlowClient:
    """LangFlow 工作流调用客户端。

    Args:
        host: LangFlow 服务地址
        http_client: HTTP 客户端
        logger: 日志记录器
    """

    def __init__(self, host: str, http_client: HttpClient, logger: Logger) -> None:
        self.host = host
        self.http_client = http_client
        self.logger = logger

    async def invoke(self, id: str, chat: str, props: List[str]) -> str:
        """调用指定 LangFlow 工作流。

        Args:
            id: 工作流 flow_id
            chat: 输入文本（用户问题或工具结果）
            props: 需要覆盖的节点 id 列表（tweaks 为空对象，即使用默认配置）

        Returns:
            工作流输出文本。若 outputs 为空则返回 ''。
        """
        tweaks = {it: {} for it in props}
        res = await self.http_client.post_json(
            f'{self.host}/api/v1/run/{id}?stream=false',
            None,
            {
                'input_value': chat,
                'input_type': 'chat',
                'output_type': 'chat',
                'tweaks': tweaks,
            },
            None,
            None,
            lambda x: x.json(),
        )
        os = res['outputs']
        if len(os) == 0:
            return ''
        os = os[0]['outputs']
        if len(os) == 0:
            return ''
        return os[0]['results']['message']['data']['text']
