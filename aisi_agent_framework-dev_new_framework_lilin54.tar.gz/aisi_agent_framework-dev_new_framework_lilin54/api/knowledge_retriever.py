"""知识库检索客户端，封装三种检索后端。

Retrieval backends:
  - RAGFlow:       POST /api/v1/retrieval  (knowledge_type=2)
  - ZSK:           POST /api/v1/open/knowledge/retrieve  (knowledge_type=3)
  - 内部知识库:     POST /search_top_n   (其他 knowledge_type)
  - 联网搜索:       POST dp.nxin.com     (search_type 开启时)
"""
from typing import List, Dict, Optional

from utils import HttpClient


class KnowledgeRetriever:
    """知识库检索客户端，根据 knowledge_type 路由到不同检索后端。

    Args:
        host: 内部知识库服务地址
        ragflow_host: RAGFlow 服务地址
        ragflow_api_key: RAGFlow API 密钥
        zsk_knowledge_host: ZSK 知识库服务地址
        zsk_knowledge_api_key: ZSK API 密钥
        client: HTTP 客户端（复用连接池）
    """

    def __init__(
        self,
        host: str,
        ragflow_host: str,
        ragflow_api_key: str,
        zsk_knowledge_host: str,
        zsk_knowledge_api_key: str,
        client: HttpClient,
    ) -> None:
        self.host = host
        self.ragflow_host = ragflow_host
        self.ragflow_api_key = ragflow_api_key
        self.zsk_host = zsk_knowledge_host
        self.zsk_api_key = zsk_knowledge_api_key
        self.client = client

    async def query_top_n(
        self,
        keywords: List[str],
        collections: List[str],
    ) -> Optional[Dict[str, str]]:
        """内部知识库检索：返回匹配度最高的 N 条知识 (dict[str, str])。"""
        return await self.client.post_form(
            f'{self.host}/search_top_n',
            None,
            {'content': keywords, 'collectionName': collections},
            None,
            None,
            lambda x: x.json(content_type=None),
        )

    async def ragflow_retrieval(
        self,
        question: str,
        dataset_ids: List[str],
    ) -> Optional[str]:
        """RAGFlow 检索：返回包含 chunks 列表的 dict。"""
        return await self.client.post_json(
            f'{self.ragflow_host}/api/v1/retrieval',
            None,
            {'question': question, 'dataset_ids': dataset_ids, 'top_k': 5},
            {'Authorization': f'Bearer {self.ragflow_api_key}'},
            None,
            lambda x: x.json(content_type=None),
        )

    async def zsk_retriever(
        self,
        query: str,
        knowledge_base_ids: list[str],
        knowledge_ids: list[str],
    ) -> str:
        """ZSK 知识库检索：返回匹配内容的字符串表示。"""
        data = {
            'query': query,
            'knowledge_base_ids': knowledge_base_ids,
            'knowledge_ids': knowledge_ids,
            'match_count': 7,
        }
        headers = {'X-Open-Retrieve-Api-Key': self.zsk_api_key}
        try:
            result = await self.client.post_json(
                f'{self.zsk_host}/api/v1/open/knowledge/retrieve',
                None, data, headers, None,
                lambda x: x.json(content_type=None),
            )
            content_list = [data['content'] for data in result['data']]
            return str(content_list)
        except Exception:
            return ''

    async def nxin_search(self, question: str, org_id: int):
        """联网搜索：调用 nxin 搜索引擎返回结构化结果。"""
        return await self.client.post_json(
            'http://dp.nxin.com/web/search',
            None,
            {'question': question},
            None,
            None,
            lambda x: x.json(content_type=None),
        )
