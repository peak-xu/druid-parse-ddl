class TokenExceedError(Exception):
    """Token 超限异常，模型响应因 max_tokens 限制被截断。"""

    pass