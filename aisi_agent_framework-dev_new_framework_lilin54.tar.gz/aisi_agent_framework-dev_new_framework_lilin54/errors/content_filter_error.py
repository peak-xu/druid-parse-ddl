class ContentFilterError(Exception):
    """内容安全过滤异常，触发敏感词或不合规内容检测时抛出。"""

    pass