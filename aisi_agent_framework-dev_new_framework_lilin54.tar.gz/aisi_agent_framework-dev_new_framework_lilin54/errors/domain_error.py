class DomainError(Exception):
    """业务领域异常，携带错误码和消息。

    用于统一错误响应格式，前端根据 code 做差异化处理。

    Attributes:
        code: 业务错误码
        msg: 错误描述信息
    """

    def __init__(self, code: int, msg: str):
        self.code = code
        self.msg = msg

    def get_code(self) -> int:
        return self.code

    def get_msg(self) -> str:
        return self.msg