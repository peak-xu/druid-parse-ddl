date_str1 = 'Date_time'
date_str2 = 'Date'
date_str3 = '123_Date'
print(date_str1.lower().__contains__('date'))
print(date_str2.lower().__contains__('date'))
print(date_str3.lower().__contains__('date'))


print(date_str1)
print(date_str2)
print(date_str3)