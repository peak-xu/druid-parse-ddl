"""
ChannelV2 — 数字人快速回复通道（SSE 流式输出）

职责：
  1. 多轮对话历史管理
  2. 知识库 RAG 检索增强（支持 RAGFlow / ZSK / 内部知识库）
  3. 工具 / 技能调用（Function Calling）
  4. 图表意图识别 + ECharts 自动生成
  5. SSE 流式输出给前端

入口：chat(request)  →  _run(conversation_id, history, knowledge, request)
"""

import asyncio
import json
import os
import re
import time
import traceback
from copy import deepcopy
from datetime import date
from enum import Enum
from logging import Logger
from typing import Any, Callable, Dict, List, Optional, Tuple
from uuid import uuid4

from jinja2 import Environment
from openai.types.chat import ChatCompletionToolParam
from tiktoken import get_encoding

from api import KnowledgeRetriever, LangFlowClient
from entity import (
    ChatImgContentPart, ChatRequest, ChatTextContentPart,
    Knowledge, Message, Tool, ZxhToolCall,
)
from entity.chat_request import KnowledgeItem
from entity.constant import EChartsType
from llm import BaseLLM, LlmFactory, LlmRepository
from llm.base_llm import flatten_user_content_for_token_count
from models import ChatLog, ChatMsg
from nlp import Nlp
from store import MessageStore
from utils import ColUtil, HttpClient, ToolExtractor, substr, format_log_value, str_util
from utils.PPTUtil import gen_ppt
from utils.multimodal_util import parse_file_type, parse_file_url_content
from utils.sse_response_util import EventType, StreamResponseGenerator

# ── 常量 ──────────────────────────────────────────────────────────────────────
_THINK_RE = re.compile(r'<think_deeply>.*?</think_deeply>\s*', re.DOTALL)
_INTENT_RECOGNITION_PROMPT_TMPL = 'intent_recognition_system_prompt.md'
_ECHARTS_PROMPT_TMPL = 'plotting_echarts_prompt.md'
_PPT_PROMPT_TMPL = 'gen_ppt_plan_system_prompt.md'
_TOOL_PARAM_EXTRACTION_TMPL = 'tool_param_extraction_prompt.md'
_ECHARTS_MD_HINT = ' \n{type}已生成，请勿自己绘制，直接把`![{type}]({url})`穿插在回复中'
_PPT_MD_HINT = ' \nPPT 已生成，请勿自己生成，直接把`[PPT]({ppt_url})`穿插在回复中'
_DEFAULT_DEVICE_ID = '327943460860391424'
_DATE_PARAM_KEYWORDS = ('date', 'time', '日期', '时间')
_CHAT_INTERRUPTED_MSG = '本次对话过程发生异常中断，请稍后重试'

class IntentRecognitionDim(str, Enum):
    """意图识别维度与prompt.md"""
    PLOTTING = 'plotting_system_prompt.md'
    FARMING = 'farming_system_prompt.md'
    PPT = 'ppt_system_prompt.md'


class ChannelV2:
    """数字人快速回复通道（SSE 流式）。

    核心入口:
        :meth:`chat` — 单个请求的完整生命周期（会话加载 → 调度 → SSE 输出 → 持久化）

    调度核心:
        :meth:`_run` — 按顺序执行: 工具收集 → 多模态处理 → 知识库检索 → 图表意图
        → 三条分支之一（无工具 / @强制工具 / 自动工具）→ 图表补救 → 持久化

    三条回复分支:
        - 分支 A（无工具）: 直接 LLM 流式输出
        - 分支 B（@强制）: 逐工具参数提取 → 执行 → 汇总后 LLM 生成
        - 分支 C（自动）: 标准 function calling，LLM 自主选择工具

    外部依赖（由 IoC 容器注入）:
        所有依赖通过构造函数接收，便于单测 mock。
    """

    MAX_TOOL_ROWS: int = 200

    def __init__(
        self,
        store: MessageStore,
        client: HttpClient,
        langflow_client: LangFlowClient,
        knowledge_retriever: KnowledgeRetriever,
        llm_repository: LlmRepository,
        nlp: Nlp,
        env: Environment,
        logger: Logger,
    ) -> None:
        self.store = store
        self.client = client
        self.langflow_client = langflow_client
        self.knowledge_retriever = knowledge_retriever
        self.llm_repository = llm_repository
        self.echarts_server = os.getenv('echarts.server')
        self.datahub_url = os.getenv('datahub_url')
        self.nlp = nlp
        self.env = env
        self.logger = logger
        # 预热 tiktoken 编码器（首次调用较慢，提前加载缓存）
        get_encoding('cl100k_base')

    # ── 公共入口 ───────────────────────────────────────────────────────────────

    async def chat(self, request: ChatRequest):
        """SSE 流式对话入口。

        Yields:
            每帧为 JSON 字符串 + 两个换行。业务帧含 ``type`` 字段，token
            计数帧不含 ``type``，在 end 帧中汇总上报。
        """
        conv_id: Optional[str] = None
        tk_count: Dict[str, int] = {}
        query = request.user_chats[0].content

        try:
            conv_id, his_msg, his_knowledge = await self._load_or_create_session(request)

            start_time = time.time()
            first_yield_time: Optional[float] = None
            tk_count = {}

            yield self._sse_start(request, conv_id, start_time)

            async for frame in self._run(conv_id, his_msg, his_knowledge, request):
                if first_yield_time is None:
                    first_yield_time = time.time()
                    self.logger.info(
                        f'首次token响应时长:{first_yield_time - start_time:.2f} s'
                    )
                try:
                    parsed = json.loads(frame)
                    if 'type' in parsed:
                        yield frame + '\n\n'
                    else:
                        for k, v in parsed.items():
                            tk_count[k] = tk_count.get(k, 0) + v
                except (json.JSONDecodeError, TypeError, AttributeError) as e:
                    self._log_chat_frame_parse_warning(query, conv_id, frame, e)

            yield self._sse_end(request, conv_id, tk_count)
            self.logger.info(f'总耗时:{time.time() - start_time:.2f} s')
        except Exception:
            self._log_chat_exception(query, conv_id)
            end_conv_id = conv_id if conv_id is not None else (request.conversation_id or '')
            yield self._sse_generating(request, end_conv_id, _CHAT_INTERRUPTED_MSG) + '\n\n'
            yield self._sse_end(request, end_conv_id, tk_count)

    def _log_chat_frame_parse_warning(
        self,
        query: str,
        conv_id: Optional[str],
        frame: str,
        exc: Exception,
    ) -> None:
        conv_part = f'conv_id={conv_id}, ' if conv_id else ''
        self.logger.warning(
            f'{conv_part}query={query}, 单帧解析跳过: {exc}, '
            f'frame={substr(frame, 0, 200)}'
        )

    def _log_chat_exception(self, query: str, conv_id: Optional[str]) -> None:
        conv_part = f'conv_id={conv_id}, ' if conv_id else ''
        self.logger.error(
            f'对话异常: {conv_part}query={query}\n{traceback.format_exc()}'
        )

    # ── 核心调度 ───────────────────────────────────────────────────────────────

    async def _run(
        self,
        conversation_id: str,
        history: List[Message],
        knowledge_history: Optional[Knowledge],
        request: ChatRequest,
    ):
        """核心调度 — 7 步流水线处理单次对话。

        ┌─────────────┬──────────────────────────────────────────────┐
        │ 步骤         │ 说明                                        │
        ├─────────────┼──────────────────────────────────────────────┤
        │ 1. 工具 & LLM │ 收集工具列表，加载 LLM 配置，创建模型实例     │
        │ 2. 多模态     │ 图片 → 切换视觉模型；文档 → 解析文本追加      │
        │ 3. 知识库     │ ZSK 检索 或 标准检索（RAGFlow/ZSK/内部）      │
        │ 4. 图表意图   │ LLM 判断是否需要绘制 ECharts 图表            │
        │ 5. 三条分支   │ 无工具 / @强制调用 / 模型自选 function call   │
        │ 6. 图表补救   │ 若 LLM 未引用图表 URL，补输出 Markdown 图片   │
        │ 7. 持久化     │ 保存 ChatMsg + ChatLog 到数据库              │
        └─────────────┴──────────────────────────────────────────────┘

        Yields:
            JSON 字符串帧（业务帧含 ``type`` 字段，token 计数帧含模型名 key）。
        """
        yield self._sse_generating(request, conversation_id, '正在思考/处理中')

        # ── 步骤 1: 工具收集 & LLM 初始化 ──────────────────────────────────
        self.logger.info(
            f'conv_id={conversation_id}, run_path=channelV2->_run, request={request.model_dump_json(by_alias=True)}'
        )
        ##################################################################################################
        ##################################################################################################
        tools, tool_choice = self.append_tool(request)
        request.env.device_id = request.user_chats[0].exId or _DEFAULT_DEVICE_ID
        self.logger.info(
            f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
            f'run_path=channelV2->_run, 步骤1-工具收集完成, tools={[t.name for t in tools]}, tool_choice={tool_choice}'
        )

        llm_config = await self.llm_repository.get_config(request.agent_data.llm_name)
        deepseek_config = await self.llm_repository.get_config('deepseek-v4-flash')
        if llm_config is None:
            yield self._sse_generating(request, conversation_id, '模型未配置，请联系管理员')
            return

        temperature = float(request.agent_data.temperature)
        model = self._create_model(llm_config, temperature, request)
        # 深度思考模式：准备 DeepSeek-R1 作为思考模型，生成答案时用思考模型回复
        is_deep_thinking = bool(request.user_chats[0].deep_thinking)
        think_model = (
            self._create_model(deepseek_config, temperature, request)
            if is_deep_thinking else None
        )
        reply_model = think_model if is_deep_thinking else model

        # ── 步骤 2: 多模态文件处理 ────────────────────────────────────────
        self.logger.info(
            f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
            f'run_path=channelV2->_run, 步骤2-多模态处理开始, file_url={request.user_chats[0].file_url}, file_type={request.user_chats[0].file_type}'
        )
        user_chats, model = await self._prepare_user_chats(
            history, model, llm_config, temperature, request
        )
        # 多模态处理可能将 model 切换为视觉模型（如 doubao-1.6-vision-pro），
        # 需同步更新 reply_model，否则后续分支 A/B/C/D 仍使用原模型，
        # 导致多模态 content 被发送到不支持图片的模型。
        # 注意：_prepare_user_chats 内部会将图片请求的 deep_thinking 重置为 0，
        # 但外部的 is_deep_thinking 不会自动更新，因此不能用 is_deep_thinking 判断，
        # 而应直接判断是否为图片请求。
        if request.user_chats[0].file_url and request.user_chats[0].file_type == 'image':
            reply_model = model
        self.logger.info(
            f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
            f'run_path=channelV2->_run, 步骤2-多模态处理完成, model={model.__class__.__name__}, reply_model={reply_model.__class__.__name__}'
        )

        # ── 步骤 3: 知识库检索 & 构建 system_prompt ───────────────────────
        role_prompt = self._build_role_prompt(request)
        system_prompt = role_prompt
        knowledge: Any = ''

        if request.have_zsk_knowledge():
            self.logger.info(
                f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
                f'run_path=channelV2->_run, 步骤3-知识库检索, 路径=ZSK知识库, knowledge_base={request.knowledge_base}'
            )
            knowledge, system_prompt = await self._retrieve_zsk_knowledge(
                model, role_prompt, history, request
            )
        else:
            self.logger.info(
                f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
                f'run_path=channelV2->_run, 步骤3-知识库检索, 路径=标准检索, knowledge_base={request.knowledge_base}'
            )
            knowledge, system_prompt = await self._retrieve_standard_knowledge(
                conversation_id, model, role_prompt, history, request
            )
            # 联网搜索结果以独立帧 yield 给前端
            async for frame in self._handle_nxin_search(request, conversation_id):
                yield frame
        self.logger.info(
            f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
            f'run_path=channelV2->_run, 步骤3-知识库检索完成, knowledge长度={len(str(knowledge))}'
        )

        # ── 步骤 4: 图表意图识别 ──────────────────────────────────────────
        gen = StreamResponseGenerator(request)
        echarts_url = ''
        self.logger.info(
            f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
            f'run_path=channelV2->_run, 步骤4-图表意图识别开始'
        )
        # 旧并发识别逻辑已下沉到 _intent_recognition_with_separate_prompts 作为备用逻辑：
        # need_plotting, belong_to_farming, need_gen_ppt = await asyncio.gather(
        #     self.intent_recognition(IntentRecognitionDim.PLOTTING, model, request.user_chats[0].content, history),
        #     self.intent_recognition(IntentRecognitionDim.FARMING, model, request.user_chats[0].content, history),
        #     self.intent_recognition(IntentRecognitionDim.PPT, model, request.user_chats[0].content, history),
        # )
        need_plotting = False
        belong_to_farming = False
        need_gen_ppt = False
        need_plotting, belong_to_farming, need_gen_ppt = await self.recognize_intents(
            model, request.user_chats[0].content, history,
            bool(request.user_chats[0].file_url and request.user_chats[0].file_type == 'image')
        )

        self.logger.info(
            f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
            f'run_path=channelV2->_run, 步骤4-图表意图识别完成, '
            f'need_plotting={need_plotting}, belong_to_farming={belong_to_farming}, need_gen_ppt={need_gen_ppt}'
        )
        if need_plotting:
            yield gen.output('正在绘制图表', current_type=EventType.CAPTION)

        # 专家探索模式：仅识别意图，不做回复
        if request.env.deep_analysis:
            return

        # ── 步骤 5: 四条回复分支 ──────────────────────────────────────────
        branch_echarts: Dict[str, str] = {'url': ''}
        ans = ''
        model_result: List[Message] = []
        # 图片请求时 deep_thinking 已被 _prepare_user_chats 重置为 0，需同步更新 is_deep_thinking
        is_deep_thinking = bool(request.user_chats[0].deep_thinking)
        llm_name = 'deepseek-r1-huoshan' if is_deep_thinking else request.agent_data.llm_name

        if len(tools) == 0:
            # 分支 A — 无工具：直接 LLM 流式回复
            self.logger.info(
                f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
                f'run_path=channelV2->_run, 步骤5-进入分支A(无工具直接回复), llm_name={llm_name}'
            )
            async for frame in self._branch_no_tool(
                reply_model, system_prompt, history, request,
                conversation_id, llm_name
            ):
                parsed = json.loads(frame)
                ans += parsed.get('content', '')
                yield frame
            model_result = [Message(role='assistant', content=ans, assistant='channel')]

        elif tool_choice:
            # 分支 B — @指定工具：强制调用每个工具，汇总后 LLM 回复
            self.logger.info(
                f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
                f'run_path=channelV2->_run, 步骤5-进入分支B(@强制工具), tools={[t.name for t in tools]}, llm_name={llm_name}'
            )
            async for frame in self._branch_forced_tools(
                reply_model, model, system_prompt, tools, history, request, conversation_id,
                need_plotting, need_gen_ppt, gen, branch_echarts,
            ):
                parsed = json.loads(frame)
                ans += parsed.get('content', '')
                yield frame
            model_result = [Message(
                role='assistant', content=_THINK_RE.sub('', ans), assistant='channel'
            )]
            echarts_url = branch_echarts['url']

        elif not belong_to_farming:
            # 分支 C — （非农业相关）模型自选工具：标准 function calling
            self.logger.info('通用业务请求，模型自选工具')
            self.logger.info(
                f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
                f'run_path=channelV2->_run, 步骤5-进入分支C(模型自选工具), tools={[t.name for t in tools]}, llm_name={llm_name}'
            )
            async for frame in self._branch_auto_tool(
                reply_model, model, system_prompt, role_prompt,
                tools, user_chats, history, request,
                conversation_id, llm_name, need_plotting, branch_echarts,
            ):
                parsed = json.loads(frame)
                ans += parsed.get('content', '')
                yield frame
            model_result = [Message(
                role='assistant', content=_THINK_RE.sub('', ans), assistant='channel'
            )]
            echarts_url = branch_echarts['url']

        else:
            # 分支 d — （农业相关）直接请求DataHub
            self.logger.info('农信业务请求，调用DataHub')
            self.logger.info(
                f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
                f'run_path=channelV2->_run, 步骤5-进入分支D(农业DataHub), datahub_url={self.datahub_url}, llm_name={llm_name}'
            )
            async for frame in self._branch_data_hub(
                reply_model, model, system_prompt, history,
                request, conversation_id, need_plotting, branch_echarts,
            ):
                parsed = json.loads(frame)
                ans += parsed.get('content', '')
                yield frame
            model_result = [Message(
                role='assistant', content=_THINK_RE.sub('', ans), assistant='channel'
            )]
            echarts_url = branch_echarts['url']

        # ── 步骤 6: 图表补救 — 模型未引用图表 URL 时补输出 ─────────────────
        self.logger.info(
            f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
            f'run_path=channelV2->_run, 步骤6-图表补救检查, need_plotting={need_plotting}, echarts_url={echarts_url}, url_in_ans={echarts_url in ans if echarts_url else False}'
        )
        if need_plotting and echarts_url and echarts_url not in ans:
            self.logger.info(
                f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
                f'run_path=channelV2->_run, 步骤6-图表补救触发, echarts_url={echarts_url}'
            )
            md_url = f'\n\n![图表]({echarts_url})'
            yield gen.output(md_url)
            ans += md_url

        # ── 步骤 7: 持久化 ────────────────────────────────────────────────
        self.logger.info(
            f'conv_id={conversation_id}, query={flatten_user_content_for_token_count(request.user_chats[0].content)}, '
            f'run_path=channelV2->_run, 步骤7-持久化, conversation_id={conversation_id}, llm_id={llm_config.id}, tools={[t.name for t in tools]}'
        )
        await self._persist_conversation(
            conversation_id, request, llm_config.id, temperature,
            tools, knowledge, user_chats, model_result, role_prompt, ans
        )

    # ── 分支 A：无工具 ─────────────────────────────────────────────────────────

    async def _branch_no_tool(
        self,
        model: BaseLLM,
        system_prompt: str,
        history: List[Message],
        request: ChatRequest,
        conversation_id: str,
        llm_name: str,
    ):
        """无工具时直接调用 LLM 流式输出。"""
        query = flatten_user_content_for_token_count(request.user_chats[0].content)
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_no_tool, 分支A-调用LLM流式输出, model={model.__class__.__name__}, llm_name={llm_name}, history_len={len(history)}'
        )
        async for msg in model.stream_chat(
            system_prompt, [], history, 'user',
            request.user_chats[0].content, 'channel', False
        ):
            if isinstance(msg, int):
                yield json.dumps({llm_name: msg}, ensure_ascii=False)
            else:
                yield self._sse_generating(request, conversation_id, msg.content)

    # ── 分支 B：@ 指定工具 ─────────────────────────────────────────────────────

    async def _branch_forced_tools(
        self,
        reply_model: BaseLLM,
        model: BaseLLM,
        system_prompt: str,
        tools: List[Tool],
        history: List[Message],
        request: ChatRequest,
        conversation_id: str,
        need_plotting: bool,
        need_gen_ppt: bool,
        gen: StreamResponseGenerator,
        branch_echarts: Dict[str, str],
    ):
        """@ 工具分支：逐工具提取参数 → 执行 → 汇总注入上下文 → LLM 生成回复。"""
        query = flatten_user_content_for_token_count(request.user_chats[0].content)
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_forced_tools, 分支B-开始提取工具参数, tools={[t.name for t in tools]}'
        )
        # 提取参数
        tool_call_pairs = await self._extract_tool_params(model, tools, request, conversation_id)
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_forced_tools, 分支B-工具参数提取完成, '
            f'成功提参工具={[t.name for t, _ in tool_call_pairs]}, '
            f'params={format_log_value([p for _, p in tool_call_pairs])}'
        )

        # 执行工具 & 收集结果
        execution_results: Dict[str, str] = {}
        for tool, params in tool_call_pairs:
            try:
                self.logger.info(
                    f'conv_id={conversation_id}, query={query}, '
                    f'run_path=channelV2->_run->_branch_forced_tools, 分支B-执行工具, '
                    f'tool={tool.name}, url={tool.url}, params={format_log_value(params)}'
                )
                yield gen.output(
                    f'执行工具：{tool.summary or tool.name}',
                    current_type=EventType.CAPTION
                )
                result = await model.invoke_tool(
                    call_id=str(uuid4()), tool=tool, args=params, content=query
                )
                formatted = self._parse_tool_json_result(result[1], tool)
                self.logger.info(
                    f'conv_id={conversation_id}, query={query}, '
                    f'run_path=channelV2->_run->_branch_forced_tools, 分支B-工具执行完成, tool={tool.name}, result_len={len(formatted)}'
                )
                execution_results[tool.name] = (
                    f'工具名称: {tool.name}\n工具描述: {tool.description}\n执行结果: {formatted}'
                )
            except Exception as e:
                self.logger.error(f'工具[{tool.name}]执行失败: {e}')

        # 注入汇总结果
        summary = self._build_tool_results_summary(execution_results)
        history.append(Message(role='tool', content=summary, assistant='channel'))

        # 追加@通用技能提示到用户问题中
        if request.at_general_skill_info and request.at_general_skill_info.skill_prompt:
            request.user_chats[0].content += f' （{request.at_general_skill_info.skill_prompt}）'

        # 按需生成图表
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_forced_tools, 分支B-图表生成, need_plotting={need_plotting}, execution_results_keys={list(execution_results.keys())}'
        )
        echarts_url, echarts_type = await self.plotting_echarts_rewrite_query(
            need_plotting, model, request, history, execution_results
        )
        branch_echarts['url'] = echarts_url
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_forced_tools, 分支B-图表生成完成, echarts_url={echarts_url}, echarts_type={echarts_type}'
        )
        if echarts_url:
            request.user_chats[0].content += _ECHARTS_MD_HINT.format(
                type=echarts_type, url=echarts_url
            )
        # 生成PPT
        ppt_url = await self.gen_ppt_by_content(need_gen_ppt, model, request, history)
        if ppt_url:
            request.user_chats[0].content += _PPT_MD_HINT.format(ppt_url=ppt_url)
        history.append(Message(
            role='user', content=request.user_chats[0].content, assistant='channel'
        ))

        # 调用 LLM 生成最终回复
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_forced_tools, 分支B-调用LLM生成最终回复, model={reply_model.__class__.__name__}, history_len={len(history)}'
        )
        filtered = self._filter_messages(history)
        async for msg in reply_model.stream_chat(
            system_prompt, [], filtered, 'user', None, 'channel', False
        ):
            if not isinstance(msg, int):
                yield self._sse_generating(request, conversation_id, msg.content)

    # ── 分支 C：模型自选工具 ───────────────────────────────────────────────────

    async def _branch_auto_tool(
        self,
        reply_model: BaseLLM,
        model: BaseLLM,
        system_prompt: str,
        role_prompt: str,
        tools: List[Tool],
        user_chats: List[Message],
        history: List[Message],
        request: ChatRequest,
        conversation_id: str,
        llm_name: str,
        need_plotting: bool,
        branch_echarts: Dict[str, str],
    ):
        """分支 C — 模型自选工具（标准 function calling）。

        流程概述:
          1. 调用 LLM 流式输出，LLM 可能返回 tool_calls
          2. 收集 tool_calls → 解析结果 → 按三种子情况处理:
             a. reply tag 工具: 直接输出结果，不经过 LLM 整理
             b. 有工具结果（tmp_msg 非空）: 图表生成后，用 LLM 整理历史消息
             c. 无结果（tmp_msg 为空）: 结果已注入 user_chats，用 LLM 整理

        ``interrupted`` 标志用于跳过流式输出中的第一帧后其余帧，
        因为该分支只需处理工具调用结果，不需要逐个 token 输出中间内容。
        """
        query = flatten_user_content_for_token_count(request.user_chats[0].content)
        tools_info = {tool.name: tool for tool in tools}
        tools_prompt = (
            f'{system_prompt}\n函数调用的全局系统信息:'
            f'{request.env.model_dump(by_alias=True)}'
        )
        call_map: Dict[str, ZxhToolCall] = {}
        interrupted = False

        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_auto_tool, 分支C-调用LLM(function calling), model={model.__class__.__name__}, tools={[t.name for t in tools]}, history_len={len(history)}'
        )
        async for tool_message in model.stream_chat(
            tools_prompt, tools, history, 'user',
            request.user_chats[0].content, 'channel', False
        ):
            # 帧类型 1 — token 计数帧：记录消费量后结束监听
            if isinstance(tool_message, int):
                yield json.dumps({llm_name: tool_message}, ensure_ascii=False)
                break

            # 帧类型 2 — assistant 带 tool_calls：尚未执行，先收集起来
            if (tool_message.role == 'assistant'
                    and tool_message.tool_calls
                    and len(tool_message.tool_calls) > 0):
                self.logger.info(
                    f'conv_id={conversation_id}, query={query}, '
                    f'run_path=channelV2->_run->_branch_auto_tool, 分支C-收到tool_calls, calls={[tc.name for tc in tool_message.tool_calls]}'
                )
                user_chats.append(tool_message)
                call_map.update({tc.id: tc for tc in tool_message.tool_calls})
                continue

            # 帧类型 3 — 异步任务通知：透传给前端
            if model.async_tasks:
                yield json.dumps({
                    'type': 'async_create',
                    'feedback_id': request.feedback_id,
                    'id': request.env.reply_id,
                    'asyncTask': [t.model_dump() for t in model.async_tasks],
                }, ensure_ascii=False)

            # 帧类型 4 — 工具调用结果：解析并进入子分支处理
            tmp_msg, content_type, is_direct_reply = self._parse_function_call_chat(
                tool_message, tools_info, user_chats, call_map
            )

            # interrupted 标志：流式输出中，第一条非 token/非 tool_calls 的消息
            # 已经是工具结果。后续帧（如 LLM 继续产出）直接跳过。
            if interrupted:
                continue
            interrupted = True

            # ── 子情况 a: 工具带 reply tag → 直接输出，不经过 LLM ─────────
            if tmp_msg is not None and is_direct_reply:
                self.logger.info(
                    f'conv_id={conversation_id}, query={query}, '
                    f'run_path=channelV2->_run->_branch_auto_tool, 分支C-子情况a(reply tag直接输出), content_type={content_type}, content_len={len(tmp_msg.content)}'
                )
                yield self._sse_generating(request, conversation_id, tmp_msg.content, content_type)
                break

            # ── 子情况 b: 工具有结果 → 生成图表后，LLM 整理历史消息 ──────────
            if tmp_msg is not None:
                self.logger.info(
                    f'conv_id={conversation_id}, query={query}, '
                    f'run_path=channelV2->_run->_branch_auto_tool, 分支C-子情况b(工具有结果LLM整理), need_plotting={need_plotting}, history_len={len(history)}'
                )
                echarts_url, echarts_type = await self.plotting_echarts_rewrite_query(
                    need_plotting, model, request, history
                )
                branch_echarts['url'] = echarts_url
                self.logger.info(
                    f'conv_id={conversation_id}, query={query}, '
                    f'run_path=channelV2->_run->_branch_auto_tool, 分支C-子情况b图表生成完成, echarts_url={echarts_url}, echarts_type={echarts_type}'
                )
                if echarts_url:
                    request.user_chats[0].content += _ECHARTS_MD_HINT.format(
                        type=echarts_type, url=echarts_url
                    )
                self.logger.info(
                    f'conv_id={conversation_id}, query={query}, '
                    f'run_path=channelV2->_run->_branch_auto_tool, 分支C-子情况b调用LLM整理, model={reply_model.__class__.__name__}, history_len={len(history)}'
                )
                filtered = self._filter_messages(history)
                async for msg in reply_model.stream_chat(
                    system_prompt, [], filtered, 'user',
                    request.user_chats[0].content, 'channel', False
                ):
                    if isinstance(msg, int):
                        yield json.dumps({llm_name: msg}, ensure_ascii=False)
                    else:
                        yield self._sse_generating(request, conversation_id, msg.content)
                break

            # ── 子情况 c: tmp_msg 为空 → 结果已注入 user_chats，直接 LLM 整理 ─
            self.logger.info(
                f'conv_id={conversation_id}, query={query}, '
                f'run_path=channelV2->_run->_branch_auto_tool, 分支C-子情况c(结果注入user_chats LLM整理), need_plotting={need_plotting}, user_chats_len={len(user_chats)}'
            )
            echarts_url, echarts_type = await self.plotting_echarts_rewrite_query(
                need_plotting, model, request, history
            )
            branch_echarts['url'] = echarts_url
            self.logger.info(
                f'conv_id={conversation_id}, query={query}, '
                f'run_path=channelV2->_run->_branch_auto_tool, 分支C-子情况c图表生成完成, echarts_url={echarts_url}, echarts_type={echarts_type}'
            )
            if echarts_url:
                user_chats[-1].content += _ECHARTS_MD_HINT.format(
                    type=echarts_type, url=echarts_url
                )
            self.logger.info(
                f'conv_id={conversation_id}, query={query}, '
                f'run_path=channelV2->_run->_branch_auto_tool, 分支C-子情况c调用LLM整理, model={reply_model.__class__.__name__}, user_chats_len={len(user_chats)}'
            )
            filtered = self._filter_messages(user_chats)
            async for msg in reply_model.stream_chat(
                role_prompt, [], filtered, 'user', None, 'channel', False
            ):
                if isinstance(msg, int):
                    yield json.dumps({llm_name: msg}, ensure_ascii=False)
                else:
                    yield self._sse_generating(request, conversation_id, msg.content)


    async def _branch_data_hub(
        self,
        reply_model: BaseLLM,
        model: BaseLLM,
        system_prompt: str,
        history: List[Message],
        request: ChatRequest,
        conversation_id: str,
        need_plotting: bool,
        branch_echarts: Dict[str, str],
    ):
        """分支 D — datahub获取数据"""
        query = flatten_user_content_for_token_count(request.user_chats[0].content)
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_data_hub, 分支D-请求DataHub开始, datahub_url={self.datahub_url}'
        )
        data = await self._get_data_from_hub(request, conversation_id)
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_data_hub, 分支D-DataHub返回完成, data_len={len(str(data))}, data={str_util.format_log_value(data)}'
        )

        # 对 datahub 返回的明细数据做统计聚合，减少注入 LLM context 的数据量
        try:
            from data_add_function.item_data_analyzer import DataAnalyzer
            stat_result = await DataAnalyzer.data_stat_with_base_llm(model, query, data)
            if stat_result.get('total', 0) > 0:
                data = json.dumps(stat_result, ensure_ascii=False)
                self.logger.info(
                    f'conv_id={conversation_id}, query={query}, '
                    f'run_path=channelV2->_run->_branch_data_hub, 分支D-数据聚合完成, total={stat_result["total"]}'
                )
        except Exception as e:
            self.logger.warning(
                f'conv_id={conversation_id}, query={query}, '
                f'run_path=channelV2->_run->_branch_data_hub, 分支D-数据聚合失败，使用原始数据: {e}'
            )

        # 注入工具结果
        history.append(Message(role='tool', content=data, assistant='channel'))

        # 按需生成图表
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_data_hub, 分支D-图表生成, need_plotting={need_plotting}'
        )
        echarts_url, echarts_type = await self.plotting_echarts_rewrite_query(
            need_plotting, model, request, history
        )
        branch_echarts['url'] = echarts_url
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_data_hub, 分支D-图表生成完成, echarts_url={echarts_url}, echarts_type={echarts_type}'
        )
        if echarts_url:
            request.user_chats[0].content += _ECHARTS_MD_HINT.format(
                type=echarts_type, url=echarts_url
            )
        history.append(Message(
            role='user', content=request.user_chats[0].content, assistant='channel'
        ))
        # 调用 LLM 生成最终回复
        self.logger.info(
            f'conv_id={conversation_id}, query={query}, '
            f'run_path=channelV2->_run->_branch_data_hub, 分支D-调用LLM生成最终回复, model={reply_model.__class__.__name__}, history_len={len(history)}'
        )
        filtered = self._filter_messages(history)
        async for msg in reply_model.stream_chat(
            system_prompt, [], filtered, 'user', None, 'channel', False
        ):
            if not isinstance(msg, int):
                yield self._sse_generating(request, conversation_id, msg.content)

    # ── 工具收集 ───────────────────────────────────────────────────────────────

    @staticmethod
    def append_tool(request: ChatRequest) -> Tuple[List[Tool], bool]:
        """收集本次对话需要的工具列表。

        Returns:
            (tools, tool_choice) — tool_choice=True 表示强制调用（@了技能）。
        """
        tool_choice = False
        tools: Dict[str, Tool] = {}

        if request.have_at_skill():
            tool_choice = True
            info = request.at_general_skill_info
            for skill in info.skill_meta_list or []:
                tools[skill.url + skill.name] = Tool.parse_tool(skill, 'general_skill')
            for skill in info.dataset_meta_list or []:
                tools[skill.url + skill.name] = Tool.parse_tool(skill, 'dataset_meta')

        if request.have_at_dataset_meta_list():
            tool_choice = True
            for skill in request.at_dataset_meta_list or []:
                tools[skill.url + skill.name] = Tool.parse_tool(skill, 'dataset_meta')

        if not tool_choice:
            for skills_info in request.general_skills_info or []:
                for skill in skills_info.dataset_meta_list or []:
                    tools[skill.url + skill.name] = Tool.parse_tool(skill, 'general_skill')
            for skill in request.dataset_meta_list or []:
                tools[skill.url + skill.name] = Tool.parse_tool(skill, 'dataset_meta')
            for skill in request.skills or []:
                tools[skill.url or '' + skill.name or ''] = Tool.parse_tool(skill, 'data_query_skill')
            function_skills = request.function_skills_info
            if function_skills:
                for s in function_skills.skill_meta_list or []:
                    tools[s.url + s.name] = Tool.parse_tool(s, 'data_query_skill')
                for s in function_skills.dataset_meta_list or []:
                    tools[s.url + s.name] = Tool.parse_tool(s, 'dataset_meta')

        return list(tools.values()), tool_choice

    # ── 知识库检索 ─────────────────────────────────────────────────────────────

    async def _retrieve_zsk_knowledge(
        self,
        model: BaseLLM,
        role_prompt: str,
        history: List[Message],
        request: ChatRequest,
    ) -> Tuple[str, str]:
        """ZSK 知识库检索（@知识库时触发）。

        通过 function calling 强制调用 search_zsk_knowledge 工具，
        将检索结果拼入 system_prompt，引导 LLM 基于知识内容回复。
        """
        search_tool = self.build_search_zsk_knowledge_tool()
        knowledge = ''
        async for msg in model.stream_chat(
            role_prompt, [search_tool], history, 'user',
            request.user_chats[0].content, 'channel', False, 'not_auto'
        ):
            if msg and msg.content:
                knowledge += msg.content
        if knowledge:
            self.logger.info(f'检索到的知识[{knowledge}]')
            system_prompt = (
                f'{role_prompt}\n以下为检索到的[知识/关联文件/文档/附件]的内容'
                f'(回复请省略知识中问题部分,不要体现知识编号):\n{knowledge}'
            )
        else:
            system_prompt = role_prompt
        return knowledge, system_prompt

    async def _retrieve_standard_knowledge(
        self,
        conversation_id: str,
        model: BaseLLM,
        role_prompt: str,
        history: List[Message],
        request: ChatRequest,
    ) -> Tuple[Any, str]:
        """标准知识库检索。

        根据 request.knowledge_base[0].type 选择检索策略:
          - type=2: RAGFlow
          - type=3: ZSK
          - 其他: 内部知识库

        返回值: (knowledge dict, 拼接了知识的 system_prompt)
        """
        self.logger.info(f'用户问题[{request.user_chats[0].content}]')
        self.logger.info(f'绑定知识库为{request.knowledge_base}')
        knowledge: Any = ''
        if request.knowledge_base:
            knowledge = await self._build_knowledge(
                conversation_id, model, None,
                request.knowledge_base,
                ColUtil.map(request.user_chats, lambda x: x.content),
                model.keyword_rewrite,
                request.knowledge_base[0].type,
            )
        if knowledge:
            self.logger.info(f'检索到的知识[{knowledge}]')
            system_prompt = (
                f'{role_prompt}\n参考以下知识库内容'
                f'(回复请省略知识中问题部分,不要体现知识编号):\n{knowledge}'
            )
        else:
            system_prompt = role_prompt
        return knowledge, system_prompt

    # todo 联网搜索功能，暂不处理
    async def _handle_nxin_search(
        self, request: ChatRequest, conversation_id: str
    ):
        """联网搜索：若用户开启搜索模式，将搜索结果注入 system_prompt。"""
        if not request.user_chats[0].search_type:
            return
        query = flatten_user_content_for_token_count(request.user_chats[0].content)
        search_result = await self.knowledge_retriever.nxin_search(
            query, request.env.enterprise_id
        )
        data = search_result.get('data', [])
        if not data:
            return
        yield json.dumps({
            'type': 'caption_search',
            'feedback_id': request.feedback_id,
            'conversation_id': conversation_id,
            'content': f'搜索到{len(data)}篇资料供参考',
            'search_result': data,
        }, ensure_ascii=False)

    async def _build_knowledge(
        self,
        conversation_id: str,
        model: BaseLLM,
        knowledge: Optional[Knowledge],
        knowledge_base: List[KnowledgeItem],
        chats: List[Any],
        fn: Callable[[str], str],
        knowledge_type: int,
    ) -> Knowledge:
        """按 knowledge_type 执行知识库检索。

        Args:
            knowledge_type: 2=RAGFlow, 3=ZSK, 其他=内部知识库。
        """
        try:
            kb_ids = [item.id for item in knowledge_base]
            kb_names = [item.name for item in knowledge_base]
            chats_text = [flatten_user_content_for_token_count(c) for c in chats]

            if knowledge_type == 2:
                raw = await self.knowledge_retriever.ragflow_retrieval(chats_text[0], kb_ids)
                if raw.get('code') == 0:
                    return {i + 1: chunk['content'] for i, chunk in enumerate(raw['data']['chunks'])}
                return {}

            if knowledge_type == 3:
                k = await self.knowledge_retriever.zsk_retriever(chats_text[0], kb_ids, [])
                return {1: k} if k else {}

            # 内部知识库
            k = await self.knowledge_retriever.query_top_n(chats_text, kb_names)
            if k is not None:
                k = {a: fn(b) for a, b in k.items()}
            if k is None and knowledge is None:
                return {}
            if knowledge is None:
                return k
            if k is None:
                return knowledge
            knowledge.update(k)
            return knowledge
        except Exception:
            self.logger.error(f'知识库检索异常:{traceback.format_exc()}')
            return {}

    # ── 工具调用辅助 ───────────────────────────────────────────────────────────

    async def _get_data_from_hub(self, request, conversation_id) -> str:
        msg = '未查询到结果'
        try:
            body = json.dumps({
                'query': request.user_chats[0].content,
                'session_id': conversation_id
            },ensure_ascii=False).encode('utf-8')
            header = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {request.user_chats[0].dataset_token}'
            }
            res = await self.client.request('POST', self.datahub_url, None, body, header, None, lambda x: x.json(content_type=None))

            if res['status'] == 0:
                msg = res['message']
            else:
                # 字段中文映射
                fields_map = {field['name']:field['text'] for field in res['data']['fields']}
                # 从datahub返回的数据结果
                dh_data_list = res['data']['data']['value']
                if dh_data_list:
                    msg = str(dh_data_list)  # 数据
                    for key, value in fields_map.items():
                        msg = msg.replace(key, value)

        except Exception as e:
            self.logger.error(f'DataHub数据提取异常：{str(e)}')
            msg = '获取数据异常，未查询到结果'
        return msg

    @staticmethod
    def _tool_has_date_params(tool: Tool) -> bool:
        """检测工具是否包含日期/时间相关参数。"""
        for arg in tool.args:
            name_lower = arg.name.lower()
            desc_lower = (arg.description or '').lower()
            if any(kw in name_lower or kw in desc_lower for kw in _DATE_PARAM_KEYWORDS):
                return True
        return False

    @staticmethod
    def _format_tool_info(tool: Tool) -> str:
        """将 Tool.args 格式化为可读 parameters.properties schema。"""
        lines = []
        for arg in tool.args:
            default = arg.default if arg.default not in (None, '') else '(无)'
            lines.append(
                f'- name={arg.name} | type={arg.arg_type} | required={arg.required} '
                f'| description={arg.description} | default={default}'
            )
        return '\n'.join(lines) if lines else '(无参数)'

    async def _build_tool_param_extraction_prompt(
        self,
        tool: Tool,
        query: str,
        request: ChatRequest,
    ) -> str:
        """渲染工具参数抽取专用 prompt。"""
        system_date = date.today().strftime('%Y-%m-%d')
        return await self.env.get_template(_TOOL_PARAM_EXTRACTION_TMPL).render_async({
            'query': query,
            'global_param': json.dumps(
                request.env.model_dump(by_alias=True), ensure_ascii=False
            ),
            'tool_info': self._format_tool_info(tool),
            'system_date': system_date,
            'tool_name': tool.name,
            'has_date_params': self._tool_has_date_params(tool),
        })

    async def _extract_tool_params(
        self,
        model: BaseLLM,
        tools: List[Tool],
        request: ChatRequest,
        conversation_id: str
    ) -> List[Tuple[Tool, dict]]:
        """为每个工具单独调用 LLM 提取参数，失败的工具跳过。"""
        results: List[Tuple[Tool, dict]] = []
        query = flatten_user_content_for_token_count(request.user_chats[0].content)
        for tool in tools:
            self.logger.info(f'开始为工具[{tool.name}]提取参数，URL：{tool.url}')
            prompt = await self._build_tool_param_extraction_prompt(tool, query, request)
            self.logger.info(
                f'conv_id={conversation_id}, '
                f'run_path=channelV2->_run->_extract_tool_params, '
                f'prompt={prompt}, 打印执行工具抽取时的system_prompt'
            )
            params = {}
            try:
                async for response in model.stream_chat(
                    prompt, [tool], [], 'user',
                    request.user_chats[0].content, 'channel', False
                ):
                    if isinstance(response, int):
                        continue
                    if hasattr(response, 'tool_calls') and response.tool_calls:
                        try:
                            self.logger.info(
                                f'conv_id={conversation_id}, '
                                f'run_path=channelV2->_run->_extract_tool_params, '
                                f'tool={format_log_value(tool)}, '
                                f'query={query}, '
                                f'response={response.tool_calls[0].arguments}'
                            )
                            params = json.loads(response.tool_calls[0].arguments)
                            self.logger.info(
                                f'成功解析工具[{tool.name}]参数: {format_log_value(params)}'
                            )
                            break
                        except json.JSONDecodeError as e:
                            self.logger.error(f'解析工具[{tool.name}]参数JSON失败: {e}')
                if params:
                    results.append((tool, params))
                else:
                    self.logger.warning(f'工具[{tool.name}]未提取到参数，跳过执行')
            except Exception as e:
                self.logger.error(f'为工具[{tool.name}]提取参数异常: {e}', exc_info=True)
        return results

    @staticmethod
    def _get_tool_field_map(tool: Tool) -> Dict[str, str]:
        """从 tool.return_description 解析字段中英映射。"""
        if not tool.return_description:
            return {}
        try:
            return json.loads(tool.return_description)
        except Exception:
            return {}

    def _normalize_tool_data(
        self,
        res_data: Any,
        field_map: Dict[str, str],
        tool_name: Optional[str] = None,
    ) -> List[Any]:
        """将 tool data 转为行列表；list 超过 MAX_TOOL_ROWS 时截断。"""
        if isinstance(res_data, dict):
            return [{field_map.get(k, k): v for k, v in res_data.items()}]
        if isinstance(res_data, list):
            total = len(res_data)
            if total > self.MAX_TOOL_ROWS:
                self.logger.info(
                    '工具[%s] data 截断: 共%d条，仅展示前%d条',
                    tool_name or 'unknown', total, self.MAX_TOOL_ROWS,
                )
            return [
                {field_map.get(k, k): v for k, v in row.items()}
                for row in res_data[:self.MAX_TOOL_ROWS]
            ]
        return [res_data]

    def _parse_tool_json_result(
        self,
        content: str,
        tool: Tool,
        *,
        with_output_hint: bool = False,
    ) -> str:
        """解析工具 JSON 响应：校验 code、截断 data、字段中文化。"""
        if not content:
            return '未获取到相关数据'
        executor = ToolExtractor(content)
        if not executor.is_ok():
            return executor.get_msg()
        rows = self._normalize_tool_data(
            executor.get_data(),
            self._get_tool_field_map(tool),
            tool.name if tool else None,
        )
        text = str(rows)
        if with_output_hint:
            hint = tool.output_example or '请使用文本或者markdown表格呈现数据'
            text = f'{text},{hint}'
        return text

    @staticmethod
    def _build_tool_results_summary(execution_results: Dict[str, str]) -> str:
        """将工具执行结果拼接为 Markdown 字符串注入 tool 消息。"""
        lines = ['## 工具执行结果汇总\n']
        for name, info in execution_results.items():
            lines.append(f'### {name}\n{info}\n')
        lines.append('\n请根据用户的问题和以上工具执行结果，回答用户的问题。')
        return '\n'.join(lines)

    # ── Function Calling 消息解析 ──────────────────────────────────────────────

    def _parse_function_call_chat(
        self,
        msg: Message,
        tools: Dict[str, Tool],
        user_chats: List[Message],
        call_map: Dict[str, ZxhToolCall],
    ) -> Tuple[Optional[Message], str, bool]:
        """解析 function calling 流中每帧消息的角色和工具状态。

        根据消息角色和工具 tags 返回三元组，调用方据此走不同分支：

        =================== =============== =================== =================================
        场景                  tmp_msg         is_direct_reply    调用方行为
        =================== =============== =================== =================================
        tool 角色 + reply    Message (结果)   True              直接 SSE 输出，跳过 LLM 整理
        tool 角色（无reply）  None            False             结果已注入 user_chats，需 LLM 整理
        assistant 角色       Message (文本)   False             回复纯文本，无需工具处理
        =================== =============== =================== =================================

        Returns:
            (tmp_msg, content_type, is_direct_reply)
        """
        if msg.role == 'tool':
            tool = tools.get(call_map.get(msg.tool_call_id).name)
            content_type = 'html' if 'html' in tool.tags else 'text'
            if 'reply' in tool.tags:
                # reply 标签：工具结果直接作为最终回复，跳过 LLM 整理
                user_chats.append(Message(
                    role='tool', content=msg.content,
                    tool_call_id=msg.tool_call_id, assistant='channel'
                ))
                return (
                    Message(
                        role='assistant',
                        content=self._parse_tool_json_result(msg.content, tool),
                        assistant='channel',
                    ),
                    content_type, True,
                )
            # 无 reply 标签：标准化工具内容后注入上下文，调用方后续用 LLM 整理
            parsed = self._parse_tool_item(
                msg.content, call_map.get(msg.tool_call_id), tools
            )
            user_chats.append(Message(
                role='tool', content=parsed,
                tool_call_id=msg.tool_call_id, assistant='channel'
            ))
            return None, content_type, False
        return Message(
            role='assistant', content=msg.content, assistant='channel'
        ), 'text', False

    def _parse_tool_item(
        self, content: str, call: ZxhToolCall, tools: Dict[str, Tool]
    ) -> str:
        """标准化工具返回的 JSON：英文字段名 → 中文，附加输出格式提示。"""
        return self._parse_tool_json_result(
            content, tools.get(call.name), with_output_hint=True
        )

    # ── 消息过滤 ───────────────────────────────────────────────────────────────

    def _filter_messages(self, messages: List[Message]) -> List[Message]:
        """过滤 tool 角色和带 tool_calls 的助手消息，让 LLM 感知工具数据但不感知格式。

        策略:
          1. 移除所有 tool 消息（原始 JSON 对 LLM 是噪音）
          2. 移除所有带 tool_calls 的 assistant 消息
          3. 将最后一条 tool 内容以纯文本附加到最后一条 user 消息尾部

        副作用: 通过 deepcopy 保证不修改原始消息列表。
        """
        copied = deepcopy(messages)
        filtered = [m for m in copied if m.role != 'tool' and m.tool_calls is None]
        last_tool = next((m for m in reversed(copied) if m.role == 'tool'), None)
        if last_tool:
            last_user = next(
                (m for m in reversed(filtered) if m.role == 'user'), None
            )
            if last_user:
                last_user.content += (
                    f', 参考获取到的数据:{last_tool.content}'
                    f',当前系统日期是:{date.today().strftime("%Y-%m-%d")},全程使用中文回复！'
                )
        return filtered


    async def recognize_intents(
        self,
        model: BaseLLM,
        query: str,
        history: List[Message],
        is_image_request: bool = False,
    ) -> Tuple[bool, bool, bool]:
        """一次性识别绘图、农信业务、PPT 三类意图，失败时降级到独立 prompt 并发识别。"""
        defaults = (False, False, False)
        try:
            need_plotting, belong_to_farming, need_gen_ppt = await self._intent_recognition_combined(
                model, query, history
            )
            if is_image_request:
                need_plotting = False
            return need_plotting, belong_to_farming, need_gen_ppt
        except Exception as e:
            self.logger.warning(f'综合意图识别失败，降级到独立prompt并发识别: {e}')

        try:
            need_plotting, belong_to_farming, need_gen_ppt = await self._intent_recognition_with_separate_prompts(
                model, query, history, is_image_request
            )
            return need_plotting, belong_to_farming, need_gen_ppt
        except Exception as e:
            self.logger.warning(f'独立prompt并发意图识别失败，使用默认值: {e}')
            return defaults

    async def _intent_recognition_combined(
        self,
        model: BaseLLM,
        query: str,
        history: List[Message],
    ) -> Tuple[bool, bool, bool]:
        """主逻辑：使用合并 prompt 一次返回三个意图标签。"""
        prompt = await self.env.get_template(_INTENT_RECOGNITION_PROMPT_TMPL).render_async()
        flattened_query = flatten_user_content_for_token_count(query)
        res = await model.chat(prompt, [], history, 'user', flattened_query, 'channel', True)
        if not res or not res[0].content:
            raise ValueError('综合意图识别返回为空')
        return self._parse_intent_recognition_result(res[0].content)

    async def _intent_recognition_with_separate_prompts(
        self,
        model: BaseLLM,
        query: str,
        history: List[Message],
        is_image_request: bool,
    ) -> Tuple[bool, bool, bool]:
        """备用逻辑：沿用三个旧 prompt，并发分别识别三个意图。"""
        need_plotting = False
        belong_to_farming = False
        need_gen_ppt = False

        if is_image_request:
            # 识图时认为不需要绘图，仅并发识别农业领域和 PPT 意图。
            belong_to_farming, need_gen_ppt = await asyncio.gather(
                self.intent_recognition(
                    IntentRecognitionDim.FARMING, model, query, history
                ),
                self.intent_recognition(
                    IntentRecognitionDim.PPT, model, query, history
                ),
            )
        else:
            # 旧并发处理逻辑保留：三个旧 prompt 分别分类，最后分别获取分类结果。
            need_plotting, belong_to_farming, need_gen_ppt = await asyncio.gather(
                self.intent_recognition(
                    IntentRecognitionDim.PLOTTING, model, query, history
                ),
                self.intent_recognition(
                    IntentRecognitionDim.FARMING, model, query, history
                ),
                self.intent_recognition(
                    IntentRecognitionDim.PPT, model, query, history
                ),
            )

        return need_plotting, belong_to_farming, need_gen_ppt

    @staticmethod
    def _parse_intent_recognition_result(content: str) -> Tuple[bool, bool, bool]:
        """解析综合意图识别 JSON，兼容模型误包裹的代码块或说明文字。"""
        text = content.strip()
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            text = match.group(0)
        data = json.loads(text)
        return (
            ChannelV2._bool_value(data.get('need_plotting', False)),
            ChannelV2._bool_value(data.get('belong_to_farming', False)),
            ChannelV2._bool_value(data.get('need_gen_ppt', False)),
        )

    @staticmethod
    def _bool_value(value: Any) -> bool:
        """将模型可能返回的 bool/string/number 规整为 bool。"""
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in {'true', '1', 'yes', 'y', '是', '需要'}
        return bool(value)

    async def intent_recognition(self, dim: IntentRecognitionDim, model: BaseLLM, query: str, history: List[Message]) -> bool:
        """
        LLM 判断用户意图。
        Args:
            dim: 意图识别维度
            model: LLM
            query: 用户请求
            history: 上下文
        """
        try:
            prompt = await self.env.get_template(dim.value).render_async()
            query = flatten_user_content_for_token_count(query)
            res = await model.chat(prompt, [], history, 'user', query, 'channel', False)
            return 'true' in res[0].content.strip().lower()
        except Exception:
            return False

    async def plotting_echarts_rewrite_query(
        self,
        need_plotting: bool,
        model: BaseLLM,
        request: ChatRequest,
        history: List[Message],
        dataset_dict: dict = {},
    ) -> Tuple[str, str]:
        """生成 ECharts 图表。

        流程:
          1. render plotting_echarts_prompt.md 模板并交给 LLM 生成 ECharts option JSON
          2. 调用 echarts 渲染服务生成图片 URL
          3. 根据 option.series[0].type 确定图表类型中文名

        Returns:
            (图表图片URL, 图表类型中文名)。失败时返回 ('', '图表')。
        """
        if not need_plotting:
            return '', '图表'
        self.logger.info('开始生成图表')
        query = request.user_chats[0].content
        prompt = await self.env.get_template(_ECHARTS_PROMPT_TMPL).render_async({
            'dataset_dict': str(dataset_dict) if dataset_dict else ''
        })
        try:
            res = await model.chat(prompt, [], history, 'user', query, 'channel', False)
            echarts_json = json.loads(res[0].content.strip())
            # 强制白色背景，确保在深色主题前端中可读
            if 'option' in echarts_json:
                echarts_json['option']['backgroundColor'] = '#fff'
            self.logger.info(
                f'生成图表参数为：{json.dumps(echarts_json, ensure_ascii=False, separators=(",", ":"))}'
            )
            result = await self.client.post_json(
                self.echarts_server, None, echarts_json, {}, None,
                lambda x: x.json(content_type=None)
            )
            if result['code'] != 0:
                self.logger.warning(f'生成图表失败：{result["msg"]}')
                return '', '图表'
            option = echarts_json.get('option', {})
            if 'series' not in option:
                return '', '图表'
            echarts_type = EChartsType.get_name(option['series'][0]['type'])
            self.logger.info(f'生成`{echarts_type}`成功：{result["data"]}')
            return result['data'], echarts_type
        except Exception as e:
            self.logger.warning(f'生成图表失败：{e}')
            return '', '图表'

    async def gen_ppt_by_content(self, need_gen_ppt, model: BaseLLM, request, history, dataset_dict: dict = {}) -> str:
        """生成 PPT，返回 PPT 下载地址"""
        if not need_gen_ppt:
            return ''
        self.logger.info('开始生成PPT')
        query = request.user_chats[0].content
        prompt = await self.env.get_template(_PPT_PROMPT_TMPL).render_async({
            'dataset_dict': str(dataset_dict) if dataset_dict else ''
        })
        try:
            res = await model.chat(prompt, [], history, 'user', query, 'channel', False)
            ppt_plan_json = json.loads(res[0].content.strip())
            self.logger.info(
                f'生成 PPT 计划 json 为：{json.dumps(ppt_plan_json, ensure_ascii=False, separators=(",", ":"))}'
            )
            ppt_url = await gen_ppt(ppt_plan_json, filename='演示文稿.pptx')
            self.logger.info(f'生成 PPT 下载地址为：{ppt_url}')
            return ppt_url
        except Exception as e:
            self.logger.warning(f'生成 PPT 失败：{e}')
            return ''

    # ── 静态工具 ───────────────────────────────────────────────────────────────

    @staticmethod
    def build_search_zsk_knowledge_tool() -> ChatCompletionToolParam:
        """构建 ZSK 知识库搜索的 function calling 工具定义。"""
        return {
            'type': 'function',
            'function': {
                'name': 'search_zsk_knowledge',
                'description': '搜索知识库回答用户的问题',
                'parameters': {
                    'type': 'object',
                    'properties': {
                        'query': {
                            'type': 'string',
                            'description': '用户问题',
                        },
                    },
                    'required': ['query'],
                    'additionalProperties': False,
                },
            },
        }

    # ── 会话 / 模型 / Prompt 初始化 ────────────────────────────────────────────

    async def _load_or_create_session(
        self, request: ChatRequest
    ) -> Tuple[str, List[Message], Any]:
        """加载已有会话或创建新会话。"""
        if request.conversation_id is None:
            return str(uuid4()), [], []
        conv_id = request.conversation_id
        conv_info = await self.store.load_chat(conv_id)
        if conv_info:
            return conv_id, conv_info.msg, conv_info.knowledge
        return conv_id, [], []

    def _create_model(
        self, llm_config, temperature: float, request: ChatRequest
    ) -> BaseLLM:
        """创建 LLM 模型实例。"""
        return LlmFactory.create(
            llm_config, temperature, self.client,
            self.langflow_client, self.nlp, self.logger, request
        )

    @staticmethod
    def _build_role_prompt(request: ChatRequest) -> str:
        """构建角色 system prompt（角色设定 + 当前日期 + 时间推导规则）。"""
        return (
            'Role: ' + request.agent_data.role_settings
            + '当前系统日期是: ' + date.today().strftime('%Y-%m-%d')
            + '（当用户问题涉及数据查询、时间分析或函数调用时，需要结合当前日期进行时间推导；'
            '如果函数调用需要开始时间和结束时间参数，但用户未明确指定时间范围，'
            '则默认查询近30天的数据：结束时间为当前日期，开始时间为当前日期往前推30天；'
            '如果用户明确指定了时间，则优先使用用户时间；普通闲聊场景无需主动提及当前日期。）'
        )

    async def _prepare_user_chats(
        self,
        history: List[Message],
        model: BaseLLM,
        llm_config,
        temperature: float,
        request: ChatRequest,
    ) -> Tuple[List[Message], BaseLLM]:
        """处理多模态文件，构建本轮用户消息上下文。

        根据文件类型走三条路径:
          - 图片 (image): 切换为豆包视觉模型 (doubao-1.6-vision-pro)，
            构造 ChatImgContentPart + ChatTextContentPart 多模态 content
          - 文本文件 (docx/pdf/pptx/csv/txt): 调用 multimodal_util 解析文件，
            将纯文本内容追加到用户消息末尾
          - 无文件: 过滤历史中的 multimodal 消息，仅保留纯文本上下文

        Returns:
            (user_chats 列表, 可能已切换的 model 实例)
        """
        file_url = request.user_chats[0].file_url
        file_type = request.user_chats[0].file_type

        if file_url and file_type == 'image':
            request.user_chats[0].deep_thinking = 0
            llm_config = await self.llm_repository.get_config('doubao-1.6-vision-pro')
            model = self._create_model(llm_config, temperature, request)
            request.user_chats[0].content = [
                ChatImgContentPart(type='image_url', url=file_url, detail='auto'),
                ChatTextContentPart(type='text', text=request.user_chats[0].content),
            ]
            user_chats = history + [Message(
                role='user',
                content=[self._parse_user_msg(it) for it in request.user_chats[0].content],
                assistant='channel',
            )]
        elif file_url:
            detected_type = parse_file_type(file_url)
            file_content = await parse_file_url_content(file_url, detected_type)
            request.user_chats[0].content += (
                f'\n以下内容是格式为{detected_type}的关联文件（附件）解析出来的文本\n---\n{file_content}'
            )
            user_chats = history + [Message(
                role='user', content=request.user_chats[0].content, assistant='channel'
            )]
        else:
            user_chats = (
                [m for m in history if m.assistant != 'multimodal']
                + [Message(
                    role='user', content=request.user_chats[0].content, assistant='channel'
                )]
            )
        return user_chats, model

    @staticmethod
    def _parse_user_msg(msg) -> dict:
        """将内部消息对象转为 OpenAI 多模态 content item 格式。"""
        if isinstance(msg, str):
            return msg
        if isinstance(msg, ChatTextContentPart):
            return {'type': 'text', 'text': msg.text}
        if isinstance(msg, ChatImgContentPart):
            return {'type': 'image_url', 'image_url': msg.url}

    # ── 持久化 ─────────────────────────────────────────────────────────────────

    async def _persist_conversation(
        self,
        conversation_id: str,
        request: ChatRequest,
        llm_id: int,
        temperature: float,
        tools: List[Tool],
        knowledge: Any,
        user_chats: List[Message],
        model_result: List[Message],
        role_prompt: str,
        ans: str,
    ) -> None:
        """保存对话记录和操作日志到数据库。

        写两张表:
          - chat_msg: 完整对话上下文（消息列表 + 工具 + 知识），下次加载时恢复会话
          - chat_log: 操作审计日志（prompt / query / answer 截断至 980 字符）
        """
        await self.store.save_chat(ChatMsg(
            id=conversation_id, env=request.env,
            llm_id=llm_id, temperature=temperature,
            tools=tools, knowledge=knowledge,
            msg=user_chats + model_result,
        ))
        await self.store.add_chat_log(ChatLog(
            conversation_id=conversation_id,
            stage='快速回复通道', agent_name='fast_channel',
            prompt=substr(role_prompt, 0, 980),
            content=substr(str(user_chats[-1].content), 0, 980),
            answer=substr(
                f'获取到的知识为[{knowledge}]\n大模型回复内容为[{model_result[-1].content}]',
                0, 980,
            ),
        ))
        self.logger.info(f'回复内容为[{ans[:100]}]')
        self.logger.info(f'结尾内容为[{ans[-600:]}]')

    # ── SSE 帧构造辅助 ─────────────────────────────────────────────────────────

    @staticmethod
    def _sse_start(request: ChatRequest, conv_id: str, start_time: float) -> str:
        """构造 SSE start 帧。"""
        return json.dumps({
            'type': 'start',
            'time': int(start_time),
            'feedback_id': request.feedback_id,
            'question_id': request.feedback_id.split('#')[-1],
            'conversation_id': conv_id,
        }) + '\n\n'

    @staticmethod
    def _sse_end(
        request: ChatRequest, conv_id: str, tk_count: Dict[str, int]
    ) -> str:
        """构造 SSE end 帧。"""
        return json.dumps({
            'type': 'end',
            'time': int(time.time()),
            'feedback_id': request.feedback_id,
            'question_id': request.feedback_id.split('#')[-1],
            'conversation_id': conv_id,
            'token_total': tk_count,
        }) + '\n\n'

    @staticmethod
    def _sse_generating(
        request: ChatRequest,
        conv_id: str,
        content: str,
        content_type: str = 'text',
    ) -> str:
        """构造 SSE generating 帧。"""
        return json.dumps({
            'type': 'generating',
            'feedback_id': request.feedback_id,
            'conversation_id': conv_id,
            'content': content,
            'content_type': content_type,
        }, ensure_ascii=False)
