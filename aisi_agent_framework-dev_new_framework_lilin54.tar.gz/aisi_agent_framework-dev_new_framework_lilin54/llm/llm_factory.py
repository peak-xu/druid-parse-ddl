from logging import Logger

from api import LangFlowClient
from entity import ChatRequest
from errors import DomainError
from models import LlmConfig
from nlp import Nlp
from utils import HttpClient
from .base_llm import BaseLLM
from .chatgpt import ChatGpt
from .chat_glm import ChatGlm
from .qwen import Qwen
from .moonshot import Moonshot
from .deepseek import Deepseek
from .doubao import Doubao
from .deepseek_reasoner import DeepseekReasoner


class LlmFactory:
    """LLM 工厂，根据 config.type 创建对应的模型实例。

    type 映射:
      ===== ====================
      type  模型类
      ===== ====================
      1     ChatGPT (Azure)
      2     ChatGLM
      3     Qwen (通义千问)
      4     Moonshot (月之暗面)
      5     DeepSeek
      6     Doubao (豆包)
      7     DeepSeekReasoner (R1)
      ===== ====================
    """

    @staticmethod
    def create(config: LlmConfig, temperature: int | float, http_client: HttpClient, langflow_client: LangFlowClient, nlp: Nlp, logger: Logger, request: ChatRequest) -> BaseLLM:
        if config.type == 1:
            return ChatGpt(config, temperature, http_client, langflow_client, nlp, logger, request)
        elif config.type == 2:
            return ChatGlm(config, temperature, http_client, langflow_client, nlp, logger, request)
        elif config.type == 3:
            return Qwen(config, temperature, http_client, langflow_client, nlp, logger, request)
        elif config.type == 4:
            return Moonshot(config, temperature, http_client, langflow_client, nlp, logger, request)
        elif config.type == 5:
            return Deepseek(config, temperature, http_client, langflow_client, nlp, logger, request)
        elif config.type == 6:
            return Doubao(config, temperature, http_client, langflow_client, nlp, logger, request)
        elif config.type == 7:
            return DeepseekReasoner(config, temperature, http_client, langflow_client, nlp, logger, request)
        else:
            raise DomainError(31001, f'不支持的大模型类型:{config.type}')
