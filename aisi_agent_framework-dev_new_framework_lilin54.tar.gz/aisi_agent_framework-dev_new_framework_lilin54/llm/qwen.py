from asyncio import TaskGroup
from typing import override, List, Optional, Iterable
from logging import Logger
from json import loads, dumps

from openai import AsyncOpenAI, NOT_GIVEN
from openai.types.chat import ChatCompletionMessageParam, ChatCompletionSystemMessageParam, \
    ChatCompletionUserMessageParam, ChatCompletionAssistantMessageParam, ChatCompletionToolMessageParam, \
    ChatCompletionFunctionMessageParam, ChatCompletionMessageToolCallParam, ChatCompletionToolParam, \
    ChatCompletionContentPartParam
from openai.types.chat.chat_completion_message_tool_call_param import Function
from openai.types.shared_params import FunctionDefinition
from tiktoken import get_encoding

from api import LangFlowClient
from entity import Tool, Message, ZxhToolCall, LangFlow, ChatContentPart, ChatRequest
from errors import TokenExceedError
from models import LlmConfig
from nlp import Nlp
from utils import HttpClient, ColUtil
from .base_llm import BaseLLM
from .user_content_openai import user_content_part_to_openai_param


class Qwen(BaseLLM):
    """
    通义千问（阿里云）LLM 适配器。

    基于 OpenAI 兼容 API 对接 Qwen 系列模型。特性：
    - 完整的 function calling（tool_calls / function_call）支持
    - 流式 + 非流式对话
    - reasoning_content 思维链输出（用 <think_deeply></think_deeply> 标签包裹）
    - enable_thinking 参数控制深度思考模式（通过 extra_body 传递）
    - 流式 tool_calls 增量拼接（final_tool_calls dict 按 index 累积 fragment）
    - 工具列表为空时传 NOT_GIVEN（避免 Qwen API 报错）
    - tiktoken 精确 token 计数
    """
    def __init__(self, config: LlmConfig, temperature: int | float, http_client: HttpClient, langflow_client: LangFlowClient, nlp: Nlp, logger: Logger, request: ChatRequest):
        super().__init__(config, temperature, http_client, langflow_client, nlp, logger, request)
        self.model = AsyncOpenAI(api_key=config.key, base_url=config.endpoint)
        self.encoding = get_encoding(config.encoding_name)
        self.data_type_mapping = {'string': 'string', 'text': 'string', 'char': 'string', 'date': 'string', 'int': 'number', 'integer': 'number', 'long': 'number', 'float': 'number', 'dict': 'object', 'list': 'array', 'bool': 'boolean', 'none': 'null'}

    @override
    async def achat(self, assistant: str, tools: List[Tool], msg: List[Message], resp_json: bool, wf_tools: List[LangFlow] = []) -> List[Message]:
        try:
            content = msg[-1].content
            resp = await self.model.chat.completions.create(model=self.config.llm_name, temperature=self.temperature, messages=[m for m in (self._transform_msg(it) for it in msg) if m is not None], tools=[self._parse_tool(it) for it in tools] if [self._parse_tool(it) for it in tools] else NOT_GIVEN,
                                                            max_tokens=self.config.max_response_token, response_format={"type": "json_object"} if resp_json else NOT_GIVEN)
            res = []
            for choice in resp.choices:
                if choice.finish_reason == 'length':
                    raise TokenExceedError()
                elif choice.finish_reason == 'tool_calls':
                    res.append(Message(id=resp.id, role=choice.message.role, content=None, tool_calls=[ZxhToolCall(id=it.id, name=it.function.name, arguments=it.function.arguments) for it in choice.message.tool_calls], assistant=assistant))
                    calls = []
                    for call in choice.message.tool_calls:
                        tool = ColUtil.single(tools, lambda x: x.name == call.function.name)
                        if tool is not None:
                            calls.append((call, tool))
                    if len(calls) == 1:
                        call, tool = calls[0]
                        r = await self.invoke_tool(call.id, tool, loads(call.function.arguments), wf_tools, content)
                        res.append(Message(id=resp.id, role='tool', tool_call_id=r[0], content=r[1], assistant=assistant))
                    elif len(calls) > 1:
                        tasks = []
                        async with TaskGroup() as g:
                            for call, tool in calls:
                                tasks.append(g.create_task(self.invoke_tool(call.id, tool, loads(call.function.arguments), wf_tools, content)))
                        for it in tasks:
                            r = it.result()
                            res.append(Message(id=resp.id, tool_call_id=r[0], role='tool', content=r[1], assistant=assistant))
                elif choice.finish_reason == 'function_call':
                    fc = choice.message.function_call
                    tool = ColUtil.single(tools, lambda x: x.name == fc.name)
                    if tool is not None:
                        r = await self.invoke_tool(fc.name, tool, loads(fc.arguments), wf_tools, content)
                        res.append(Message(id=resp.id, role='function', function_name=r[0], content=r[1], assistant=assistant))
                else:
                    res.append(Message(id=resp.id, role=choice.message.role, content=choice.message.content, assistant=assistant))
            return res
        except Exception as e:
            self.logger.error(f'调用qwen异常[assistant:{assistant},msg:{dumps([it.model_dump() for it in msg], ensure_ascii=False)}]', stack_info=True, exc_info=e)
            return []

    @override
    async def stream_achat(self, assistant: str, tools: List[Tool], msg: List[Message], resp_json: bool, enable_thinking: bool = False):
        try:
            response = await self.model.chat.completions.create(
                model=self.config.llm_name,
                temperature=0,
                messages=[m for m in (self._transform_msg(it) for it in msg) if m is not None],
                max_tokens=self.config.max_response_token,
                response_format={"type": "json_object"} if resp_json else NOT_GIVEN,
                tools=[self._parse_tool(it) for it in tools] if len(tools) > 0 else NOT_GIVEN,
                tool_choice='auto' if len(tools) > 0 else NOT_GIVEN,
                extra_body={"enable_thinking": enable_thinking},
                top_p=0.95,
                stream=True
            )
            logger_flag = True
            final_tool_calls = {}
            think_added = False
            async for resp in response:
                if not resp.choices:
                    continue
                if logger_flag:
                    logger_flag = False
                    self.logger.info(f'qwen模型名称:[{resp.model}],请求id:[{resp.id}]')
                delta_obj = resp.choices[0].delta
                if (resp.choices[0].finish_reason == "stop" or resp.choices[0].finish_reason == "tool_calls") and resp.usage is not None:
                    yield resp.usage.total_tokens
                reasoning_piece = getattr(delta_obj, 'reasoning_content', None) or None
                content_piece = delta_obj.content
                if not content_piece and not reasoning_piece and not delta_obj.tool_calls and not resp.choices[0].finish_reason:
                    continue
                if delta_obj.tool_calls:
                    # 拼接函数调用信息
                    for tool_call_chunk in delta_obj.tool_calls:
                        call_index = tool_call_chunk.index
                        tool_call_chunk.function.arguments = tool_call_chunk.function.arguments or ""
                        if call_index not in final_tool_calls:
                            final_tool_calls[call_index] = tool_call_chunk
                        else:
                            final_tool_calls[call_index].function.arguments += tool_call_chunk.function.arguments
                if hasattr(delta_obj, 'reasoning_content') and delta_obj.reasoning_content:
                    if not think_added:
                        ans = f"\n\n<think_deeply>\n\n{delta_obj.reasoning_content}"
                        think_added = True
                    else:
                        ans = delta_obj.reasoning_content
                elif content_piece:
                    if think_added:
                        ans = f"\n</think_deeply>{delta_obj.content}"
                        think_added = False
                    else:
                        ans = delta_obj.content
                else:
                    ans = content_piece
                if resp.choices[0].finish_reason == "length":
                    ans = (ans or "") + "······\n由于长度的原因，回答被截断了，要继续吗？"
                if resp.choices[0].finish_reason == "tool_calls":
                    yield Message(id=resp.id, role='assistant', content=None, tool_calls=[ZxhToolCall(id=tool_call.id, name=tool_call.function.name, arguments=tool_call.function.arguments) for index, tool_call in final_tool_calls.items()], assistant=assistant)
                    calls = []
                    for index, call in final_tool_calls.items():
                        tool = ColUtil.single(tools, lambda x: x.name == call.function.name)
                        if tool is not None:
                            calls.append((call, tool))
                    if len(calls) == 1:
                        call, tool = calls[0]
                        r = await self.invoke_tool(call.id, tool, loads(call.function.arguments))
                        yield Message(id=resp.id, role='tool', tool_call_id=r[0], content=r[1], assistant=assistant)
                    elif len(calls) > 1:
                        tasks = []
                        async with TaskGroup() as g:
                            for call, tool in calls:
                                tasks.append(g.create_task(self.invoke_tool(call.id, tool, loads(call.function.arguments))))
                        for it in tasks:
                            r = it.result()
                            yield Message(id=resp.id, tool_call_id=r[0], role='tool', content=r[1], assistant=assistant)
                else:
                    if ans:
                        yield Message(id=resp.id, role='assistant', content=ans, assistant=assistant)

        except Exception as e:
            self.logger.error(f'调用qwen异常[assistant:{assistant},msg:{dumps([it.model_dump() for it in msg], ensure_ascii=False)}]', stack_info=True, exc_info=e)

    @override
    def token_length(self, content: Optional[str]) -> int:
        if content is None:
            return 0
        return len(self.encoding.encode(content))

    @override
    def tool_token(self, tools: List[Tool]) -> int:
        if len(tools) == 0:
            return 0
        llm_tools = [self._parse_tool(tool) for tool in tools]
        return len(self.encoding.encode(dumps(llm_tools, ensure_ascii=False)))

    @override
    def tool_call_token_length(self, calls: List[ZxhToolCall]) -> int:
        tcs = [ChatCompletionMessageToolCallParam(id=it.id, function=Function(name=it.name, arguments=it.arguments), type='function') for it in calls]
        return self.token_length(dumps(tcs, ensure_ascii=False))

    @override
    def translate_type(self, data_type: str) -> str:
        nt = self.data_type_mapping.get(data_type.lower())
        if nt is not None:
            return nt
        return data_type

    @override
    def keyword_rewrite(self, content: str) -> str:
        return content

    @override
    async def ocr(self, url: str, purpose: str) -> str:
        pass

    def _transform_msg(self, msg: Message) -> Optional[ChatCompletionMessageParam]:
        if msg.role == 'system':
            return ChatCompletionSystemMessageParam(role='system', content=msg.content)
        elif msg.role == 'user':
            if msg.content is None:
                return None
            elif isinstance(msg.content, str):
                return ChatCompletionUserMessageParam(role='user', content=msg.content)
            elif isinstance(msg.content, Iterable):
                return ChatCompletionUserMessageParam(role='user', content=[self._parse_user_msg(it) for it in msg.content])
            else:
                return None
        elif msg.role == 'assistant':
            if msg.tool_calls is None:
                return ChatCompletionAssistantMessageParam(role='assistant', content=msg.content)
            return ChatCompletionAssistantMessageParam(role='assistant', content=msg.content, tool_calls=[ChatCompletionMessageToolCallParam(id=it.id, function=Function(name=it.name, arguments=it.arguments), type='function') for it in msg.tool_calls])
        elif msg.role == 'tool':
            return ChatCompletionToolMessageParam(role='tool', content=msg.content, tool_call_id=msg.tool_call_id)
        else:
            return ChatCompletionFunctionMessageParam(role='function', name=msg.function_name, content=msg.content)

    def _parse_tool(self, tool: Tool) -> ChatCompletionToolParam:
        props = {arg.name: {'type': self.translate_type(arg.arg_type), 'description': arg.description} for arg in tool.args}
        required = ColUtil.map(ColUtil.where(tool.args, lambda x: x.required), lambda x: x.name)
        return ChatCompletionToolParam(type='function', function=FunctionDefinition(name=tool.name, description=tool.description, parameters={'type': 'object', 'properties': props, 'required': required, 'additionalProperties': False}))

    def _parse_user_msg(self, msg: ChatContentPart) -> ChatCompletionContentPartParam:
        return user_content_part_to_openai_param(msg)

    @override
    async def stream_achat_report(self, assistant: str, tools, msg, resp_json):
        async for it in self.stream_achat(assistant, tools, msg, resp_json):
            yield it
