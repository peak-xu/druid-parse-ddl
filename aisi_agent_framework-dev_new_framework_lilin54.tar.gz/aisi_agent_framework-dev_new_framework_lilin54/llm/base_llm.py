"""LLM 抽象基类 + 辅助函数。

BaseLLM 定义了与 LLM 交互的统一接口，各实现类（ChatGpt / Deepseek / Doubao 等）
只需覆写抽象方法和以下钩子：
  - _transform_msg: 将内部 Message 转为模型 SDK 的消息格式
  - _parse_tool: 将内部 Tool 转为模型 SDK 的 tool 定义
  - token_length / tool_token / tool_call_token_length: Token 计数
"""
import json
from abc import ABC, abstractmethod
from json import dumps
from logging import Logger
from time import time
from typing import List, Mapping, Any, Optional, Tuple, AsyncGenerator
from urllib.parse import quote
from uuid import uuid4

from openai import AsyncOpenAI, NOT_GIVEN
from openai.types.chat import ChatCompletionMessageParam, ChatCompletionToolParam

from api import LangFlowClient
from entity import Tool, Message, Role, ZxhToolCall, LangFlow, ChatRequest, ChatTextContentPart, ChatImgContentPart, ChatAudioContentPart
from entity.message import AsyncTask
from errors import TokenExceedError
from models import LlmConfig
from nlp import Nlp
from utils import HttpClient, ColUtil, substr, format_log_value
from utils.str_util import get_uuid


def flatten_user_content_for_token_count(content: Any) -> str:
    """把 user 消息的 str 或图文/音频片段列表压成一段纯文本，供 tiktoken 等只接受字符串的编码器计数。"""
    if content is None:
        return ''
    if isinstance(content, str):
        return content
    if isinstance(content, (list, tuple)):
        parts: List[str] = []
        for item in content:
            if isinstance(item, ChatTextContentPart):
                parts.append(item.text)
            elif isinstance(item, ChatImgContentPart):
                parts.append('[图片]')
            elif isinstance(item, ChatAudioContentPart):
                parts.append('[音频]')
            elif isinstance(item, dict):
                t = item.get('type')
                if t == 'text':
                    parts.append(str(item.get('text', '')))
                elif t == 'image_url':
                    parts.append('[图片]')
                elif t == 'input_audio':
                    parts.append('[音频]')
                else:
                    parts.append(dumps(item, ensure_ascii=False))
            else:
                parts.append(str(item))
        return '\n'.join(parts)
    return dumps(content, ensure_ascii=False)


# 大模型已提取到非空值时，不允许用 tool 默认值覆盖
_NO_OVERRIDE_DEFAULT_ARGS = frozenset({
    'begindate', 'enddate', 'period', 'DateStart', 'DateEnd', 'begin_date', 'end_date','date',
    'rs_user_id', 'rs_enterprise_id', 'rs_group_id', 'rs_child_enterprise_id', 'rs_menu_id', 'rs_permissions',
    'rs-user-id', 'rs-enterprise-id', 'rs-group-id', 'rs-child-enterprise-id', 'rs-menu-id', 'rs-permissions',
})


def _is_arg_empty(value: Any) -> bool:
    return value is None or value == ''


def _pick_arg(args: Mapping[str, Any], *keys: str) -> str:
    """按顺序从 args 取值，兼容下划线与连字符参数名。"""
    for key in keys:
        v = args.get(key)
        if v is not None and v != '':
            return str(v)
    return ''


class BaseLLM(ABC):
    """LLM 统一抽象基类。

    子类需覆写的抽象方法：
      - achat / stream_achat / stream_achat_report
      - ocr
      - _transform_msg / _parse_tool
      - token_length / tool_token / tool_call_token_length
      - translate_type / keyword_rewrite

    Attributes:
        async_tasks: 异步任务列表，流式输出中若触发了异步工具调用会填充此项
        choice_tool_map: 强制工具选择映射，key=工具名, value=回调函数
    """

    def __init__(
        self,
        config: LlmConfig,
        temperature: int | float,
        http_client: HttpClient,
        langflow_client: LangFlowClient,
        nlp: Nlp,
        logger: Logger,
        request: ChatRequest,
    ) -> None:
        self.config = config
        self.temperature = temperature
        self.http_client = http_client
        self.langflow_client = langflow_client
        self.nlp = nlp
        self.logger = logger
        self.async_tasks: List[AsyncTask] = []
        self.request = request
        self.choice_tool_map: dict = {}
        self.load_choice_tool()


    def load_choice_tool(self):
        """注册强制工具选择映射。子类可覆盖以追加自定义工具 → 回调映射。"""
        self.choice_tool_map['search_zsk_knowledge'] = self.search_zsk_knowledge

    async def invoke_tool(
        self,
        call_id: str,
        tool: Tool,
        args: Mapping[str, Any],
        wf_tools: List[LangFlow] = [],
        content: str = '',
        conversation_id: str = '',
        model: str = '',
    ) -> Tuple[str, str]:
        """执行单个工具调用。

        流程:
          1. 如果是 LangFlow 工作流，直接调用 LangFlowClient.invoke
          2. 否则构造 HTTP 请求:
             a. 合并默认值（跳过 LLM 已提取的非空值）
             b. 处理 arg_mapping（枚举值 → 真实值；模糊匹配）
             c. 替换 URL 路径参数
             d. 构建 query / body / header
             e. 发送 HTTP 请求

        Returns:
            (call_id, 工具返回的原始字符串)
        """
        tool_code = get_uuid()
        # 异步工具：预注册到 async_tasks 列表，前端轮询
        if tool.is_async:
            self.async_tasks.append(AsyncTask(title=tool.skill_caption, code=tool_code, process=1))

        # LangFlow 工作流优先
        langflow = ColUtil.single(wf_tools, lambda x: x.name == tool.name)
        if langflow is not None:
            res = await self.langflow_client.invoke(langflow.id, content, langflow.node_id_list)
            return call_id, res

        # ── 普通 HTTP 工具调用 ────────────────────────────────────────────
        self.logger.info(
            f'conv_id={conversation_id}, tool={format_log_value(tool)}, args={format_log_value(args)}, '
            f'run_path=channelV2->_run->_branch_forced_tools->model.invoke_tool, 执行工具调用的原始输入-step0'
        )

        merged_args = dict(args)

        # Step a: 填入参数的默认值（LLM 已提取非空值时跳过）
        for arg in tool.args:
            v0 = merged_args.get(arg.name)
            if arg.default is None or arg.default == '' or arg.default in ('0', '1'):
                continue
            ##  抽取的字段包含日期，且提取的日期值不为空的一律不替换
            if arg.name.lower().__contains__("date") >= 0 and not _is_arg_empty(v0):
                continue
            if arg.name in _NO_OVERRIDE_DEFAULT_ARGS and not _is_arg_empty(v0):
                continue
            merged_args[arg.name] = arg.default

        # Step b: 处理 arg_mapping 映射和异步工具额外参数
        params = {}
        self.logger.info(
            f'conv_id={conversation_id}, tool={format_log_value(tool)}, args={format_log_value(merged_args)}, '
            f'run_path=channelV2->_run->_branch_forced_tools->model.invoke_tool, 执行工具调用的默认值替换与填充-step1'
        )

        for arg in tool.args:
            if arg.arg_mapping is not None and len(arg.arg_mapping) > 0:
                v = merged_args.get(arg.name)
                if v is not None and isinstance(v, str):
                    # 构建键到值的映射表（支持逗号分隔的多个别名）
                    dic = {}
                    for k, va in arg.arg_mapping.items():
                        for a in k.split(','):
                            dic[a.upper()] = va
                    value = dic.get(v.upper())
                    if value is not None:
                        params[arg.name] = value
                    else:
                        # 映射失败时用模糊匹配挽救
                        k = self.nlp.similarity(v.upper(), list(dic.keys()))
                        params[arg.name] = dic.get(k) if k is not None else v
                else:
                    params[arg.name] = v
            else:
                params[arg.name] = merged_args.get(arg.name)
                # 异步工具需注入回调和反馈信息
                if tool.is_async:
                    params['feedback_id'] = self.request.feedback_id
                    params['callback_api'] = self.request.callback_api
                    params['reply_id'] = self.request.env.reply_id
                    params['code'] = tool_code

        self.logger.info(
            f'conv_id={conversation_id}, tool={format_log_value(tool)}, args={format_log_value(params)}, '
            f'run_path=channelV2->_run->_branch_forced_tools->model.invoke_tool, 执行工具调用的相似信息处理-step2'
        )

        # Step c: 替换 URL 中的路径参数 {name}
        self.logger.info(
            f'conv_id={conversation_id}, tool={format_log_value(tool)}, '
            f'merged_args={format_log_value(merged_args)}, args={format_log_value(params)}, url={tool.url}, '
            f'run_path=channelV2->_run->_branch_forced_tools->model.invoke_tool, 执行工具调用的原始tool链接-step3'
        )
        
        url = tool.url
        for arg in ColUtil.where(tool.args, lambda x: x.location == 'path'):
            url = url.replace('{' + arg.name + '}', merged_args.get(arg.name))

        self.logger.info(
            f'conv_id={conversation_id}, tool={format_log_value(tool)}, '
            f'merged_args={format_log_value(merged_args)}, args={format_log_value(params)}, url={url}, '
            f'run_path=channelV2->_run->_branch_forced_tools->model.invoke_tool, 执行工具调用的替换后tool链接-step4'
        )

        # Step d: 构建 query string / request body / headers
        query = {it.name: merged_args.get(it.name) for it in ColUtil.where(tool.args, lambda x: x.location == 'query')}
        request_body = self._build_body(tool, params)
        header = self._build_header(tool, params)

        # 数据集服务（ed.nxin.com）要求 url 中不带 query 参数
        if 'ed.nxin.com' in url or 'ed.t.nxin.com' in url:
            url = url.split('?')[0]
            query = {}

        # Step e: 发送请求
        res = await self.http_client.request(
            tool.method, url,
            query if len(query) > 0 else None,
            request_body, header, tool.timeout,
            lambda x: x.text(),
        )
        self.logger.info(
            f'调用工具信息[id:{call_id},tool:{tool.name},'
            f'raw_args:{format_log_value(args)},'
            f'args:{format_log_value(params)}]'
        )
        self.logger.info(f'调用工具结果[{substr(res, 0, 100)}]')

        # 对工具返回的明细数据做统计聚合，减少注入 LLM context 的数据量
        try:
            from data_add_function.item_data_analyzer import DataAnalyzer
            stat_result = await DataAnalyzer.data_stat_with_base_llm(self, content, res)
            if stat_result.get('total', 0) > 0:
                res = json.dumps(stat_result, ensure_ascii=False)
                self.logger.info(f'工具结果聚合完成[total={stat_result["total"]}]')
        except Exception as e:
            self.logger.warning(f'工具结果聚合失败，使用原始数据: {e}')

        return call_id, res

    async def chat(
        self,
        prompt: Optional[str],
        tools: List[Tool],
        msg: List[Message],
        role: Role,
        content: Optional[str],
        assistant: str,
        resp_json: bool = False,
        wf_tools: List[LangFlow] = [],
    ) -> List[Message]:
        """非流式聊天（完整回复）。

        对 _take_msg 裁剪后的消息列表调用子类 achat()，
        token 超限时自动丢弃最早的两条消息重试。
        """
        ls = self._take_msg(prompt, tools, role, content, msg, assistant)
        try:
            s = time()
            res = await self.achat(assistant, tools, ls, resp_json, wf_tools)
            return res
        except TokenExceedError as e:
            self.logger.error(e, f'调用大模型token超了,尝试缩小消息范围', stack_info=True, exc_info=True)
            return await self.achat(assistant, tools, [ls[0]] + ls[2:])

    async def stream_chat(
        self,
        prompt: Optional[str],
        tools: List[Tool | ChatCompletionToolParam],
        msg: List[Message],
        role: Role,
        content: Optional[str],
        assistant: str,
        resp_json: bool = False,
        tool_choice: str = 'auto',
        enable_thinking: bool = False,
    ) -> AsyncGenerator[Message, None]:
        """流式聊天（逐 token 产出）。

        tool_choice 不为 'auto' 且只有一个工具时，走强制工具选择路径；
        否则走标准流式路径。token 超限时同 chat() 逻辑。
        """
        if len(tools) == 1 and (tool_choice != 'auto'):
            ls = self._take_msg(prompt, [], role, content, msg, assistant)
            async for res in self.stream_achat_for_choice_tool(assistant, tools[0], ls):
                yield res
        else:
            try:
                ls = self._take_msg(prompt, tools, role, content, msg, assistant)
                async for res in self.stream_achat(assistant, tools, ls, resp_json, enable_thinking):
                    yield res
            except TokenExceedError as e:
                self.logger.error(e, f'调用大模型token超了,尝试缩小消息范围', stack_info=True, exc_info=True)
                yield await self.stream_achat(assistant, tools, [ls[0]] + ls[2:], resp_json, enable_thinking)

    @abstractmethod
    async def achat(self, assistant: str, tools: List[Tool], msg: List[Message], resp_json: bool, wf_tools: List[LangFlow] = []) -> List[Message]:
        """子类实现：非流式对话，返回完整消息列表。"""
        pass

    @abstractmethod
    async def ocr(self, url: str, purpose: str) -> str:
        """子类实现：图片 OCR 识别（部分模型不支持，返回空实现）。"""
        pass

    @abstractmethod
    def _transform_msg(self, msg: Message) -> Optional[ChatCompletionMessageParam]:
        """子类实现：将内部 Message 转为模型 SDK 的消息参数。"""
        pass

    @abstractmethod
    def _parse_tool(self, tool: Tool) -> ChatCompletionToolParam:
        """子类实现：将内部 Tool 转为模型 SDK 的工具定义。"""
        pass

    @abstractmethod
    async def stream_achat(self, assistant: str, tools: List[Tool], msg: List[Message], resp_json: bool, enable_thinking: bool) -> AsyncGenerator[Message, None]:
        """子类实现：流式对话，逐 token yield Message 或 int（token 计数）。"""
        ...

    async def stream_achat_for_choice_tool(self, assistant: str, choice_tool: Tool|ChatCompletionToolParam, msgs: List[Message]) -> AsyncGenerator[Message, None]:
        """强制工具选择：用 tool_choice 锁定指定工具，执行后 yield 工具结果。"""
        if isinstance(choice_tool, Tool):
            choice_tool= self._parse_tool(choice_tool)
        model = AsyncOpenAI(api_key=self.config.key, base_url=self.config.endpoint)
        tool_choice: Any = {"type": "function", "function": {"name": choice_tool['function']['name']}}
        response = await model.chat.completions.create(
            model=self.config.llm_name,
            temperature=self.temperature,
            messages=[m for m in (self._transform_msg(msg) for msg in msgs) if m],
            tools=[choice_tool],
            tool_choice=tool_choice,
            max_tokens=self.config.max_response_token,
            response_format=NOT_GIVEN,
            top_p=0.95,
        )
        tool_call = response.choices[0].message.tool_calls[0]
        tool_name = tool_call.function.name
        tool_func = self.choice_tool_map.get(tool_name)
        args = json.loads(tool_call.function.arguments)
        tool_result = await tool_func(**args)
        yield Message(role='tool', tool_call_id=tool_call.id, content=tool_result or '', assistant=assistant)


    async def search_zsk_knowledge(self, query: str) -> str:
        """根据用户上传的知识库检索内容（强制工具选择时触发）。

        Args:
            query: 用户问题

        Returns:
            默认返回 ''，实际检索需由外部注入（ChannelV2 中通过 build_search_zsk_knowledge_tool 覆盖）。
        """
        self.logger.info(f'知识库query: {query}')
        return ''



    @abstractmethod
    def token_length(self, content: Optional[str]) -> int:
        """计算单条内容的 token 数。"""
        ...

    @abstractmethod
    def tool_token(self, tools: List[Tool]) -> int:
        """计算工具定义的 token 数。"""
        ...

    @abstractmethod
    def tool_call_token_length(self, calls: List[ZxhToolCall]) -> int:
        """计算工具调用结果的 token 数。"""
        ...

    @abstractmethod
    def translate_type(self, data_type: str) -> str:
        """将业务类型名转为 OpenAI function calling 参数类型。"""
        ...

    @abstractmethod
    def keyword_rewrite(self, content: str) -> str:
        """领域关键词改写（如 '猪价' → '生猪价格'），子类可覆盖。"""
        ...

    def _content_token_length(self, content: Any) -> int:
        """多模态 content 先压成纯文本再计算 token 数。"""
        return self.token_length(flatten_user_content_for_token_count(content))

    def _take_msg(
        self,
        prompt: Optional[str],
        tools: List[Tool],
        role: Role,
        content: str,
        msgs: List[Message],
        assistant: str,
    ) -> List[Message]:
        """从历史消息中裁剪出不超过最大 token 限制的消息列表。

        逻辑:
          1. 计算 prompt + tools + 当前 content 占用的 token
          2. 从最新到最旧方向取出历史消息，直到 remain < 0
          3. 反转拼接成 [system(prompt), ...history, current_message]

        为什么从最新开始取：
          多轮对话中最近的上下文对回复质量影响最大。
        """
        if len(msgs) == 0:
            if prompt is None or len(prompt) == 0:
                return [Message(id=str(uuid4()), role=role, content=content, assistant=assistant)]
            return [Message(role='system', content=prompt, assistant=assistant), Message(id=str(uuid4()), role=role, content=content, assistant=assistant)]
        remain = self.config.max_tokens - self.config.max_response_token - (0 if prompt is None else self.token_length(prompt) + self.config.token_per_msg) - (0 if len(tools) == 0 else self.tool_token(tools) + self.config.token_per_msg) - (self._content_token_length(content) + self.config.token_per_msg)
        i = len(msgs) - 1
        r = []
        while remain > 0 and i >= 0:
            m = msgs[i]
            token = self._content_token_length(m.content) if m.role != 'assistant' or m.content is not None else self.tool_call_token_length(m.tool_calls) + (self.config.replay_token if m.role != 'assistant' else self.config.replay_token + self.config.token_per_msg)
            if remain > token:
                r.append(m)
                remain -= token
                i -= 1
            else:
                r.append(m)
                remain -= token
                i -= 1
                self.logger.warning(f'消息内容太长,无法加入到历史记录中,当前消息内容长度为[{token}],当前剩余长度为[{remain}]')
                # break
        res = []
        if prompt is not None:
            res.append(Message(role='system', content=prompt, assistant=assistant))
        if len(r) > 0:
            res += list(reversed(r))
        if content is not None:
            res.append(Message(role=role, content=content, assistant=assistant))
        return res

    def _build_body(self, tool: Tool, args: Mapping[str, Any]) -> Optional[bytes]:
        """根据工具配置构造 HTTP 请求体。

        - GET 方法: 无 body
        - application/json: JSON 编码
        - 其他: URL 编码（只含 location=body 的参数）
        """
        if tool.method == 'GET':
            return None
        elif tool.content_type == 'application/json':
            body = args
            return dumps(body, ensure_ascii=False).encode('utf-8')
        else:
            body = [f'{quote(arg.name)}={quote(args.get(arg.name))}' for arg in ColUtil.where(tool.args, lambda x: x.location == 'body')]
            return '&'.join(body).encode('utf-8')

    def _build_header(self, tool: Tool, args: Mapping[str, Any]) -> Mapping[str, str]:
        """构造 HTTP 请求头：header 参数 + Content-Type + Authorization + 集团 ID。"""
        header = {arg.name: args.get(arg.name) for arg in ColUtil.where(tool.args, lambda x: x.location == 'header')}
        if tool.content_type is not None:
            header['Content-Type'] = tool.content_type
        dataset_token = self.request.user_chats[0].dataset_token
        if dataset_token:
            header['Authorization'] = f'Bearer {dataset_token}'
        header['rs-group-id'] = _pick_arg(args, 'rs_group_id', 'rs-group-id')
        return header

    async def stream_chat_report(
        self,
        prompt: Optional[str],
        tools: List[Tool],
        msg: List[Message],
        role: Role,
        content: Optional[str],
        assistant: str,
        resp_json: bool = False,
    ) -> AsyncGenerator[Message, None]:
        """报告场景的流式聊天，token 超限缩消息窗口后重试。"""
        ls = self._take_msg(prompt, tools, role, content, msg, assistant)
        try:
            async for res in self.stream_achat_report(assistant, tools, ls, resp_json):
                yield res
        except TokenExceedError as e:
            self.logger.error(
                e, f'调用report流式大模型token超了,尝试缩小消息范围', stack_info=True, exc_info=True
            )
            async for res in self.stream_achat_report(assistant, tools, [ls[0]] + ls[2:], resp_json):
                yield res

    @abstractmethod
    async def stream_achat_report(
        self, assistant: str, tools: List[Tool], msg: List[Message], resp_json: bool,
    ) -> AsyncGenerator[Message, None]:
        """子类实现：报告场景流式对话。"""
        ...

    async def invoke_tool_report(
        self,
        call_id: str,
        tool: Tool,
        args: Mapping[str, Any],
        wf_tools: List[LangFlow] = [],
        content: str = '',
        feedback_id: str = '',
        type_: int = 1,
        conversation_id: str = '',
        callback_url: str = '',
    ) -> Tuple[str, str]:
        """执行报告场景的工具调用，payload 包裹为 report_body 结构。"""
        params = {}
        for arg in tool.args:
            if arg.arg_mapping:
                v = args.get(arg.name)
                if v is not None and isinstance(v, str):
                    dic = {}
                    for k, va in arg.arg_mapping.items():
                        for a in k.split(','):
                            dic[a.upper()] = va
                    value = dic.get(v.upper())
                    if value is not None:
                        params[arg.name] = value
                    else:
                        k = self.nlp.similarity(v.upper(), list(dic.keys()))
                        params[arg.name] = dic.get(k) if k is not None else v
                else:
                    params[arg.name] = v
            else:
                params[arg.name] = args.get(arg.name)
        if "pig_farm_id" in params:
            params["pigFarmId"] = params.pop("pig_farm_id")
        url = tool.url
        for arg in ColUtil.where(tool.args, lambda x: x.location == 'path'):
            url = url.replace('{' + arg.name + '}', str(args.get(arg.name) or ''))        
        query = {it.name: args.get(it.name) for it in ColUtil.where(tool.args, lambda x: x.location == 'query')}
        report_body = {
            "feedback_id": feedback_id,
            "type": type_,
            "content": content,
            "conversation_id": conversation_id,
            "input": params,
            "callback_url": callback_url
        }
        try:
            body = json.dumps(report_body, ensure_ascii=False).encode('utf-8')
        except Exception as e:
            self.logger.error(f"report_body 序列化失败: {e}", exc_info=True)
            return call_id, '{"code":-1,"msg":"序列化失败"}'

        headers = self._build_header(tool, params) or {}
        headers['Content-Type'] = 'application/json; charset=utf-8'

        res = await self.http_client.request(
            tool.method,
            url,
            query if query else None,
            body,  
            headers,
            tool.timeout,
            lambda x: x.text()
        )

        self.logger.info(
            f'调用报告工具信息[id:{call_id},tool:{tool.name},args:{format_log_value(params)}]'
        )
        self.logger.info(f'调用报告工具结果[{substr(res or "", 0, 200)}]')

        return call_id, res

