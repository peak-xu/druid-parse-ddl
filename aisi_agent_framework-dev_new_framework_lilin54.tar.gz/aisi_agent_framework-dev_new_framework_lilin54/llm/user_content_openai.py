"""将 user 多模态片段（Pydantic 模型或历史里的 dict）转为 OpenAI SDK 的 content part。"""
from __future__ import annotations

from typing import Any, cast

from openai.types.chat import (
    ChatCompletionContentPartImageParam,
    ChatCompletionContentPartInputAudioParam,
    ChatCompletionContentPartParam,
    ChatCompletionContentPartTextParam,
)
from openai.types.chat.chat_completion_content_part_image_param import ImageURL
from openai.types.chat.chat_completion_content_part_input_audio_param import InputAudio

from entity import ChatAudioContentPart, ChatContentPart, ChatImgContentPart, ChatTextContentPart


def user_content_part_to_openai_param(part: Any) -> ChatCompletionContentPartParam:
    """将用户多模态消息片段转换为 OpenAI SDK 的 ChatCompletionContentPartParam。

    支持三种输入形态：
    - dict（历史反序列化）→ 根据 type 字段路由到 text/image_url/input_audio
    - ChatTextContentPart → text 片段
    - ChatImgContentPart → image_url 片段
    - ChatAudioContentPart → input_audio 片段
    其他类型兜底为 text。

    Args:
        part: 输入片段，可为 Pydantic 模型实例或 dict

    Returns:
        OpenAI SDK 兼容的 content part 对象
    """
    if isinstance(part, dict):
        t = part.get('type')
        if t == 'text':
            return ChatCompletionContentPartTextParam(type='text', text=str(part.get('text', '')))
        if t == 'image_url':
            iu = part.get('image_url')
            if isinstance(iu, str):
                return ChatCompletionContentPartImageParam(type='image_url', image_url=ImageURL(url=iu, detail='auto'))
            if isinstance(iu, dict):
                url = str(iu.get('url', '') or '')
                detail = cast(Any, iu.get('detail', 'auto'))
                if detail not in ('auto', 'low', 'high'):
                    detail = 'auto'
                return ChatCompletionContentPartImageParam(type='image_url', image_url=ImageURL(url=url, detail=detail))
        if t == 'input_audio':
            ia = part.get('input_audio') or {}
            if isinstance(ia, dict):
                return ChatCompletionContentPartInputAudioParam(
                    type='input_audio',
                    input_audio=InputAudio(data=str(ia.get('data', '')), format=cast(Any, ia.get('format', 'wav'))),
                )
        return cast(ChatCompletionContentPartParam, part)
    if isinstance(part, ChatTextContentPart):
        return ChatCompletionContentPartTextParam(type='text', text=part.text)
    if isinstance(part, ChatImgContentPart):
        return ChatCompletionContentPartImageParam(type='image_url', image_url=ImageURL(url=part.url, detail=part.detail))
    if isinstance(part, ChatAudioContentPart):
        return ChatCompletionContentPartInputAudioParam(type='input_audio', input_audio=InputAudio(data=part.data, format=part.format))
    return ChatCompletionContentPartTextParam(type='text', text=str(part))
