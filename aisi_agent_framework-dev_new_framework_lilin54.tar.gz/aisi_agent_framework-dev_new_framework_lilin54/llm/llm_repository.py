from typing import Optional, Dict

from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession
from sqlmodel import select

from models import LlmConfig


class LlmRepository:
    """LLM 配置仓储，首次查询时从 DB 全量加载并缓存。

    支持按名称 (str) 或 id (int) 查询配置。
    """

    def __init__(self, engine: AsyncEngine):
        self.engine = engine
        # 键为模型名称的缓存字典
        self.cache: Dict[str, LlmConfig] = {}

    async def get_config(self, key: str | int) -> Optional[LlmConfig]:
        """按名称或 ID 获取 LLM 配置。

        首次调用时从 llm_config 表全量加载到内存缓存。
        """
        if len(self.cache) == 0:
            async with AsyncSession(self.engine) as session:
                confs = await session.execute(select(LlmConfig))
                for conf in confs:
                    it = conf._data[0]
                    self.cache[it.name] = it
        if isinstance(key, str):
            return self.cache.get(key)
        else:
            for conf in self.cache.values():
                if conf.id == key:
                    return conf
            return None