from asyncio import TaskGroup
from json import loads, dumps
from logging import Logger
from typing import override, List, Optional, Iterable

from openai import AsyncOpenAI, NOT_GIVEN
from openai.types.chat import ChatCompletionMessageParam, ChatCompletionSystemMessageParam, \
    ChatCompletionUserMessageParam, ChatCompletionAssistantMessageParam, ChatCompletionToolMessageParam, \
    ChatCompletionFunctionMessageParam, ChatCompletionMessageToolCallParam, ChatCompletionToolParam, \
    ChatCompletionContentPartParam
from openai.types.chat.chat_completion_message_tool_call_param import Function
from openai.types.shared_params import FunctionDefinition
from tiktoken import get_encoding

from api import LangFlowClient
from entity import Tool, Message, ZxhToolCall, LangFlow, ChatContentPart, ChatRequest
from errors import TokenExceedError
from models import LlmConfig
from nlp import Nlp
from utils import HttpClient, ColUtil
from .base_llm import BaseLLM, flatten_user_content_for_token_count
from .user_content_openai import user_content_part_to_openai_param


class DeepseekReasoner(BaseLLM):
    """
    DeepSeek Reasoner（深度推理）LLM 适配器。

    基于 OpenAI 兼容 API 对接 DeepSeek-Reasoner 模型。特性：
    - 不支持 function calling（achat 无 tools 参数），仅做纯文本推理
    - reasoning_content 思维链输出（用 <think_deeply></think_deeply> 标签包裹）
    - stream_options={\"include_usage\": True} 获取流式 token 用量
    - 多模态用户消息压缩为纯文本（flatten_user_content_for_token_count）
    - tiktoken 精确 token 计数
    """
    def __init__(self, config: LlmConfig, temperature: int | float, http_client: HttpClient, langflow_client: LangFlowClient, nlp: Nlp, logger: Logger, request: ChatRequest):
        super().__init__(config, temperature, http_client, langflow_client, nlp, logger, request)
        self.model = AsyncOpenAI(api_key=config.key, base_url=config.endpoint)
        self.encoding = get_encoding(config.encoding_name)
        self.data_type_mapping = {'string': 'string', 'text': 'string', 'char': 'string', 'date': 'string', 'int': 'number', 'integer': 'number', 'long': 'number', 'float': 'number', 'dict': 'object', 'list': 'array', 'bool': 'boolean', 'none': 'null'}

    @override
    async def achat(self, assistant: str, tools: List[Tool], msg: List[Message], resp_json: bool, wf_tools: List[LangFlow] = []) -> List[Message]:
        try:
            content = msg[-1].content
            resp = await self.model.chat.completions.create(model=self.config.llm_name, temperature=self.temperature, messages=[m for m in (self._transform_msg(it) for it in msg) if m is not None], max_tokens=self.config.max_response_token,
                                                            response_format={'type': 'json_object'} if resp_json else NOT_GIVEN)
            res = []
            for choice in resp.choices:
                if choice.finish_reason == 'length':
                    raise TokenExceedError()
                elif choice.finish_reason == 'tool_calls':
                    res.append(Message(id=resp.id, role=choice.message.role, content=None, tool_calls=[ZxhToolCall(id=it.id, name=it.function.name, arguments=it.function.arguments) for it in choice.message.tool_calls], assistant=assistant))
                    calls = []
                    for call in choice.message.tool_calls:
                        tool = ColUtil.single(tools, lambda x: x.name == call.function.name)
                        if tool is not None:
                            calls.append((call, tool))
                    if len(calls) == 1:
                        call, tool = calls[0]
                        r = await self.invoke_tool(call.id, tool, loads(call.function.arguments), wf_tools, content)
                        res.append(Message(id=resp.id, role='tool', tool_call_id=r[0], content=r[1], assistant=assistant))
                    elif len(calls) > 1:
                        tasks = []
                        async with TaskGroup() as g:
                            for call, tool in calls:
                                tasks.append(g.create_task(self.invoke_tool(call.id, tool, loads(call.function.arguments), wf_tools, content)))
                        for it in tasks:
                            r = it.result()
                            res.append(Message(id=resp.id, tool_call_id=r[0], role='tool', content=r[1], assistant=assistant))
                elif choice.finish_reason == 'function_call':
                    fc = choice.message.function_call
                    tool = ColUtil.single(tools, lambda x: x.name == fc.name)
                    if tool is not None:
                        r = await self.invoke_tool(fc.name, tool, loads(fc.arguments), wf_tools, content)
                        res.append(Message(id=resp.id, role='function', function_name=r[0], content=r[1], assistant=assistant))
                else:
                    reasoning_content = ''
                    if hasattr(choice.message, 'reasoning_content'):
                        reasoning_content = choice.message.reasoning_content
                    res.append(Message(id=resp.id, role=choice.message.role, content=choice.message.content, reasoning_content=reasoning_content, assistant=assistant))
            return res
        except Exception as e:
            self.logger.error(f'调用deepseek异常[assistant:{assistant},msg:{dumps([it.model_dump() for it in msg], ensure_ascii=False)}]', stack_info=True, exc_info=e)
            return []

    @override
    async def stream_achat(self, assistant: str, tools: List[Tool], msg: List[Message], resp_json: bool, enable_thinking: bool = False):
        try:
            response = await self.model.chat.completions.create(model=self.config.llm_name, temperature=self.temperature, messages=[m for m in (self._transform_msg(it) for it in msg) if m is not None], max_tokens=self.config.max_response_token,
                                                                response_format={"type": "json_object"} if resp_json else NOT_GIVEN, top_p=0.95, stream=True, stream_options={"include_usage": True})
            think_added = False
            async for chunk in response:
                if (len(chunk.choices) == 0 or chunk.choices[0].finish_reason == "stop") and chunk.usage is not None:
                    yield chunk.usage.total_tokens
                    continue
                delta = chunk.choices[0].delta
                if hasattr(delta, 'reasoning_content') and delta.reasoning_content:
                    if not think_added:
                        ans = f"\n\n<think_deeply>\n\n{delta.reasoning_content}"
                        think_added = True
                    else:
                        ans = delta.reasoning_content
                elif hasattr(delta, 'content') and delta.content:
                    if think_added:
                        ans = f"\n</think_deeply>{delta.content}"
                        think_added = False
                    else:
                        ans = delta.content
                else:
                    continue
                if not ans:
                    continue
                yield Message(id=chunk.id, role=delta.role, content=ans, assistant=assistant)
        except Exception as e:
            self.logger.error(f'调用deepseek reasoner异常[assistant:{assistant},msg:{dumps([it.model_dump() for it in msg], ensure_ascii=False)}]', stack_info=True, exc_info=e)

    @override
    def token_length(self, content: Optional[str]) -> int:
        flat = flatten_user_content_for_token_count(content)
        if not flat:
            return 0
        return len(self.encoding.encode(flat))

    @override
    def tool_token(self, tools: List[Tool]) -> int:
        if len(tools) == 0:
            return 0
        llm_tools = [self._parse_tool(tool) for tool in tools]
        return len(self.encoding.encode(dumps(llm_tools, ensure_ascii=False)))

    @override
    def tool_call_token_length(self, calls: List[ZxhToolCall]) -> int:
        tcs = [ChatCompletionMessageToolCallParam(id=it.id, function=Function(name=it.name, arguments=it.arguments), type='function') for it in calls]
        return self.token_length(dumps(tcs, ensure_ascii=False))

    @override
    def translate_type(self, data_type: str) -> str:
        nt = self.data_type_mapping.get(data_type.lower())
        if nt is not None:
            return nt
        return data_type

    @override
    def keyword_rewrite(self, content: str) -> str:
        return content

    @override
    async def ocr(self, url: str, purpose: str) -> str:
        pass

    def _transform_msg(self, msg: Message) -> Optional[ChatCompletionMessageParam]:
        if msg.role == 'system':
            return ChatCompletionSystemMessageParam(role='system', content=msg.content)
        elif msg.role == 'user':
            if msg.content is None:
                return None
            elif isinstance(msg.content, str):
                return ChatCompletionUserMessageParam(role='user', content=msg.content)
            elif isinstance(msg.content, Iterable):
                return ChatCompletionUserMessageParam(role='user', content=flatten_user_content_for_token_count(msg.content))
            else:
                return None
        elif msg.role == 'assistant':
            return ChatCompletionAssistantMessageParam(role='assistant', content=msg.content, tool_calls=[] if msg.tool_calls is None else [ChatCompletionMessageToolCallParam(id=it.id, function=Function(name=it.name, arguments=it.arguments), type='function') for it in msg.tool_calls])
        elif msg.role == 'tool':
            return ChatCompletionToolMessageParam(role='tool', content=msg.content, tool_call_id=msg.tool_call_id)
        else:
            return ChatCompletionFunctionMessageParam(role='function', name=msg.function_name, content=msg.content)

    def _parse_tool(self, tool: Tool) -> ChatCompletionToolParam:
        props = {arg.name: {'type': self.translate_type(arg.arg_type), 'description': arg.description} for arg in tool.args}
        required = ColUtil.map(ColUtil.where(tool.args, lambda x: x.required), lambda x: x.name)
        return ChatCompletionToolParam(type='function', function=FunctionDefinition(name=tool.name, description=tool.description, parameters={'type': 'object', 'properties': props, 'required': required, 'additionalProperties': False}))

    def _parse_user_msg(self, msg: ChatContentPart) -> ChatCompletionContentPartParam:
        return user_content_part_to_openai_param(msg)

    @override
    async def stream_achat_report(self, assistant: str, tools, msg, resp_json):
        async for it in self.stream_achat(assistant, tools, msg, resp_json):
            yield it