from abc import ABC, abstractmethod
from typing import Optional

from models import ChatMsg, ChatLog


class MessageStore(ABC):
    """消息存储抽象基类。

    定义会话消息和日志的持久化契约：
    - load_chat(): 按会话 ID 加载历史消息
    - save_chat(): 保存/更新会话消息
    - add_chat_log(): 记录每次调用的详细日志
    """

    @abstractmethod
    async def load_chat(self, id: str) -> Optional[ChatMsg]:
        pass

    @abstractmethod
    async def save_chat(self, chat: ChatMsg) -> None:
        pass

    @abstractmethod
    async def add_chat_log(self, log: ChatLog) -> None:
        pass