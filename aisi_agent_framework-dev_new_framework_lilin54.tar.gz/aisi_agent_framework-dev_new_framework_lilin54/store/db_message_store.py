from logging import Logger
from typing import override, Optional

from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession
from sqlmodel import select

from models import ChatMsg, ChatLog
from .message_store import MessageStore


class DbMessageStore(MessageStore):
    """数据库消息存储实现，基于 SQLModel + SQLAlchemy AsyncEngine。

    使用 session.merge() 进行 upsert（load_chat 用 get）。
    错误时打印日志但不抛异常，保证主流程不中断。
    """

    def __init__(self, engine: AsyncEngine, logger: Logger):
        self.engine = engine
        self.logger = logger

    @override
    async def load_chat(self, id: str) -> Optional[ChatMsg]:
        async with AsyncSession(self.engine) as session:
            return await session.get(ChatMsg, id)

    @override
    async def save_chat(self, chat: ChatMsg) -> None:
        try:
            async with AsyncSession(self.engine) as session:
                await session.merge(chat)
                await session.commit()
        except Exception as e:
            self.logger.error('保存会话失败', exc_info=e, stack_info=True)

    @override
    async def add_chat_log(self, log: ChatLog) -> None:
        try:
            async with AsyncSession(self.engine) as session:
                await session.merge(log)
                await session.commit()
        except Exception as e:
            self.logger.error('保存会话日志失败', exc_info=e, stack_info=True)