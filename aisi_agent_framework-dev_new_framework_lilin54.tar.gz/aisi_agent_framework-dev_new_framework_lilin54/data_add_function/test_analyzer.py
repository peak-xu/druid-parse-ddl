"""
测试脚本 — DataAnalyzer.data_stat

测试用例：
  query     = "按照死亡原因进行查询我猪场26年1-5月份肥猪死亡情况"
  data_list = item_data3.json 内容

运行方式（在项目根目录下）：
  python -m data_add_function.test_analyzer
或直接：
  python data_add_function/test_analyzer.py
"""

import ast
import asyncio
import json
import logging
import os
import sys
from datetime import datetime
from idlelib import query

# ── 路径修正：确保项目根目录在 sys.path 中 ────────────────────────────────
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from dotenv import load_dotenv
load_dotenv(os.path.join(_ROOT, '.env.dev'))

from entity import ChatRequest
from entity.chat_request import AgentData, Chat
from entity.env import Env
from llm import LlmFactory
from models import LlmConfig
from utils import HttpClient
from api import LangFlowClient
from nlp import RapidfuzzNlp
from data_add_function.item_data_analyzer import DataAnalyzer

# ── 日志配置 ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
)
logger = logging.getLogger(__name__)


def _build_llm_config() -> LlmConfig:
    """从环境变量构造 LlmConfig（不依赖数据库）。

    默认使用内网 qwen35-122b 服务（OpenAI-compatible，type=3/Qwen）。
    可通过 TEST_LLM_* 环境变量覆盖。
    type 映射：1=Azure ChatGPT, 3=Qwen, 5=DeepSeek（参见 LlmFactory）
    """
    return LlmConfig(
        id=0,
        type=int(os.getenv('TEST_LLM_TYPE', '3')),
        name=os.getenv('TEST_LLM_NAME', 'qwen35-122b'),
        endpoint=os.getenv('TEST_LLM_ENDPOINT', 'http://10.212.70.23:8080/v1'),
        key=os.getenv('TEST_LLM_KEY', '5fb548e7-bc8e-4f62-873e-29a48b8d1320'),
        llm_name=os.getenv('TEST_LLM_MODEL', 'qwen35-122b-a10b'),
        llm_version=os.getenv('TEST_LLM_VERSION', ''),
        encoding_name=os.getenv('TEST_LLM_ENCODING', 'cl100k_base'),
        max_tokens=int(os.getenv('TEST_LLM_MAX_TOKENS', '8192')),
        max_response_token=int(os.getenv('TEST_LLM_MAX_RESP', '4096')),
        token_per_msg=4,
        replay_token=3,
        create_time=datetime.now(),
        update_time=datetime.now(),
    )


def _build_mock_request() -> ChatRequest:
    """构造最小化的 ChatRequest，满足 BaseLLM 初始化需求。"""
    return ChatRequest(
        conversation_id=None,
        callback_api='',
        streaming_callback_api='',
        agent_data=AgentData(
            role_name='测试角色',
            role_settings='',
            model_name='azure',
            temperature='0.1',
        ),
        env=Env(userId=0, enterpriseId=0, groupId=0),
        knowledge_base=[],
        user_chats=[Chat(role='user', content='test')],
    )


def _load_data3() -> list[dict]:
    """加载 item_data3.json（Python 单引号格式，用 ast.literal_eval 解析）。"""
    path = os.path.join(os.path.dirname(__file__), 'item_data3.json')
    with open(path, 'r', encoding='utf-8') as f:
        raw = f.read()
    return ast.literal_eval(raw)

def _load_data(data_file_name) -> list[dict]:
    """加载 item_data3.json（Python 单引号格式，用 ast.literal_eval 解析）。"""
    path = os.path.join(os.path.dirname(__file__), data_file_name)
    with open(path, 'r', encoding='utf-8') as f:
        raw = f.read()
    return ast.literal_eval(raw)


async def main():
    # ── 1. 加载数据 ────────────────────────────────────────────────────────
    data_file = 'item_data1.json'
    logger.info(f'加载 {data_file} ...')
    data_list = _load_data(data_file)
    # data_list = _load_data3()
    logger.info(f'共加载 {len(data_list)} 条记录，字段：{list(data_list[0].keys())}')

    # ── 2. 构建 LLM ────────────────────────────────────────────────────────
    cfg = _build_llm_config()
    if not cfg.endpoint:
        logger.error('未检测到 LLM endpoint，请设置环境变量 TEST_LLM_ENDPOINT')
        return

    http_client = HttpClient(timeout=60.0, logger=logger)
    langflow_host = os.getenv('langflow.host', 'http://localhost:7860')
    langflow_client = LangFlowClient(host=langflow_host, http_client=http_client, logger=logger)
    nlp = RapidfuzzNlp()
    request = _build_mock_request()

    model = LlmFactory.create(cfg, 0.1, http_client, langflow_client, nlp, logger, request)
    logger.info(f'LLM 实例化成功：{cfg.name} / {cfg.llm_name}')

    # ── 3. 执行分析 ────────────────────────────────────────────────────────
    # query = "按照死亡原因进行查询我猪场26年1-5月份肥猪死亡情况"
    query = "按照单位统计26年1-5月的项目收入情况"
    # query = "根据事业部查看一下26年5月市场服务中心各部门的净收益"
    # query = "看一下26年5月市场服务中心的净收益"
    logger.info(f'执行查询：{query}')

    result = await DataAnalyzer.data_stat(model, query, data_list)

    # ── 4. 打印结果 ────────────────────────────────────────────────────────
    print('\n' + '=' * 70)
    print('  DataAnalyzer.data_stat 测试结果')
    print('=' * 70)

    if 'error' in result:
        print(f'\n  [ERROR] {result["error"]}')
        print(f'  LLM 原始回复：{result.get("raw", "")}')
        return

    intent = result['intent']
    print(f'\n  识别到的意图：')
    print(f'    dim_list  : {intent.get("dim_list", [])}')
    print(f'    ind_list  : {intent.get("ind_list", [])}')
    print(f'    agg_func  : {intent.get("agg_func", "")}')
    print(f'    过滤条件  : {json.dumps(intent.get("filter_conditions", []), ensure_ascii=False)}')
    print(f'    日期粒度  : {intent.get("date_dim_granularity", "day")}')
    print(f'\n  聚合结果共 {result["total"]} 行：')
    print('-' * 70)

    rows = result['rows']
    if rows:
        # 打印表头
        headers = list(rows[0].keys())
        col_w = max(len(str(h)) for h in headers) + 2
        header_line = '  ' + ''.join(str(h).ljust(col_w) for h in headers)
        print(header_line)
        print('  ' + '-' * (col_w * len(headers)))
        for row in rows:
            line = '  ' + ''.join(str(row.get(h, '')).ljust(col_w) for h in headers)
            print(line)

    print('=' * 70 + '\n')




if __name__ == '__main__':
    asyncio.run(main())
