"""
ItemDataAnalyzer — 数据明细聚合分析器

核心思路：
  1. LLM 只负责"意图识别"：从字段列表中识别 dim_list / ind_list / filter_conditions
  2. 聚合计算由固定 Python 代码执行，避免 LLM 直接操作数值带来的幻觉/计算错误
  3. Prompt 与代码解耦，统一放在 prompts/data_stat_prompt.md

入口（静态方法，无需实例化）：
  result = await DataAnalyzer.data_stat(model, query, data_list)
"""

import json
import os
import re
from collections import defaultdict
from typing import Any, Optional

from llm import BaseLLM


# prompt 模板文件路径（相对本文件）
_PROMPT_FILE = os.path.join(os.path.dirname(__file__), 'prompts', 'data_stat_prompt.md')


def _load_prompt(field_samples: list[dict], query: str) -> str:
    """读取 prompt 模板并填充变量。"""
    with open(_PROMPT_FILE, 'r', encoding='utf-8') as f:
        tmpl = f.read()
    tmpl = tmpl.replace('{{ fields }}', json.dumps(field_samples, ensure_ascii=False))
    tmpl = tmpl.replace('{{ query }}', query)
    return tmpl


def _extract_fields(data_list: list[dict]) -> list[str]:
    """从数据列表第一行提取所有字段名。"""
    if not data_list:
        return []
    return list(data_list[0].keys())


def _extract_field_samples(data_list: list[dict], sample_rows: int = 5) -> list[dict]:
    """提取每个字段的名称及前 sample_rows 行中不重复的样本值（最多3个）。

    返回格式：
        [{"field": "平台", "samples": ["市场服务中心", "华东区"]}, ...]

    样本值仅取非空、非纯数值字段的去重值，数值型字段仅标注类型说明，避免 prompt 过长。
    """
    if not data_list:
        return []

    fields = list(data_list[0].keys())
    sample_pool = data_list[:max(sample_rows, 20)]  # 多取几行保证去重后有足够样本
    result = []
    for f in fields:
        vals = [row.get(f) for row in sample_pool if row.get(f) is not None]
        # 判断该字段是否为纯数值型
        numeric_count = sum(1 for v in vals if isinstance(v, (int, float)))
        if vals and numeric_count == len(vals):
            # 数值字段：不附样本，标注为数值型
            result.append({"field": f, "type": "numeric"})
        else:
            # 非数值字段：取去重后前3个样本
            seen: list = []
            for v in vals:
                sv = str(v)
                if sv not in seen:
                    seen.append(sv)
                if len(seen) >= 3:
                    break
            result.append({"field": f, "samples": seen})
    return result


def _parse_llm_json(raw: str) -> dict:
    """从 LLM 回复中提取 JSON，兼容有 markdown 代码块包裹的情况。"""
    raw = raw.strip()
    # 去掉 ```json ... ``` 包裹
    match = re.search(r'```(?:json)?\s*([\s\S]*?)```', raw)
    if match:
        raw = match.group(1).strip()
    return json.loads(raw)


def _apply_filter(row: dict, conditions: list[dict]) -> bool:
    """对单行数据应用过滤条件，全部满足返回 True。"""
    for cond in conditions:
        field = cond.get('field')
        op = cond.get('op', 'eq')
        value = cond.get('value')

        if field not in row:
            continue

        cell = row[field]
        cell_str = str(cell) if cell is not None else ''

        if op == 'eq':
            if str(cell) != str(value):
                return False
        elif op == 'ne':
            if str(cell) == str(value):
                return False
        elif op == 'contains':
            if str(value).lower() not in cell_str.lower():
                return False
        elif op == 'in':
            if str(cell) not in [str(v) for v in (value or [])]:
                return False
        elif op == 'gte':
            try:
                if float(str(cell)) < float(str(value)):
                    return False
            except (ValueError, TypeError):
                if cell_str < str(value):
                    return False
        elif op == 'lte':
            try:
                if float(str(cell)) > float(str(value)):
                    return False
            except (ValueError, TypeError):
                if cell_str > str(value):
                    return False
        elif op == 'between':
            if not isinstance(value, (list, tuple)) or len(value) < 2:
                continue
            low, high = str(value[0]), str(value[1])
            # 支持日期前缀比较：若 cell 比 boundary 长，则截断 cell 再比
            # 例如 cell="2026-01-05", low="2026-01", high="2026-05"
            # → 截为 "2026-01" >= "2026-01" 且 "2026-05" <= "2026-05"
            cell_low = cell_str[:len(low)] if len(cell_str) > len(low) else cell_str
            cell_high = cell_str[:len(high)] if len(cell_str) > len(high) else cell_str
            if not (cell_low >= low and cell_high <= high):
                return False
    return True


def _truncate_date(value: str, granularity: str) -> str:
    """按粒度截断日期字符串。
    granularity: 'year' -> 前4位, 'month' -> 前7位, 'day' -> 原值
    """
    s = str(value)
    if granularity == 'year':
        return s[:4]
    elif granularity == 'month':
        return s[:7]
    return s


def _aggregate(
    data_list: list[dict],
    dim_list: list[str],
    ind_list: list[str],
    filter_conditions: list[dict],
    agg_func: str,
    date_dim_granularity: str = 'day',
    date_fields: Optional[set] = None,
) -> list[dict]:
    """
    固定聚合模板：
      1. 按 filter_conditions 过滤行
      2. 按 dim_list 分组（日期字段按 date_dim_granularity 截断后分组）
      3. 对 ind_list 中每个字段执行 agg_func 聚合

    Args:
        date_fields: 需要按粒度截断的日期字段名集合，None 时自动推断（字段名含"日期"/"date"/"time"）
    """
    # 推断日期字段
    if date_fields is None:
        date_fields = {
            d for d in dim_list
            if any(kw in d.lower() for kw in ('日期', 'date', 'time', '时间', '月份', '年份'))
        }

    def _dim_val(row: dict, dim: str) -> str:
        v = str(row.get(dim, ''))
        if dim in date_fields and date_dim_granularity != 'day':
            v = _truncate_date(v, date_dim_granularity)
        return v

    # Step 1: 过滤
    filtered = [row for row in data_list if _apply_filter(row, filter_conditions)]

    # Step 2: 分组
    groups: dict[tuple, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for row in filtered:
        key = tuple(_dim_val(row, d) for d in dim_list)
        for ind in ind_list:
            val = row.get(ind)
            try:
                groups[key][ind].append(float(val))
            except (TypeError, ValueError):
                pass  # 非数值跳过

    # Step 3: 聚合
    agg_map = {
        'sum': lambda vals: round(sum(vals), 4),
        'count': lambda vals: len(vals),
        'mean': lambda vals: round(sum(vals) / len(vals), 4) if vals else 0,
        'max': lambda vals: max(vals) if vals else None,
        'min': lambda vals: min(vals) if vals else None,
    }
    agg_fn = agg_map.get(agg_func, agg_map['sum'])

    result = []
    for key, ind_vals in groups.items():
        row_out: dict[str, Any] = {}
        for i, dim in enumerate(dim_list):
            row_out[dim] = key[i]
        for ind in ind_list:
            vals = ind_vals.get(ind, [])
            row_out[ind] = agg_fn(vals) if vals else None
        result.append(row_out)

    # 按维度字段排序，结果更易读
    if dim_list:
        result.sort(key=lambda r: tuple(str(r.get(d, '')) for d in dim_list))

    return result


def _parse_data_list(raw: Any) -> list[dict]:
    """将工具/datahub 返回的原始数据转换为 list[dict]。

    支持以下格式：
      - 已经是 list[dict]：直接返回
      - JSON 字符串：解析后取 list 部分（兼容 {"data": [...]} / {"rows": [...]} / 直接 [...]）
      - 其他：返回空列表
    """
    if isinstance(raw, list):
        return [r for r in raw if isinstance(r, dict)]

    if isinstance(raw, str):
        raw = raw.strip()
        if not raw:
            return []
        try:
            parsed = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return []
        if isinstance(parsed, list):
            return [r for r in parsed if isinstance(r, dict)]
        if isinstance(parsed, dict):
            # 常见包装格式：{"data": [...]} / {"rows": [...]} / {"list": [...]} / {"result": [...]}
            for key in ('data', 'rows', 'list', 'result', 'items', 'records'):
                val = parsed.get(key)
                if isinstance(val, list):
                    return [r for r in val if isinstance(r, dict)]
        return []

    return []


class DataAnalyzer:
    """数据明细聚合分析器（所有方法均为静态方法，无需实例化）。

    使用方式::

        result = await DataAnalyzer.data_stat(model, query, data_list)
        result = await DataAnalyzer.data_stat_with_base_llm(base_llm, query, raw_data)
    """

    @staticmethod
    async def data_stat_with_base_llm(base_llm: 'BaseLLM', query: str, raw_data: Any) -> dict:
        """接受 BaseLLM 实例和原始数据（JSON 字符串或 list[dict]），完成解析后调用 data_stat。

        Args:
            base_llm:   BaseLLM 实例，直接用其 chat 方法调用 LLM
            query:      用户自然语言查询
            raw_data:   工具/datahub 返回的原始数据，支持 JSON 字符串或 list[dict]

        Returns:
            同 data_stat 的返回格式
        """
        data_list = _parse_data_list(raw_data)
        return await DataAnalyzer.data_stat(base_llm, query, data_list)

    @staticmethod
    async def data_stat(model: 'BaseLLM', query: str, data_list: list[dict]) -> dict:
        """
        对 data_list 按 query 意图进行聚合统计。

        流程：
          1. LLM 意图识别：识别 dim_list / ind_list / filter_conditions
          2. 字段合法性校验
          3. 固定模板聚合

        Args:
            model:      已实例化的 LLM 对象
            query:      用户自然语言查询
            data_list:  数据明细列表，每个元素是一行数据的字典

        Returns:
            {
                "intent": { ... },
                "total":  结果行数,
                "rows":   结果列表
            }
        """
        if not data_list:
            return {"intent": {}, "total": 0, "rows": []}

        # Step 1: 提取字段名及样本值，构造 prompt
        fields = _extract_fields(data_list)
        field_samples = _extract_field_samples(data_list)
        prompt = _load_prompt(field_samples, query)

        # Step 2: 调用 LLM 识别意图（dim_list / ind_list / filter_conditions）
        res = await model.chat(prompt, [], [], 'user', query, 'channel', False)
        content = res[0].content if res else ''
        raw_reply = content.strip() if isinstance(content, str) else ''

        # Step 3: 解析 LLM JSON 输出
        try:
            intent = _parse_llm_json(raw_reply)
        except (json.JSONDecodeError, ValueError) as e:
            return {
                "error": f"LLM 返回内容解析失败: {e}",
                "raw": raw_reply,
                "intent": {},
                "total": 0,
                "rows": [],
            }

        dim_list: list[str] = intent.get('dim_list', [])
        ind_list: list[str] = intent.get('ind_list', [])
        filter_conditions: list[dict] = intent.get('filter_conditions', [])
        agg_func: str = intent.get('agg_func', 'sum')
        date_dim_granularity: str = intent.get('date_dim_granularity', 'day')

        # Step 4: 字段合法性校验（只保留实际存在的字段，防止 LLM 幻觉）
        valid_fields = set(fields)
        dim_list = [d for d in dim_list if d in valid_fields]
        ind_list = [i for i in ind_list if i in valid_fields]
        filter_conditions = [c for c in filter_conditions if c.get('field') in valid_fields]

        # Step 5: 固定模板聚合
        rows = _aggregate(
            data_list, dim_list, ind_list, filter_conditions, agg_func,
            date_dim_granularity=date_dim_granularity,
        )

        return {
            "intent": {
                "dim_list": dim_list,
                "ind_list": ind_list,
                "filter_conditions": filter_conditions,
                "agg_func": agg_func,
                "date_dim_granularity": date_dim_granularity,
            },
            "total": len(rows),
            "rows": rows,
        }
