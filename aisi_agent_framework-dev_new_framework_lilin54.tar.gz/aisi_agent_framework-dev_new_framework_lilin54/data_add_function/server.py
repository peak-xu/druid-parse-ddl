"""
MCP Server - 数值求和工具

自动解析 ********* data item ********* 包裹区域内的 Markdown 表格，
智能识别数值列并对每个数值列分别精确求和。
"""

import json
import re

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("sum-tool")

# ── 标记识别 ────────────────────────────────────────────────────────────
DATA_ITEM_MARKER = re.compile(
    r"\*{9}\s*data\s*item\s*\*{9}", re.DOTALL | re.IGNORECASE
)

# ── 业务指标列关键字（命中 → 数值列） ──────────────────────────────────
METRIC_KEYWORDS = [
    "收入", "成本", "净收入", "金额", "费用", "利润", "支出",
    "税后", "税前", "劳务", "营收", "毛利", "净利",
    "销售额", "回款", "欠款", "余额", "总计", "合计", "小计",
]

# ── 非业务列关键字（命中 → 文本列，跳过） ──────────────────────────────
NON_METRIC_KEYWORDS = [
    "事业部", "部门", "名称", "日期", "编号", "序号",
    "月份", "时间", "机构", "单位", "公司",
]

# ── 数字解析 ────────────────────────────────────────────────────────────
_CLEAN_TABLE = str.maketrans("", "", ",， \u3000")


def _try_parse_number(raw: str) -> float | None:
    """尝试将字符串解析为 float；失败返回 None。"""
    s = raw.strip()
    if not s:
        return None
    cleaned = s.translate(_CLEAN_TABLE).lstrip("+")
    try:
        return float(cleaned)
    except ValueError:
        return None


def _classify_header(header: str) -> bool | None:
    """根据列头关键字判断列类型：True=数值列, False=文本列, None=待定。"""
    for kw in NON_METRIC_KEYWORDS:
        if kw in header:
            return False
    for kw in METRIC_KEYWORDS:
        if kw in header:
            return True
    return None


# ── 表格解析 ────────────────────────────────────────────────────────────


def _parse_table(block: str) -> dict | None:
    """从文本块中解析 Markdown 表格，返回 { 列名: 列数据 }。"""
    lines = block.strip().split("\n")

    # 提取表格行（以 | 开头并以 | 结尾）
    table_lines = [
        ln.strip() for ln in lines
        if ln.strip().startswith("|") and ln.strip().endswith("|")
    ]
    if len(table_lines) < 2:
        return None

    # 表头
    headers = [h.strip() for h in table_lines[0].split("|")[1:-1]]
    if not headers:
        return None

    # 数据行（跳过 |---|---| 分隔行）
    data_rows: list[list[str]] = []
    for ln in table_lines[1:]:
        cells = [c.strip() for c in ln.split("|")[1:-1]]
        if all(
            c.replace("-", "").replace(":", "").strip() == "" for c in cells
        ):
            continue  # 分隔行
        data_rows.append(cells)

    if not data_rows:
        return None

    # 构建列数据
    columns: dict = {}
    for col_idx, header in enumerate(headers):
        raw_values = [row[col_idx] for row in data_rows if col_idx < len(row)]
        if not raw_values:
            continue

        # 分类：数值 or 文本
        hint = _classify_header(header)
        numeric_parsed: list[float] = []
        for v in raw_values:
            num = _try_parse_number(v)
            if num is not None:
                numeric_parsed.append(num)

        non_empty = sum(1 for v in raw_values if v)
        ratio = len(numeric_parsed) / non_empty if non_empty else 0

        if hint is False:
            columns[header] = {"type": "text", "values": raw_values}
        elif hint is True or ratio >= 0.8:
            total = sum(numeric_parsed)
            columns[header] = {
                "type": "numeric",
                "values": [f"{n:,.2f}" for n in numeric_parsed],
                "total": round(total, 2),
                "total_formatted": f"{total:,.2f}",
                "count": len(numeric_parsed),
            }
        else:
            columns[header] = {"type": "text", "values": raw_values}

    return columns


# ── 数据块提取 ──────────────────────────────────────────────────────────


def _extract_data_blocks(text: str) -> list[str]:
    parts = DATA_ITEM_MARKER.split(text)
    # 奇数索引（1,3,5...）是两个标记之间的内容
    blocks = []
    for i in range(1, len(parts), 2):
        block = parts[i].strip()
        if block:
            blocks.append(block)
    return blocks


# ── Tool 定义 ───────────────────────────────────────────────────────────


@mcp.tool()
def sum_numbers(text: str) -> str:
    """对 ********* data item ********* 包裹区域内的 Markdown 表格数值列求和。

    工作方式（全自动，无需 LLM 手动标记）：
        1. 提取所有 data item 块之间的内容。
        2. 解析其中的 Markdown 表格。
        3. 智能识别数值列：列头含业务关键字（收入/成本/金额/利润等），
           或数值占比 ≥80% → 视为数值列。
        4. 自动跳过名称、序号、日期等非业务列。
        5. 对每个数值列分别求和。

    返回 JSON：
        {
            "columns": {
                "税后净收入（元）": {
                    "type": "numeric",
                    "values": ["87,772.63", ...],           // 格式化数字列表
                    "total": 1323606.03,                     // 精确总和
                    "total_formatted": "1,323,606.03",       // 格式化总和
                    "count": 16                              // 有效数值个数
                },
                ...
            },
            "skipped_columns": ["事业部"],                      // 被跳过的文本列
            "block_count": 1                                    // 处理的 data item 块数
        }
    """
    blocks = _extract_data_blocks(text)
    if not blocks:
        return json.dumps(
            {
                "error": "未找到 ********* data item ********* 包裹的内容。",
                "columns": {},
                "skipped_columns": [],
                "block_count": 0,
            },
            ensure_ascii=False,
        )

    # 解析所有块中的表格
    merged_columns: dict = {}
    for block in blocks:
        table = _parse_table(block)
        if not table:
            continue
        for col_name, col_data in table.items():
            if col_name not in merged_columns:
                merged_columns[col_name] = col_data
            elif col_data["type"] == "numeric":
                # 同名列合并：扩展 values 并重算
                existing = merged_columns[col_name]
                if existing["type"] == "numeric":
                    combined = []
                    for v in existing["values"] + col_data["values"]:
                        n = _try_parse_number(v)
                        if n is not None:
                            combined.append(n)
                    total = sum(combined)
                    existing["values"] = [f"{n:,.2f}" for n in combined]
                    existing["total"] = round(total, 2)
                    existing["total_formatted"] = f"{total:,.2f}"
                    existing["count"] = len(combined)

    # 分类输出
    numeric_cols = {}
    skipped = []
    for name, data in merged_columns.items():
        if data["type"] == "numeric":
            numeric_cols[name] = data
        else:
            skipped.append(name)

    result = {
        "columns": numeric_cols,
        "skipped_columns": skipped,
        "block_count": len(blocks),
    }
    return json.dumps(result, ensure_ascii=False)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
