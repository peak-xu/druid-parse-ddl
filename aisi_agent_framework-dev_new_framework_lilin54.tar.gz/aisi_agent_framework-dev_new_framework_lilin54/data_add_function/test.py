"""
测试脚本 —— 验证 sum_numbers 多列分别求和能力。

新逻辑：
    1. 只处理 ********* data item ********* 包裹的内容
    2. 自动识别数值列并分别求和
    3. 跳过名称列等非业务数据
"""

import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from server import sum_numbers


def test_with_original_data():
    """用三列表格数据测试。"""

    # 模拟 LLM 输入：表格用 data item 包裹，无需 [S:...] 标记
    test_text = """
好的，用户想查询2026年5月市场服务中心的净收入，我得仔细看看这些数据。

下面是 Markdown 表格版本：
********* data item *********

| 事业部 | 税后净收入（元） | 税前收入（元） | 劳务成本收入（元）|
|---|---|---|---|
| 东北事业部 | 87,772.63 | 119,145.58 | 16,062.50 |
| 云贵事业部 | 56,289.79 | 73,838.74 | 15,106.86 |
| 华北事业部 | 225,637.79 | 304,987.83 | 42,968.80 |
| 山东事业部 | 169,035.12 | 222,618.54 | 34,861.22 |
| 川渝事业部 | 84,205.85 | 109,486.76 | 17,166.25 |
| 广东事业部 | 123,083.97 | 165,471.49 | 25,411.04 |
| 广西事业部 | -29,631.30 | -22,600.10 | 1,495.04 |
| 江西事业部 | 118,736.30 | 160,900.19 | -7,866.16 |
| 河南事业部 | 97,667.22 | 134,880.66 | -6,457.50 |
| 浙沪事业部 | 72,593.15 | 94,564.60 | 20,449.44 |
| 湖北事业部 | 132,404.95 | 179,996.96 | 35,427.30 |
| 湖南事业部 | 43,362.84 | 62,602.05 | 9,775.03 |
| 甘宁新事业部 | 115,623.91 | 157,800.45 | 29,394.18 |
| 福建事业部 | 14,045.39 | 20,346.01 | -1,114.71 |
| 苏皖事业部 | -7,389.02 | -7,679.15 | -155.74 |
| 陕蒙事业部 | 20,167.44 | 25,752.25 | 3,874.57 |

********* data item *********
"""

    result_str = sum_numbers(text=test_text)
    result = json.loads(result_str)

    # ── 预期值 ──────────────────────────────────────────────────────────
    expected = {
        "税后净收入（元）": 1323606.03,
        "税前收入（元）": 1802112.86,
        "劳务成本收入（元）": 236398.12,
    }

    print("=" * 65)
    print("  多列分别求和 测试结果")
    print("=" * 65)

    if "error" in result:
        print(f"\n  [ERROR] {result['error']}")
        return

    print(f"\n  处理的 data item 块数: {result['block_count']}")
    print(f"  跳过的列: {result['skipped_columns']}")
    print(f"\n  数值列（{len(result['columns'])} 列）:")

    all_pass = True
    for col_name, col_data in result["columns"].items():
        total = col_data["total"]
        exp = expected.get(col_name)
        match = "PASS" if exp is not None and abs(total - exp) < 0.01 else "FAIL"
        if match == "FAIL":
            all_pass = False

        print(f"\n  ── {col_name} ──")
        print(f"     个数: {col_data['count']}")
        for i, v in enumerate(col_data["values"], 1):
            print(f"       {i:2d}. {v}")
        print(f"     总和: {col_data['total_formatted']}  |  预期: {exp:,.2f}  |  [{match}]")

    print(f"\n{'─' * 65}")
    if all_pass:
        print("  [OVERALL] 全部三列求和验证 PASS")
    else:
        print("  [OVERALL] 存在 FAIL，请检查。")
    print("=" * 65)


if __name__ == "__main__":
    test_with_original_data()
