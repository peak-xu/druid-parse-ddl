"""
ChannelV2 服务入口模块
====================

职责：
  1. 加载日志配置
  2. 组装依赖注入容器（DB / HTTP / LLM / RAG / NLP / 模板）
  3. 创建 FastAPI 应用并挂载中间件、生命周期、可观测性
  4. 注册业务路由（流式对话 / 健康检查）
  5. 提供编程式启动入口（uvicorn）

调用链路：
  main.py  →  channelV2.py  →  llm / api / nlp / store / utils
"""

# ═══════════════════════════════════════════════════════════════════════════════════
# 导入 — 分组：标准库 → 第三方 → 内部模块
# ═══════════════════════════════════════════════════════════════════════════════════

# ── 标准库 ────────────────────────────────────────────────────────────────────────
import logging.config
import sys
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from json import dumps
from logging import Logger, getLogger
from os import getenv
from typing import cast

# ── 第三方 ────────────────────────────────────────────────────────────────────────
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from jinja2 import Environment, FileSystemLoader
from punq import Container, Scope
from sqlalchemy import URL
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine
from starlette.responses import StreamingResponse
from yaml import safe_load

# ── 内部模块 ──────────────────────────────────────────────────────────────────────
from api import KnowledgeRetriever, LangFlowClient
from channelV2 import ChannelV2
from entity import ChatRequest
from llm import LlmRepository
from nlp import Nlp, RapidfuzzNlp
from store import DbMessageStore, MessageStore
from utils import HttpClient


# ═══════════════════════════════════════════════════════════════════════════════════
# 0. 环境文件 — 根据命令行参数加载对应 .env
# ═══════════════════════════════════════════════════════════════════════════════════

def _load_env_file() -> str:
    """根据命令行参数解析并加载对应的 .env 文件。

    映射关系：
      prod  →  .env      （生产环境）
      dev   →  .env.dev  （开发环境）

    规则：
      - sys.argv[1] 传入 'prod' 或 'dev' → 加载对应文件
      - 无参数（IDE 直接运行）          → 默认 .env.dev
    """
    from dotenv import load_dotenv

    env_map = {
        'prod': '.env',
        'dev': '.env.dev',
    }

    if len(sys.argv) > 1 and sys.argv[1] in env_map:
        env_file = env_map[sys.argv[1]]
    else:
        env_file = '.env.dev'

    load_dotenv(env_file)
    return env_file


# ═══════════════════════════════════════════════════════════════════════════════════
# 1. 日志初始化
# ═══════════════════════════════════════════════════════════════════════════════════

def _setup_logging(config_path: str = 'logger.yaml') -> Logger:
    """加载 YAML 日志配置（JSON 格式输出至文件 + 控制台），返回模块级 logger。"""
    with open(config_path, 'rt') as f:
        config = safe_load(f.read())
        logging.config.dictConfig(config)
    return getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════════
# 2. 依赖注入容器 — 按职责分组注册所有单例
# ═══════════════════════════════════════════════════════════════════════════════════

def _build_container() -> Container:
    """
    组装 IoC 容器，按注册顺序分为四组：

      - 基础设施：Logger / HttpClient / AsyncEngine
      - 数据  层：MessageStore
      - 业务  层：LangFlowClient / KnowledgeRetriever / LlmRepository / Nlp
      - 应用  层：Jinja2 Environment / ChannelV2
    """
    c = Container()

    # ── 基础设施 ──────────────────────────────────────────────────────────────

    c.register(Logger, instance=getLogger(__name__), scope=Scope.singleton)

    c.register(HttpClient,
               factory=lambda: HttpClient(
                   float(getenv('http.timeout')),
                   c.resolve(Logger),
               ),
               scope=Scope.singleton)

    c.register(AsyncEngine,
               instance=create_async_engine(
                   URL.create(
                       drivername=getenv('db.driver'),
                       username=getenv('db.user'),
                       password=getenv('db.password'),
                       host=getenv('db.host'),
                       port=int(getenv('db.port')),
                       database=getenv('db.database'),
                   ),
                   pool_pre_ping=True,
                   pool_recycle=3600,
                   pool_size=5,
                   pool_timeout=5,
               ),
               scope=Scope.singleton)

    # ── 数据层 ────────────────────────────────────────────────────────────────

    c.register(MessageStore, DbMessageStore, scope=Scope.singleton)

    # ── 业务层 ────────────────────────────────────────────────────────────────

    c.register(LangFlowClient,
               factory=lambda: LangFlowClient(
                   getenv('langflow.host'),
                   c.resolve(HttpClient),
                   c.resolve(Logger),
               ),
               scope=Scope.singleton)

    c.register(LlmRepository)

    c.register(KnowledgeRetriever,
               factory=lambda: KnowledgeRetriever(
                   getenv('knowledge.host'),
                   getenv('ragflow.host'),
                   getenv('ragflow.api_key'),
                   getenv('zsk_knowledge.host'),
                   getenv('zsk_knowledge.api_key'),
                   c.resolve(HttpClient),
               ),
               scope=Scope.singleton)

    c.register(Nlp, RapidfuzzNlp, scope=Scope.singleton)

    # ── 应用层 ────────────────────────────────────────────────────────────────

    c.register(Environment,
               instance=Environment(
                   loader=FileSystemLoader('templates'),
                   enable_async=True,
                   trim_blocks=True,
                   lstrip_blocks=True,
               ),
               scope=Scope.singleton)

    c.register(ChannelV2, scope=Scope.singleton)

    return c


# ═══════════════════════════════════════════════════════════════════════════════════
# 3. 可观测性 — Prometheus 指标 + OpenTelemetry 链路追踪
# ═══════════════════════════════════════════════════════════════════════════════════

def _setup_monitoring(app: FastAPI, logger: Logger) -> None:
    """挂载 Prometheus /metrics 端点和 OpenTelemetry 自动埋点。

    均为可选依赖：未安装时仅打 warning 日志，不影响服务启动。
    """
    # Prometheus：自动采集 QPS / 延迟直方图 / 错误率，暴露于 GET /metrics
    try:
        from prometheus_fastapi_instrumentator import Instrumentator
        Instrumentator().instrument(app).expose(app)
        logger.info('Prometheus 指标监控已启用 → /metrics')
    except ImportError:
        logger.warning('prometheus-fastapi-instrumentator 未安装，跳过 Prometheus 监控')

    # OpenTelemetry：通过 OTEL_SERVICE_NAME / OTEL_EXPORTER_OTLP_ENDPOINT 环境变量控制
    try:
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        FastAPIInstrumentor.instrument_app(app)
        logger.info('OpenTelemetry 链路追踪已启用')
    except ImportError:
        logger.warning('opentelemetry-instrumentation-fastapi 未安装，跳过链路追踪')


# ═══════════════════════════════════════════════════════════════════════════════════
# 4. 生命周期事件 — 启动 / 关闭时的收尾工作
# ═══════════════════════════════════════════════════════════════════════════════════

# ── 模块级全局引用（在 main 组装流程中延迟赋值） ─────────────────────────────────
_container: Container | None = None   # 供生命周期事件和路由获取依赖
_logger: Logger | None = None


@asynccontextmanager
async def _lifespan(app: FastAPI) -> AsyncIterator[None]:
    """FastAPI lifespan 事件处理：启动时记录信息，关闭时释放资源。"""
    _logger.info('ChannelV2 服务启动中... PID=%s', __import__('os').getpid())
    yield
    _logger.info('ChannelV2 服务正在关闭...')
    try:
        engine = cast(AsyncEngine, _container.resolve(AsyncEngine))
        await engine.dispose()
        _logger.info('数据库连接池已释放')
    except Exception:
        pass
    _logger.info('ChannelV2 服务已关闭')


# ═══════════════════════════════════════════════════════════════════════════════════
# 5. 创建 FastAPI 应用 + 挂载中间件
# ═══════════════════════════════════════════════════════════════════════════════════

def _create_app() -> FastAPI:
    """创建 FastAPI 实例并挂载 CORS 中间件。"""
    app = FastAPI(
        title='ChannelV2',
        docs_url=None,          # 生产环境关闭 Swagger 文档
        redoc_url=None,
        debug=getenv('debug', 'true').lower() == 'true',
        lifespan=_lifespan,
    )

    origins = [
        "https://serverless.t.nxin.com",
        "https://serverless.nxin.com",
        "https://r.nxin.com",
        "https://r.t.nxin.com",
        "https://liveui.nxin.com",
        "https://liveui.t.nxin.com",
        "https://liveui.nxin.com:8081",
        "https://liveui.t.nxin.com:8081",
    ]

    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,  # 允许的源
        allow_credentials=True,
        allow_methods=['*'],
        allow_headers=['*'],
    )

    return app


app = _create_app()


# ═══════════════════════════════════════════════════════════════════════════════════
# 6. 路由 — 健康检查 + 业务接口
# ═══════════════════════════════════════════════════════════════════════════════════


@app.get('/health', summary='健康检查')
async def health_check():
    """轻量级健康探测端点，供 K8s / LB 做 liveness / readiness probe。"""
    return {
        'status': 'ok',
        'service': 'ChannelV2',
        'timestamp': int(time.time()),
    }


@app.post('/fast_channelV2', summary='流式应答通道')
async def fast_channel_v2(request: ChatRequest):
    """核心业务路由：接收多轮对话请求，返回 SSE 流式响应。

    流程：
      1. 从容器中解析 ChannelV2 单例
      2. 记录请求日志（含 conversation_id / env / agent_data / user_chats）
      3. 构造 StreamingResponse，设置 SSE 相关响应头
    """
    channel = cast(ChannelV2, _container.resolve(ChannelV2))

    print("========================== main.py -> fast_channelV2 入参打印开始 ==========================")

    # print(request.model_dump_json(indent=2, ensure_ascii=False))

    # print(request)

    print("========================== main.py -> fast_channelV2 入参打印结束 ==========================")

    _logger.info(
        '聊天请求:[conversation_id:%s, env:%s, agent_data:%s, user_chats:%s]',
        request.conversation_id,
        request.env.model_dump_json(),
        request.agent_data.model_dump_json(),
        dumps([it.model_dump() for it in request.user_chats], ensure_ascii=False),
    )

    resp = StreamingResponse(channel.chat(request), media_type='text/event-stream')
    resp.headers['Cache-control'] = 'no-cache'
    resp.headers['Connection'] = 'keep-alive'
    resp.headers['X-Accel-Buffering'] = 'no'
    resp.headers['Content-Type'] = 'text/event-stream; charset=utf-8'
    return resp


# ═══════════════════════════════════════════════════════════════════════════════════
# 7. 组装入口 — 拼接所有步骤，产生可运行的 app
# ═══════════════════════════════════════════════════════════════════════════════════

def bootstrap() -> FastAPI:
    """
    一站式启动流水线：

        logging → DI container → monitoring → lifecycle → routes

    返回配置完毕的 FastAPI 应用实例。
    """
    global _container, _logger

    # Step 0: 根据运行环境加载对应 .env 文件
    _env_file = _load_env_file()

    # Step 1: 日志
    _logger = _setup_logging()
    _logger.info('已加载环境配置文件: %s', _env_file)

    # Step 2: 依赖注入容器
    _container = _build_container()
    _logger = cast(Logger, _container.resolve(Logger))   # 替换为容器托管的 logger

    # Step 3: 可观测性
    _setup_monitoring(app, _logger)

    _logger.info('ChannelV2 初始化完成')
    return app


# 模块加载时立即执行组装流水线
bootstrap()


# ═══════════════════════════════════════════════════════════════════════════════════
# 8. 编程式启动入口（python main.py）
# ═══════════════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import uvicorn

    host = getenv('server.host', '0.0.0.0')
    port = int(getenv('server.port', '7997'))
    workers = int(getenv('server.workers', '1'))
    reload = getenv('server.reload', 'false').lower() == 'true'

    _logger.info('启动 uvicorn: host=%s, port=%d, workers=%d, reload=%s',
                 host, port, workers, reload)

    uvicorn.run(
        'main:app',
        host=host,
        port=port,
        workers=workers,
        reload=reload,
        log_level='info',
        access_log=True,
    )
