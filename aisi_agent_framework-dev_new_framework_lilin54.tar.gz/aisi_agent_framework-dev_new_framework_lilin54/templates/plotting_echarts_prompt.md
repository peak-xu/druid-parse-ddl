{% if dataset_dict %}
请根据用户问题和相关数据集，生成符合绘制echarts图表的参数json
相关数据集：
{{dataset_dict}}
{% else %}
请根据用户问题和上下文，生成符合绘制echarts图表的参数json
{% endif %}

### 要求：
- 如果可以，echarts图表中要在恰当的位置体现数值，即设置参数中的`label`

### 示例参数格式：
{
    "option": {
        "title": {"text": "ECharts 入门示例"},
        "tooltip": {},
        "legend": {"data": ["销量"]},
        "xAxis": {"data": ["衬衫","羊毛衫","雪纺衫","裤子","高跟鞋","袜子"]},
        "yAxis": {},
        "series": [{"name": "销量","type": "bar","data": [5,20,36,10,10,20],"label": {"show": true, "position": "top"}}],
        "animation": false
    }
}
请直接生成不携带markdown格式的json，如数据集数据缺失或和问题无关无法生成，输出{"option": {}}